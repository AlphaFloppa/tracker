type Stage = 'register' | 'documentsSubmission' | 'exams' | 'interview' | 'final';

export type{
    Stage
}