import styles from './.module.css';
import { RegisterPage } from "./Pages/RegisterPage/RegisterPage";
import { DocumentsPage } from "./Pages/DocumentsPage/DocumentsPage";
import { ExamsPage } from "./Pages/ExamsPage/ExamsPage";
import { InterviewPage } from "./Pages/InterviewPage/InterviewPage";
import { EndingPage } from "./Pages/EndingPage/EndingPage";
import { ProfileSidebar } from '../Common/ProfileSidebar/ProfileSidebar';
import { Track } from '../Common/Track/Track';
import { MouseEventHandler } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDevice } from '../../../hooks/DeviceType.hooks';
import { Student } from '../../../types/User';

type Props = {
    student: Student,
    isProfileOpen: boolean,
    profileOpenHandler: MouseEventHandler<HTMLElement>,
    profileCloseHandler: () => void,
    activePage: number,
    setActivePage: (number: number) => void,
    onExit: Function
}

const DashboardRender = (
    {
        student,
        isProfileOpen,
        profileOpenHandler,
        profileCloseHandler,
        activePage,
        setActivePage,
        onExit
    }: Props
) => {
    const navigate = useNavigate();
    const isMobile = useDevice();
    const gotoHomeHandler = () => {
        onExit();
        navigate(-1);
    }

    return (
            <div
                className={`${styles.mainContainer} ${isMobile ? styles.mobile : ''}`}
                id='overlay-provider'
            >
                <div
                    className={styles.gotoBackBtn}
                    onClick={gotoHomeHandler}
                >
                </div>

                <div className={styles.header}>
                    <div className={styles.logo}></div>
                    <span className={styles.signRedirectBtn}>{'На главную'}</span>
                    <div
                        className={styles.profileIcon}
                        onClick={profileOpenHandler}
                    >
                    </div>
                </div>


                <div className={styles.track}>
                    <div className={styles.textCont}>
                        <span className={styles.trackHeader}>{'Траектория поступления'}</span>
                        <span className={styles.trackSubHeader}>{'Отслеживай своё поступление без лишних проблем'}</span>
                    </div>
                    <Track activePage={activePage} setPage={setActivePage} currentStage={student.currentStage}/>
                </div>

                {
                    function () {
                        switch (activePage) {
                            case 0:
                                return (
                                    <RegisterPage />
                                );
                            case 1:
                                return (
                                    <DocumentsPage student={student} />
                                );
                            case 2:
                                return (
                                    <ExamsPage student={student} />
                                );
                            case 3:
                                return (
                                    <InterviewPage student={student} />
                                );
                            case 4:
                                return (
                                    <EndingPage student={student} />
                                );
                        }
                    }()
                }

                {
                    isProfileOpen && <ProfileSidebar onClose={profileCloseHandler} />
                }
            </div>
    );
}

export {
    DashboardRender
}