import commonStyles from '../../Pages/.module.css';
import dashboardStyles from '../../.module.css';
import styles from './.module.css';
import { useUser } from '../../../../../hooks/UsersStorage.hooks';
import { stageToPageIndex } from '../../Dashboard';

const InterviewPage = () => {
    const user = useUser().user;
    if (user === null || user.type !== 'student') {
        return;
    }
    const { currentStage } = user;
    return (
        <div className={`${dashboardStyles.infoContainer} ${styles.infoContainer}`}>
            <div className={commonStyles.container}>
                <div className={commonStyles.infoContainer}>
                    <span className={commonStyles.trackHeader}>{'Собеседование'}</span>
                    <span className={commonStyles.trackSubHeader}>{'Подробная информация об этом этапе:'}</span>
                    <span className={commonStyles.stageDesc}>{'Онлайн-встреча с сотрудником приемной комиссии, чтобы ты рассказал о себе, своих увлечениях и почему тебя заинтересовал Инфотех.'}</span>
                    <div className={commonStyles.deadlinesStatusCont}>
                        <div className={commonStyles.deadlines}>
                            <span className={commonStyles.deadlinesHeader}>{'Сроки:'}</span>
                            <span className={commonStyles.deadlinesInfo}>{'01.06.26 - 15.07.26 '}</span>
                        </div>
                        <div className={commonStyles.status}>
                            <span className={commonStyles.statusHeader}>{'Статус этапа:'}</span>
                            <span
                                className={
                                    `
                                        ${commonStyles.statusValue} 
                                        ${stageToPageIndex(currentStage) < 3
                                        ? commonStyles.unstarted
                                        : stageToPageIndex(currentStage) === 3
                                            ? commonStyles.unfinished
                                            : commonStyles.finished
                                    }
                                    `
                                }
                            >
                                {
                                    stageToPageIndex(currentStage) < 3
                                        ? 'Не начато'
                                        : stageToPageIndex(currentStage) === 3
                                            ? 'В процессе'
                                            : 'Пройдено'
                                }
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <div className={commonStyles.arrowNext} id='nextPageBtn'></div>
            <div className={commonStyles.arrowPrevious} id='previousPageBtn'></div>
        </div >
    );
}

export {
    InterviewPage
}