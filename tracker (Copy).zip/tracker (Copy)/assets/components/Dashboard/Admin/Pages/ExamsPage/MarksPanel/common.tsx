import type { ExamMark } from "../../../../../../types/Exam";
import styles from './.module.css';

const stylishMark = (mark: ExamMark) => {
    const { currentMark, maxMark } = mark;
    const examResult = (currentMark / maxMark);
    switch (true) {
        case examResult <= 0.1:
            return styles.markAwful;
        case examResult <= 0.2:
            return styles.markWorse;
        case examResult <= 0.3:
            return styles.markBad;
        case examResult <= 0.6:
            return styles.markMedium;
        case examResult <= 0.8:
            return styles.markGood;
        case examResult <= 1:
            return styles.markBest;
        default:
            return undefined;
    }
}

export {
    stylishMark
}