type Interview = {
    datetime: Date,
    link: string
}

export type{
    Interview
}