import { createContext, ReactNode, useContext, useEffect, useState } from "react";

const mobileWidth = 768;

type DeviceType = {
    isMobile: boolean,
    setIsMobile: Function
}

const DeviceDataContext = createContext<DeviceType | null>(null);

const DeviceDataProvider = ({ children }: { children: ReactNode }) => {
    const [isMobile, setIsMobile] = useState<boolean>(
        window.innerWidth <= mobileWidth
    );

    const content: DeviceType = {
        isMobile,
        setIsMobile
    }

    useEffect(
        () => {
            const resizeHandler = (e: UIEvent) => {
                if (!isMobile && window.innerWidth <= mobileWidth) {
                    setIsMobile(true);
                    console.log('useDeviceHook working a');
                } else if (isMobile && window.innerWidth > mobileWidth) {
                    setIsMobile(false);
                    console.log('useDeviceHook working b');
                }
            }

            window.addEventListener(
                'resize',
                resizeHandler
            );

            return () => {
                window.removeEventListener(
                    'resize',
                    resizeHandler
                );
            }
        },
        [isMobile]
    );

    return (
        <DeviceDataContext.Provider value={content}>
            {children}
        </DeviceDataContext.Provider>
    );
}

const useDevice = () => {
    const content = useContext(DeviceDataContext);
    if (content === null) {
        console.log('device havent defined');
        return false;
    }

    return content.isMobile;
}

export {
    DeviceDataProvider,
    useDevice
}