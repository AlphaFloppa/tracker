import { createRoot } from 'react-dom/client';
import { App } from './components/App/app';
import { UserDataProvider } from './hooks/UserStorage.hooks';
import { DeviceDataProvider } from './hooks/DeviceType.hooks';

window.addEventListener('DOMContentLoaded', () => {
    const rootContainer = document.getElementById('root');
    if (!rootContainer) {
        alert('rootContainer is null');
        return;
    }

    const root = createRoot(rootContainer);

    root.render(
        <DeviceDataProvider>
            <UserDataProvider>
                    <App />
            </UserDataProvider>
        </DeviceDataProvider>
    )
});