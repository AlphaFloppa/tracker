import commonStyles from '../../Pages/.module.css';
import dashboardStyles from '../../.module.css';
import styles from './.module.css';
import { MarksPanel } from './MarksPanel/MarksPanel';
import { useUser } from '../../../../../hooks/UsersStorage.hooks';
import { stageToPageIndex } from '../../Dashboard';

type PageProps = {
    activePage: number
}

const ExamsPage = () => {
    const user = useUser().user;
    if (user === null || user.type !== 'student') {
        return;
    }
    const { currentStage } = user;
    return (
        <div className={`${dashboardStyles.infoContainer} ${styles.infoContainer}`}>
            <div className={commonStyles.container}>
                <div className={commonStyles.infoContainer}>
                    <span className={commonStyles.trackHeader}>{'Экзамены'}</span>
                    <span className={commonStyles.trackSubHeader}>{'Подробная информация об этом этапе:'}</span>
                    <span className={commonStyles.stageDesc}>{'Ты пишешь несколько работ: диагностическое тестирование и экзамен по физике и математике. Это поможет уточнить,подходит тебе обучение в лицее или нет.'}</span>
                    <div className={commonStyles.deadlinesStatusCont}>
                        <div className={commonStyles.deadlines}>
                            <span className={commonStyles.deadlinesHeader}>{'Сроки:'}</span>
                            <span className={commonStyles.deadlinesInfo}>{'01.06.26 - 15.07.26'}</span>
                        </div>
                        <div className={commonStyles.status}>
                            <span className={commonStyles.statusHeader}>{'Статус этапа:'}</span>
                            <span
                                className={
                                    `
                                        ${commonStyles.statusValue} 
                                        ${stageToPageIndex(currentStage) < 2
                                        ? commonStyles.unstarted
                                        : stageToPageIndex(currentStage) === 2
                                            ? commonStyles.unfinished
                                            : commonStyles.finished
                                    }
                                    `
                                }
                            >
                                {
                                    stageToPageIndex(currentStage) < 2
                                        ? 'Не начато'
                                        : stageToPageIndex(currentStage) === 2
                                            ? 'В процессе'
                                            : 'Пройдено'
                                }
                            </span>
                        </div>
                    </div>

                </div>
                <MarksPanel />
            </div>

            <div className={commonStyles.arrowNext} id='nextPageBtn'></div>
            <div className={commonStyles.arrowPrevious} id='previousPageBtn'></div>
        </div >
    )
}

export {
    ExamsPage
}