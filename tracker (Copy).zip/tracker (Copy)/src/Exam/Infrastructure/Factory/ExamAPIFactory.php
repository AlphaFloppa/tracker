<?php

namespace App\Exam\Infrastructure\Factory;

use App\Exam\API\ExamAPI;
use PDO;
use App\Exam\API\ExamAPIInterface;
use App\Exam\Infrastructure\Query\ExamQueryService;
use App\Exam\Infrastructure\Repository\ExamRepository;
use App\Exam\Infrastructure\Service\ExamService;

class ExamAPIFactory
{
    public static function createExamAPI(PDO $pdo): ExamAPIInterface
    {
        return new ExamAPI(
            new ExamQueryService($pdo),
            new ExamService(
                new ExamRepository($pdo)
            )
        );
    }
}