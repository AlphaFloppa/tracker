<?php

namespace App\Common\Service\StagesDeadlines\Repository;

use DateTime;
use PDO;

class StagesDeadlinesRepository
{
    public function __construct(
        private PDO $pdo
    )
    {}

    public function setStageDeadlines(
        string $studentId,
        array $deadlines
    ): void
    {
        $query = <<<SQL
            REPLACE INTO stage
            (student_id, name, start, end)
            VALUES
            (:studentId, 'documentsSubmission', :docsStageStart, :docsStageEnd),
            (:studentId, 'exams', :examsStageStart, :examsStageEnd),
            (:studentId, 'interview', :interviewStageStart, :interviewStageEnd),
            (:studentId, 'final', NULL, :finalStageEnd) 
        SQL;

        $stmt = $this->pdo->prepare($query);

        $stmt->execute(
            [
                'studentId' => $studentId,
                'docsStageStart' => $this->formatDate(
                    $deadlines['documentsSubmission']['start']
                ),
                'docsStageEnd' => $this->formatDate(
                    $deadlines['documentsSubmission']['end']
                ),
                'examsStageStart' => $this->formatDate(
                    $deadlines['exams']['start']
                ),
                'examsStageEnd' => $this->formatDate(
                    $deadlines['exams']['end']
                ),
                'interviewStageStart' => $this->formatDate(
                    $deadlines['interview']['start']
                ),
                'interviewStageEnd' => $this->formatDate(
                    $deadlines['interview']['end']
                ),
                'finalStageEnd' => $this->formatDate(
                    $deadlines['final']['end']
                )
            ]
        );
    }

    private function formatDate(string $date): string
    {
        return DateTime::createFromFormat('d.m.Y', $date)->format('Y-m-d');
    }
}