import type { StudentData } from "../../types/User";
import { useEffect } from "react";

type Filters = {
    classFilters: Array<string>,
    stageFilters: Array<string>,
    studentNameQuery: string | null,
    setResult: Function
}

const useStudentsData = ({ classFilters, stageFilters, studentNameQuery, setResult }: Filters) => {
    const fetchData = () => {
        const query = new URLSearchParams();
        if (classFilters.length === 0 || stageFilters.length === 0) {
            setResult([]);
            return;
        }
        classFilters.forEach(
            (filter) => {
                query.append('class[]', filter);
            }
        );
        stageFilters.forEach(
            (filter) => {
                query.append('stage[]', filter)
            }
        );
        if (studentNameQuery !== null) {
            query.append('name', studentNameQuery);
        }
        fetch(
            `/students?${query.toString()}`,
            {
                method: 'GET'
            }
        ).then(
            async (response) => {
                const studentsData: Array<any> = await response.json();
                setResult(
                    parse(studentsData)
                );
            }
        )
    }

    const parse = (studentsData: Array<any>): Array<StudentData> => studentsData
        .map(
            (studentData) => ({
                ...studentData,
                class: Number(studentData.class)
            })
        );

    useEffect(
        fetchData,
        [classFilters, stageFilters, studentNameQuery, setResult]
    )
}

export {
    useStudentsData
}