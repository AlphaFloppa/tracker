import { useUser } from '../../../../hooks/UsersStorage.hooks';
import styles from './.module.css';
import { stageToPageIndex } from '../Dashboard';

type TrackProps = {
    activePage: number,
    setPage: (number: number) => void
}

const Track = ({ activePage, setPage }: TrackProps) => {
    const user = useUser().user;
    if (user === null || user.type !== 'student') {
        return;
    }
    const { currentStage } = user;
    return (
        <div className={styles.roadmap}>
            <div
                className={
                    `
                    ${styles.step} 
                    ${activePage === 0 ? styles.active : ''}
                    ${stageToPageIndex(currentStage) === 0 ? styles.current : ''}
                `
                }
            >
                <div className={styles.dot} onClick={() => { setPage(0) }}></div>
                <div className={styles.stepContent}>
                    <div className={styles.label}>{'Регистрация'}</div>
                </div>
            </div>

            <div
                className={
                    `
                    ${styles.step} 
                    ${activePage === 1 ? styles.active : ''}
                    ${stageToPageIndex(currentStage) === 1 ? styles.current : ''}
                `
                }
            >
                <div className={styles.dot} onClick={() => { setPage(1) }}></div>
                <div className={styles.stepContent}>
                    <div className={styles.label}>{'Подача документов'}</div>
                </div>
            </div>

            <div
                className={
                    `
                    ${styles.step} 
                    ${activePage === 2 ? styles.active : ''}
                    ${stageToPageIndex(currentStage) === 2 ? styles.current : ''}
                `
                }
            >
                <div className={styles.dot} onClick={() => { setPage(2) }}></div>
                <div className={styles.stepContent}>
                    <div className={styles.label}>{'Экзамены'}</div>
                </div>
            </div>

            <div
                className={
                    `
                    ${styles.step} 
                    ${activePage === 3 ? styles.active : ''}
                    ${stageToPageIndex(currentStage) === 3 ? styles.current : ''}
                `
                }
            >
                <div className={styles.dot} onClick={() => { setPage(3) }}></div>
                <div className={styles.stepContent}>
                    <div className={styles.label}>{'Собеседование'}</div>
                </div>
            </div>

            <div
                className={
                    `
                    ${styles.step} 
                    ${activePage === 4 ? styles.active : ''}
                    ${stageToPageIndex(currentStage) === 4 ? styles.current : ''}
                `
                }
            >
                <div className={styles.dot} onClick={() => { setPage(4) }}></div>
                <div className={styles.stepContent}>
                    <div className={styles.label}>{'Поступление'}</div>
                </div>
            </div>
        </div >
    );
}

export {
    Track
}