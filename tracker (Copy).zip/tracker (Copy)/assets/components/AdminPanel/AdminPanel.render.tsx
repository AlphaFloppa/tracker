import { MouseEventHandler } from "react";
import { Student, StudentData } from "../../types/User";
import styles from './.module.css';
import { SearchingRow } from "./SearchingRow/SearchingRow";
import { FilterPanel } from "./FilterPanel/FilterPanel";
import { ProfileSidebar } from "../Dashboard/Common/ProfileSidebar/ProfileSidebar";
import { StudentCard } from "./StudentCard/StudentCard";

type Props = {
    containerRef: React.RefObject<HTMLDivElement | null>
    isProfileOpen: boolean,
    profileOpenHandler: MouseEventHandler,
    profileCloseHandler: () => void,
    setClassFilters: Function,
    setStageFilters: Function,
    searchingQuery: string | null,
    setSearchingQuery: Function,
    students: StudentData[],
    selectAllStudentsHandler: MouseEventHandler,
    selection: string[],
    studentSelectHandler: (id: string) => void,
    studentInspectHandler: (id: string) => void
}

const AdminPanelRender = (
    {
        containerRef,
        isProfileOpen,
        profileOpenHandler,
        profileCloseHandler,
        setClassFilters,
        setStageFilters,
        searchingQuery,
        setSearchingQuery,
        students,
        selectAllStudentsHandler,
        selection,
        studentSelectHandler,
        studentInspectHandler
    }: Props
) => {
    return (
            <div
                className={styles.mainContainer}
                ref={containerRef}
            >
                <div className={styles.header}>
                    <div className={styles.logo}></div>
                    <div
                        className={styles.profileIcon}
                        onClick={profileOpenHandler}
                    >
                    </div>
                </div>

                <FilterPanel
                    setClassFilters={setClassFilters}
                    setStageFilters={setStageFilters}
                />

                <div className={styles.studentsViewer}>
                    <span className={styles.counter}>
                        {
                            searchingQuery === null
                                ? `Всего поступающих: ${students.length}`
                                : `Результаты поиска: ${students.length}`
                        }
                    </span>

                    <div
                        className={styles.selectAllStudentsBtn}
                        onClick={selectAllStudentsHandler}
                    >
                        {'Выбрать все'}
                    </div>
                    <SearchingRow
                        setQuery={setSearchingQuery}
                    />
                    <div className={styles.contentContainer}>
                        <div className={styles.labels}></div>
                        <ul className={styles.studentsList}>
                            {
                                students.map(
                                    (studentData) => (
                                        <li
                                            key={studentData.id}
                                            className={styles.studentLItem}
                                        >
                                            <div
                                                className={
                                                    `
                                                    ${styles.selectStudentCardBtn}
                                                    ${selection.some(
                                                        (selectedId) => studentData.id === selectedId
                                                    )
                                                        ? styles.selected
                                                        : ''
                                                    }
                                                `
                                                }
                                                onClick={
                                                    () => {
                                                        studentSelectHandler(studentData.id)
                                                    }
                                                }
                                            >
                                            </div>
                                            <StudentCard
                                                studentData={studentData}
                                                onInspect={studentInspectHandler}
                                            />
                                        </li>
                                    )
                                )
                            }
                        </ul>
                    </div>

                    <div className={styles.selectAllBtn}></div>
                </div>

                {
                    isProfileOpen &&
                    <ProfileSidebar
                        onClose={profileCloseHandler}
                    />
                }
            </div>
    );
}

export {
    AdminPanelRender
}