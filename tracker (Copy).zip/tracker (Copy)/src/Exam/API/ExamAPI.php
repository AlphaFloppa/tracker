<?php

namespace App\Exam\API;

use App\Exam\App\Exam;
use App\Exam\App\Query\ExamQueryServiceInterface;
use App\Exam\App\Service\ExamServiceInterface;
use App\Exam\Infrastructure\Service\ExamService;

class ExamAPI implements ExamAPIInterface
{
    public function __construct(
        private ExamQueryServiceInterface $queryService,
        private ExamServiceInterface $service
    )
    {}
    public function findExamByStudentId(string $id): ?Exam
    {
        return $this->queryService->findExamByStudentId($id);
    }

    public function setExamResultsByStudentId(string $id, array $results): void
    {
        $this->service->setExamResultsByStudentId($id, $results);
    }
}