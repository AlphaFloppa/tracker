import { ExamMark } from "./Exam"

type Student = {
    type: 'student',
    password: string,
    id: string,
    class: number,
    email: string,
    fullName: string,
    parentName: string,
    phone: string,
    currentStage: 'register' | 'documentsSubmission' | 'exams' | 'interview' | 'final'
    exam: {
        phys: ExamMark
        math: ExamMark
        test: ExamMark
    } | null,
    uploadedDocuments: Array<string>
}

type StudentData = Omit<Student, 'password'>

type Admin = {
    type: 'admin',
    email: string,
    password: string,
    id: string,
    fullName: string
}

type User = Student | Admin

export type {
    Student, 
    StudentData,
    Admin,
    User
}