const validExtensions = [
    'application/pdf',
    'image/png',
    'image/jpeg'
];

const useDocuments = () => {

    const storeDocs = async (files: File[]) => {
        if(
            files.length === 0
        ){
            return;
        }

        const formData = new FormData();
        files.forEach(
            (file) => {
                formData.append('files[]', file);
            }
        );

        return fetch(
            '/documents/store',
            {
                method: 'POST',
                body: formData
            }
        ).then(
            (response) => response.ok
        );
    }

    const storeDocsAsAdmin = (files: File[], studentId: string) => {
        if (
            files.length === 0
        ) {
            return;
        }

        const formData = new FormData();
        files.forEach(
            (file) => {
                formData.append('files[]', file);
            }
        );

        formData.append('studentId', studentId)

        return fetch(
            '/documents/store',
            {
                method: 'POST',
                body: formData
            }
        ).then(
            (response) => response.ok
        );
    }

    const validate = (file: File) => validExtensions.includes(file.type);

    return {
        storeDocs,
        validate,
        storeDocsAsAdmin
    };
}

export{
    useDocuments
}