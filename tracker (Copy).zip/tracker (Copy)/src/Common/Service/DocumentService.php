<?php

namespace App\Common\Service;

use Exception;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\Uid\Uuid;

class DocumentService
{
    private const STORAGE_PATH = __DIR__ . '/../../../public/documents';

    //+ validate
    /**
     * @param array $documents array of UploadedFile for saving to storage
     * @return array array of UploadedFile stored
     */
    public function saveDocuments(array $documents): array
    {
        return array_map(
            function ($document) {
                if(!$document instanceof UploadedFile)
                {
                    throw new Exception();
                }

                $uniqueName = $this->saltDocumentName(
                    pathinfo(
                        $document->getClientOriginalName(),
                        PATHINFO_FILENAME
                    )
                ) . '.' . $document->getClientOriginalExtension();

                $newFile = $document->move(
                    self::STORAGE_PATH,
                    $uniqueName
                );

                return $newFile;       
            },
            $documents
        );
    }

    private function saltDocumentName(string $name): string
    {
        return $name . '_' . Uuid::v7();
    }
}