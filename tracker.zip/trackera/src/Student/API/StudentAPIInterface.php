<?php

namespace App\Student\API;

use App\Student\App\Student;

interface StudentAPIInterface
{
    public function getStudents(
        array $classFilters, 
        array $stageFilters, 
        ?string $namePattern
    ): array;

    public function findStudent(string $id): Student;

    public function createStudent(Student $student): void;

    public function updateStudentPassword(string $id, string $password): void;

    public function deleteStudent(string $id): void;

    public function storeDocuments(string $studentId, array $documents): void;

    public function getStudentDocuments(string $studentId): array | null;

    public function setStudentStage(Student $student, string $newStage): void;

    public function setStudentStatus(string $studentId, string $newStatus): void;
}