<?php

namespace App\Common\Service\StagesDeadlines\Service;

use App\Common\Service\StagesDeadlines\Query\StagesDeadlinesQueryService;
use App\Common\Service\StagesDeadlines\Repository\StagesDeadlinesRepository;

class StagesDeadlinesService
{
    public function __construct(
        private StagesDeadlinesQueryService $queryService,
        private StagesDeadlinesRepository $repository
    )
    {}

    public function getStagesDeadlinesForStudent(string $studentId): array
    {
        return $this->queryService->getStagesDeadlinesForStudent($studentId);
    }

    public function setStageDeadlines(
        string $studentId,
        array $deadlines
    ): void
    {
        $this->repository->setStageDeadlines(
            $studentId,
            $deadlines
        );
    }
}