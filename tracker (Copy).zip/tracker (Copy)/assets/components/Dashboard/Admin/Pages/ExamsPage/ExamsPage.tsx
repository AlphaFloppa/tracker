import commonStyles from '../../Pages/.module.css';
import dashboardStyles from '../../.module.css';
import styles from './.module.css';
import { MarksPanel } from './MarksPanel/MarksPanel';
import { useDevice } from '../../../../../hooks/DeviceType.hooks';
import { StudentData } from '../../../../../types/User';
import { useUser } from '../../../../../hooks/UserStorage.hooks';
import { ChangeBtn } from '../../../../AdminPanel/MakeChangeBtn/MakeChangeBtn';
import { useEffect, useState } from 'react';
import { CustomSelect } from '../Common/Select';
import { Exams } from '../../../../../types/Exam';
import { defineStageStatus, stageSettlementOptions, defineNewStage } from '../Common/common';
import { useFetch } from '../Common/.hooks';
import { validate } from '../../../../../hooks/common';
import { useChangingStudent } from '../../hooks';

type Props = {
    student: StudentData
}

type EditingMode = false | 'stage'

const ExamsPage = (
    {}: Props
) => {
    const isUserAdmin = useUser().user?.type === 'admin';
    const {value: student, setValue: setStudent} = useChangingStudent();
    const { currentStage } = student;
    const isStageActive = currentStage === "exams";
    const isMobile = useDevice();
    const [editingMode, setEditingMode] = useState<EditingMode>(false);

    const setStageEditMode = (isEditModeEnabled: boolean) => {
        setEditingMode(
            isEditModeEnabled
                ? false
                : 'stage'
        );
    }

    const handleStageSetting = (currentStageSettingStatus: string) => {
        const newStage = defineNewStage(
            {
                currentStageSetting: currentStageSettingStatus,
                currentStage
            }
        );

        if (newStage !== null) {
            setStudent(
                {
                    ...student,
                    currentStage: newStage
                }
            );
        }
    }

    return (
        !isMobile
            ? (
                <div className={`${dashboardStyles.infoContainer} ${styles.infoContainer}`}>
                    <div className={commonStyles.container}>
                        <div className={commonStyles.infoContainer}>
                            <span className={commonStyles.trackHeader}>{'Экзамены'}</span>
                            <span className={commonStyles.trackSubHeader}>{'Подробная информация об этом этапе:'}</span>
                            <span className={commonStyles.stageDesc}>{'Ты пишешь несколько работ: диагностическое тестирование и экзамен по физике и математике. Это поможет уточнить,подходит тебе обучение в лицее или нет.'}</span>
                            <div className={commonStyles.deadlinesStatusCont}>
                                <div className={commonStyles.deadlines}>
                                    <span className={commonStyles.deadlinesHeader}>{'Сроки:'}</span>
                                    <span className={commonStyles.deadlinesInfo}>{'01.06.26 - 15.07.26'}</span>
                                </div>
                                <div className={commonStyles.status}>
                                    <span className={commonStyles.statusHeader}>{'Статус этапа:'}</span>

                                    <div style={{ display: 'flex', flexFlow: 'row nowrap', gap: '1rem', height: 'fit-content', alignItems: 'center' }}>
                                        {
                                            isStageActive && isUserAdmin && editingMode === 'stage'
                                                ? (
                                                    <CustomSelect
                                                        onSelect={handleStageSetting}
                                                        placeholder={
                                                            {
                                                                value: 'unfinished',
                                                                label: defineStageStatus(currentStage)
                                                            }
                                                        }
                                                        options={
                                                            stageSettlementOptions
                                                        }

                                                    />
                                                )
                                                : (
                                                    defineStageStatus(currentStage)
                                                )
                                        }

                                        <ChangeBtn onClick={setStageEditMode} />
                                    </div>
                                </div>
                            </div>

                        </div>
                        {
                            <MarksPanel />
                        }
                    </div>

                    <div className={commonStyles.arrowNext} id='nextPageBtn'></div>
                    <div className={commonStyles.arrowPrevious} id='previousPageBtn'></div>
                </div >
            )
            : (
                <>
                    <div className={`${commonStyles.infoContainer} ${commonStyles.mobile}`}>
                        <span className={commonStyles.trackHeader}>{'Экзамены'}</span>
                        <span className={commonStyles.trackSubHeader}>{'Подробная информация об этом этапе:'}</span>
                        <span className={commonStyles.stageDesc}>{'Ты пишешь несколько работ: диагностическое тестирование и экзамен по физике и математике. Это поможет уточнить,подходит тебе обучение в лицее или нет.'}</span>
                        <div className={commonStyles.deadlinesStatusCont}>
                            <div className={commonStyles.deadlines}>
                                <span className={commonStyles.deadlinesHeader}>{'Сроки:'}</span>
                                <span className={commonStyles.deadlinesInfo}>{'01.06.26 - 15.07.26'}</span>
                            </div>
                            <div className={commonStyles.status}>
                                <span className={commonStyles.statusHeader}>{'Статус этапа:'}</span>

                                {
                                    isStageActive && isUserAdmin && editingMode === 'stage'
                                        ? (
                                            <>
                                                <CustomSelect
                                                    onSelect={handleStageSetting}
                                                    placeholder={
                                                        {
                                                            value: 'unfinished',
                                                            label: defineStageStatus(currentStage)
                                                        }
                                                    }
                                                    options={
                                                        stageSettlementOptions
                                                    }

                                                />

                                                <ChangeBtn onClick={setStageEditMode} />
                                            </>
                                        )
                                        : (
                                            <>
                                                {
                                                    defineStageStatus(currentStage)
                                                }

                                                <ChangeBtn onClick={setStageEditMode} />
                                            </>
                                        )
                                }
                            </div>
                        </div>
                    </div>
                    {
                        <MarksPanel />
                    }

                    <div className={commonStyles.arrowNext} id='nextPageBtn'></div>
                    <div className={commonStyles.arrowPrevious} id='previousPageBtn'></div>
                </>
            )
    )
}

export {
    ExamsPage
}