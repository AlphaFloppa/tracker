<?php

namespace App\Controller;

use App\Meeting\API\MeetingAPIInterface;
use App\ServiceProvider;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

class MeetingController extends AbstractController
{
    private MeetingAPIInterface $meetingAPI;

    public function __construct(
        ServiceProvider $provider
    ) {
        $this->meetingAPI = $provider->getMeetingAPI();
    }

    public function getStudentMeeting(string $studentId): Response
    {
        $meeting = $this->meetingAPI->getMeetingByStudentId($studentId);
        if(is_null($meeting))
        {
            return new Response('', 404);
        }

        return new JsonResponse(
            [
                'datetime' => $meeting->getMeetingTime(),
                'link' => $meeting->getLink()
            ]
        );
    }
}
