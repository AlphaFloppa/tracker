<?php

namespace App\Common\Service;

use App\Common\Infrastructure\EnvProvider;
use App\Exam\App\Exam;
use App\Meeting\App\Meeting;
use Symfony\Component\Mailer\MailerInterface;
use Symfony\Component\Mime\Email;

class MailerService
{
    private string $emailsSender;
    const FAILURE_EMAIL_TEXT = 'You failed';
    const PASS_EMAIL_TEXT = 'You passed';

    public function __construct(
        private MailerInterface $mailer,
        EnvProvider $envProvider
    )
    {
        $this->emailsSender = $envProvider->getMailerParams()['senderEmail'];
    }

    public function sendStatusUpdationEmail(
        string $recipientEmail,
        string $newStatus
    ): void 
    {
        $this->sendEmail(
            $recipientEmail,
            $newStatus === 'passed'
            ? self::PASS_EMAIL_TEXT
            : self::FAILURE_EMAIL_TEXT
        );
    }

    public function sendExamResults(
        string $recipientEmail,
        Exam $exam
    ): void
    {
        $physMark = $exam->getMarks()['phys'];
        $mathMark = $exam->getMarks()['math'];
        $testMark = $exam->getMarks()['test'];

        $this->sendEmail(
            $recipientEmail,
            "
                Обновлены оценки за экзамены

                Физика:
                    {$physMark['currentMark']} из {$physMark['maxMark']}
                Математика:
                    {$mathMark['currentMark']} из {$mathMark['maxMark']}
                Диагностическое тестирование:
                    {$testMark['currentMark']} из {$testMark['maxMark']}
            "
        );
    }

    public function sendInterviewShhedule(
        string $recipientEmail,
        Meeting $meeting
    ): void
    {
        $this->sendEmail(
            $recipientEmail,
            "
                Обновлено расписание собеседования

                Новое расписание:
                    Дата: {$meeting->getFormattedDate()}
                    Время: {$meeting->getFormattedTime()}
                    Ссылка: {$meeting->getLink()}
            "
        );
    }

    private function sendEmail(
        string $recipientEmail,
        string $text
    ): void
    {
        $email = (new Email())
            ->from($this->emailsSender)
            ->to($recipientEmail)
            ->subject('Поступление в лицей')
            ->text($text);

        $this->mailer->send($email);
    }
}