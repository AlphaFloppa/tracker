<?php

namespace App\Meeting\App;

class Meeting
{
    public function __construct(
        private string $studentId,
        private int $time,
        private string $link
    ){}

    public function getMeetingTime(): int
    {
        return $this->time;
    }

    public function getFormattedTime(): string
    {
        return date('d.m.Y H:i');
    }

    public function getLink(): string
    {
        return $this->link;
    }

    public function getStudentId(): string
    {
        return $this->studentId;
    }
}