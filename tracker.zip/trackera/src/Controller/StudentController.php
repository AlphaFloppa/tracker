<?php

namespace App\Controller;

use App\Common\Service\MailerService;
use App\Common\Service\StagesDeadlines\Service\StagesDeadlinesService;
use App\Exam\API\ExamAPIInterface;
use App\Meeting\API\MeetingAPIInterface;
use App\Meeting\App\Meeting;
use App\ServiceProvider;
use App\Student\API\StudentAPIInterface;
use App\Student\App\Student;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class StudentController extends AbstractController
{
    private StudentAPIInterface $studentAPI;
    private MeetingAPIInterface $meetingAPI;
    private ExamAPIInterface $examAPI;
    private StagesDeadlinesService $stagesService;

    public function __construct(
        ServiceProvider $provider
    ) {
        $this->studentAPI = $provider->getStudentAPI();
        $this->meetingAPI = $provider->getMeetingAPI();
        $this->examAPI = $provider->getExamAPI();
        $this->stagesService = $provider->getStagesDeadlinesService();
    }

    public function getStudents(Request $request): Response
    {
        $classFilters = $request->query->all('class');
        $stageFilters = $request->query->all('stage');
        $namePattern = $request->query->get('name');
        $students = $this->studentAPI->getStudents($classFilters, $stageFilters, $namePattern);
        $studentsData = array_map(
            fn($student) => $student instanceof Student ? $student->hydrateStudentPublicData() : [],
            $students
        );
        return new JsonResponse(
            $studentsData
        );
    }

    public function findStudent(int $id): Response
    {
        $studentData = $this->studentAPI->findStudent($id);
        return new JsonResponse(
            $studentData->hydrateStudentData()
        );
    }

    public function setStudentData(Request $request, MailerService $mailerService): Response
    {
        $modifiedStudentData = $request->toArray();
        $studentId = $modifiedStudentData['id'];
        $student = $this->studentAPI->findStudent($studentId);

        if (
            array_key_exists(
                'exam',
                $modifiedStudentData
            ) &&
            !is_null($modifiedStudentData['exam'])
        ) {
            $this->examAPI->setExamResultsByStudentId(
                $studentId,
                $modifiedStudentData['exam']
            );
        }

        if (
            array_key_exists(
                'interview',
                $modifiedStudentData
            ) &&
            !is_null($modifiedStudentData['interview'])
        ) {
            $meeting = new Meeting(
                $studentId,
                (int) $modifiedStudentData['interview']['datetime'],
                $modifiedStudentData['interview']['link']
            );
            $this->meetingAPI->storeMeeting($meeting);
        }

        if (
            array_key_exists(
                'status',
                $modifiedStudentData
            ) &&
            $modifiedStudentData['status'] !== 'enroll' &&
            in_array(
                $modifiedStudentData['status'],
                ['passed', 'failed']
            )
        ) {
            $mailerService->sendStatusUpdationEmail(
                $student->getEmail(),
                $modifiedStudentData['status']
            );

            $this->studentAPI->setStudentStatus(
                $studentId,
                $modifiedStudentData['status']
            );
        }

        $this->studentAPI->setStudentStage(
            $student,
            $modifiedStudentData['currentStage']
        );

        $this->stagesService->setStageDeadlines(
            $studentId,
            $modifiedStudentData['stagesSchedule']
        );  

        return new Response('', 200);
    }
}
