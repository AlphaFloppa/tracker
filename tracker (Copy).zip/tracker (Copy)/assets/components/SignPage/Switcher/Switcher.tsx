import styles from './.module.css';
import { ActiveMode } from '../SignPage';

type SwitcherPropsType = {
    currentMode: ActiveMode,
    toggleMode: Function
}

const Switcher = ({currentMode, toggleMode}: SwitcherPropsType) => {
    const modeChangeHandler = ({ currentTarget }: React.MouseEvent) => {
        if (currentTarget.classList.contains(styles.active)) {
            return;
        }

        toggleMode();
    }
    return (
        <div className = {styles.switcher}>
            <span 
                onClick={modeChangeHandler}
                className = {
                    `
                        ${styles.label}
                        ${styles.register}
                        ${
                            currentMode === 'register'
                            && styles.active
                        }
                    `
                }>
                Регистрация
            </span>
            <span 
                onClick={modeChangeHandler}
                className = {
                    `
                        ${styles.label}
                        ${styles.login}
                        ${
                            currentMode === 'login'
                            && styles.active
                        }
                    `
            }>
                Вход
            </span>
        </div>
    );
}

export{
    Switcher
}