<?php

namespace App\Student\API;

use App\Student\App\Student;

interface StudentAPIInterface
{
    public function getStudents(
        array $classFilters, 
        array $stageFilters, 
        ?string $namePattern
    ): array;

    public function findStudent(int $id): Student;

    public function createStudent(Student $student): void;

    public function updateStudentPassword(int $id, string $password): void;

    public function deleteStudent(int $id): void;

    public function storeDocuments(string $studentId, array $documents): void;

    public function getStudentDocuments(string $studentId): array | null;
}