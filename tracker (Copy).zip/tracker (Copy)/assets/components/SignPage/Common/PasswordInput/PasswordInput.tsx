import { ForwardedRef, forwardRef, useEffect, useRef, useState, type CSSProperties } from "react";
import styles from '../../RegisterForm/.module.css';
import localStyles from './.module.css';

type PasswordInputProps = {
    onDataChange: Function,
    type: 'register' | 'login',
    errorMode: boolean
}

const registerContentIncorrectErrorMessage = "'*минимальная длина пароля - 6 символов'";

const loginContentIncorrectErrorMessage = "'*неверно указан пароль'";

const PasswordInput = forwardRef(
    ({ onDataChange, type, errorMode }: PasswordInputProps, ref: ForwardedRef<HTMLInputElement>) => {
        const inputRef = useRef<HTMLInputElement | null>(null);
        const inputWrapperRef = useRef<HTMLDivElement | null>(null);
        const error = useRef<'incorrect' | 'empty' | null>(null);
        const setError = (value: 'incorrect' | 'empty' | null) => {
            error.current = value;
        }

        const [isPasswordHidden, setIsPasswordHidden] = useState<boolean>(false);

        const validate = () => {
            const password = inputRef.current?.value;
            if (password === undefined) {
                return;
            }
            if (password === "") {
                inputWrapperRef.current?.classList.add(styles.contentEmpty)
                inputWrapperRef.current?.classList.remove(styles.contentIncorrect)
                onDataChange(false)
                return
            }
            if (password.length < 6) {
                inputWrapperRef.current?.classList.remove(styles.contentEmpty)
                inputWrapperRef.current?.classList.add(styles.contentIncorrect)
                onDataChange(false)
                return
            }

            onDataChange(true)
        }

        const resetErrors = () => {
            inputWrapperRef.current?.classList.remove(styles.contentEmpty)
            inputWrapperRef.current?.classList.remove(styles.contentIncorrect)
        }

        /*const focusHandler = () => {
            setError(null);
        }
        const blurHandler = () => {
            const password = inputRef.current?.value;
            if (!password) {
                return;
            }
            if (password === '') {
                setError('empty');
            } else if (password.length < 6) {
                setError('incorrect');
            } else {
                onDataChange(true);
            }
        }

        useEffect(
            () => {
                if (error.current === null || errorMode) {
                    return;
                }
                inputWrapperRef.current?.classList.add(
                    (
                        error.current === 'empty'
                            ? styles.contentEmpty
                            : styles.contentIncorrect
                    ) as string
                )
            }
        )*/

        useEffect(
            () => {
                document.querySelector('#submit')?.addEventListener(
                    'click',
                    validate
                )

                inputRef.current?.addEventListener(
                    'focus',
                    resetErrors
                )
            }
        )

        return (
            <div
                style={
                    {
                        '--contentIncorrectMessage': (
                            type === 'login'
                                ? loginContentIncorrectErrorMessage
                                : registerContentIncorrectErrorMessage
                        )
                    } as CSSProperties
                }
                className={`${styles.inputWrapper} ${localStyles.passwordInputWrapper}`}
                ref={inputWrapperRef}
                id='password'
            >
                <input
                    ref={
                        (node) => {
                            inputRef.current = node;
                            if (typeof ref !== 'function' && ref) {
                                ref.current = node;
                            }
                        }
                    }
                    type={
                        isPasswordHidden
                            ? 'password'
                            : 'text'
                    }
                    placeholder="Пароль"
                    name='password'
                    className={styles.input}
                />

                <div
                    className={
                        `${localStyles.showPasswordBtn}
                                ${isPasswordHidden ? localStyles.hidden : localStyles.open}`
                    }
                    onClick={() => { setIsPasswordHidden((value) => !value) }}
                ></div>
            </div>
        );
    }
);

export {
    PasswordInput
}