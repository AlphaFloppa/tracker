const useLogout = () => {
    const logoutHandler = () => {
        return fetch(
            '/logout',
            {
                method: 'POST'
            }
        ).then(
            async (response) => response
                .json()
                .then(
                    (data: {success: boolean}) => data.success
                )
        );
    }

    return logoutHandler;
}

export{
    useLogout
}