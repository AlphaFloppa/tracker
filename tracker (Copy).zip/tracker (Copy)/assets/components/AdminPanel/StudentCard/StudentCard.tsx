import { Student, StudentData } from '@/types/User';
import styles from './.module.css';

type Props = {
    studentData: StudentData
}

const decodeStageTitle = (stage: string) => {
    switch (stage) {
        case 'documentsSubmission':
            return 'Подача документов'
        case 'exams':
            return 'Экзамены'
        case 'interview':
            return 'Собеседование'
        case 'final':
            return 'Поступление'
    }
}

const StudentCard = ({ studentData }: Props) => {
    const { fullName, class: grade, currentStage } = studentData;
    return (
        <div className={styles.container}>
            <div className={styles.leftPart}>
                <div className={styles.avatar}></div>

                <span className={styles.info}>
                    {fullName}
                </span>
            </div>

            <div className={styles.rightPart}>
                <span className={styles.info}>
                    {grade}
                </span>

                <span className={styles.info}>
                    {
                        decodeStageTitle(currentStage)
                    }
                </span>
            </div>
        </div>
    );
}

export {
    StudentCard
}