import { useNavigate } from "react-router-dom";
import { useUser } from "../../../hooks/UserStorage.hooks";
import { useEffect } from "react";
import styles from '../RegisterForm/.module.css';

type useLoginPropsType = {
    isFormDataValid: React.RefObject<Map<string, boolean>>,
    formRef: React.RefObject<HTMLFormElement | null>,
    setIsErrorsExist: Function
}

const useLogin = (
    { isFormDataValid, formRef, setIsErrorsExist }: useLoginPropsType
) => {
    const { setUser } = useUser();
    const navigate = useNavigate();

    const loginHandler = (e: SubmitEvent) => {
        if (formRef.current === null) {
            return;
        }
        const actionURL = formRef.current.action;
        const formData = new FormData(formRef.current);
        const password = formData.get('password');
        fetch(
            actionURL,
            {
                method: 'POST',
                body: formData
            }
        ).then(
            async (response) => {
                if (!response.ok) {                               //500
                    console.debug(response);
                    return;
                }

                const data = await response.json();
                if (!data.isSuccessful) {
                    if (data.errorReason === 'password') {
                        document.getElementById('password')?.classList.remove(styles.contentEmpty);
                        document.getElementById('password')?.classList.add(styles.contentIncorrect)
                    } else if (data.errorReason === 'login') {
                        document.getElementById('email')?.classList.remove(styles.contentEmpty);
                        document.getElementById('email')?.classList.add(styles.contentIncorrect)
                    }

                    return;
                }

                const { userData, type } = data;
                setUser(
                    type === 'STUDENT'
                        ? ({
                            ...userData,
                            password,
                            class: Number(userData.class),
                            exam: 'examData' in data
                                ? {
                                    phys: {
                                        currentMark: Number(data.examData.phys.mark),
                                        maxMark: Number(data.examData.phys.max_mark)
                                    },
                                    math: {
                                        currentMark: Number(data.examData.math.mark),
                                        maxMark: Number(data.examData.math.max_mark)
                                    },
                                    test: {
                                        currentMark: Number(data.examData.test.mark),
                                        maxMark: Number(data.examData.test.max_mark)
                                    },
                                }
                                : null,
                            uploadedDocuments: 'docs' in data
                                ? data.docs
                                : [],
                            type: 'student'
                        })
                        : ({
                            ...userData,
                            password,
                            type: 'admin'
                        })
                );
                navigate(
                    type === 'STUDENT'
                        ? '/dashboard'
                        : '/panel'
                );
            }
        )
    }

    useEffect(
        () => {
            formRef.current?.addEventListener(
                'submit',
                (e) => {
                    e.preventDefault();
                    if (
                        Array.from(                          //падает на телефоне(разница в движках)
                            isFormDataValid.current.values()
                        ).every(
                            (flag) => flag)
                    ) {
                        loginHandler(e);
                    } else {
                        setIsErrorsExist(true)
                    }
                }
            );
        },
        []
    );
}

export {
    useLogin
}