import { useRef, useState } from 'react';
import styles from './.module.css';
import { useLogin } from './LoginForm.hooks';
import { EmailInput } from '../Common/EmailInput/EmailInput';
import { PasswordInput } from '../Common/PasswordInput/PasswordInput';

const Form = () => {
    const isFormDataValid = useRef<Map<string, boolean>>(
        new Map([
            ['email', false],
            ['password', false]
        ])
    );
    console.log(isFormDataValid.current);
    const [isErrorsExist, setIsErrorsExist] = useState<boolean>(false);
    const formRef = useRef<HTMLFormElement | null>(null);

    useLogin(
        {
            isFormDataValid,
            formRef,
            setIsErrorsExist
        }
    );

    const inputDataChangeHandler = (key: string, value: boolean) => {
        isFormDataValid.current.set(key, value);
    }

    return (
        <form
            ref={formRef}
            className={styles.loginform}
            action='/login'
        >
            <div
                className={styles.inputsContainer}
            >
                <EmailInput
                    errorMode={isErrorsExist}
                    onDataChange={
                        (value: boolean) => {
                            inputDataChangeHandler('email', value)
                        }
                    }
                />

                <PasswordInput
                    errorMode={isErrorsExist}
                    type='login'
                    onDataChange={
                        (value: boolean) => {
                            inputDataChangeHandler('password', value)
                        }
                    }
                />

            </div>

            <div className={styles.lowerCont}>

                <button
                    id='submit'
                    type="submit"
                    className={styles.submit}
                >
                    {'Войти'}
                </button>
            </div>
        </form>
    );
}

export {
    Form
}