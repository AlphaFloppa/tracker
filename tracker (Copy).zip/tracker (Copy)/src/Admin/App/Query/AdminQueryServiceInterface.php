<?php

namespace App\Admin\App\Query;

use App\Admin\App\Admin;

interface AdminQueryServiceInterface
{
    public function findAdminByEmail(string $email): ?Admin;
}