import commonStyles from '../../Pages/.module.css';
import dashboardStyles from '../../.module.css';
import styles from './.module.css';
import { MarksPanel } from './MarksPanel/MarksPanel';
import { useDevice } from '../../../../../hooks/DeviceType.hooks';
import { Student } from '../../../../../types/User';
import { defineStageStatus } from '../../../../../components/Dashboard/Admin/Pages/Common/common';

type Props = {
    student: Student
}

const ExamsPage = (
    { student }: Props
) => {
    const { currentStage, exam: exams} = student;
    const isMobile = useDevice();

    return (
        !isMobile
            ? (
                <div className={`${dashboardStyles.infoContainer} ${styles.infoContainer}`}>
                    <div className={commonStyles.container}>
                        <div className={commonStyles.infoContainer}>
                            <span className={commonStyles.trackHeader}>{'Экзамены'}</span>
                            <span className={commonStyles.trackSubHeader}>{'Подробная информация об этом этапе:'}</span>
                            <span className={commonStyles.stageDesc}>{'Ты пишешь несколько работ: диагностическое тестирование и экзамен по физике и математике. Это поможет уточнить,подходит тебе обучение в лицее или нет.'}</span>
                            <div className={commonStyles.deadlinesStatusCont}>
                                <div className={commonStyles.deadlines}>
                                    <span className={commonStyles.deadlinesHeader}>{'Сроки:'}</span>
                                    <span className={commonStyles.deadlinesInfo}>{'01.06.26 - 15.07.26'}</span>
                                </div>
                                <div className={commonStyles.status}>
                                    <span className={commonStyles.statusHeader}>{'Статус этапа:'}</span>

                                    {
                                        defineStageStatus(currentStage)
                                    }
                                </div>
                            </div>

                        </div>
                        {
                            <MarksPanel exams = {exams}/>
                        }
                    </div>

                    <div className={commonStyles.arrowNext} id='nextPageBtn'></div>
                    <div className={commonStyles.arrowPrevious} id='previousPageBtn'></div>
                </div >
            )
            : (
                <>
                    <div className={`${commonStyles.infoContainer} ${commonStyles.mobile}`}>
                        <span className={commonStyles.trackHeader}>{'Экзамены'}</span>
                        <span className={commonStyles.trackSubHeader}>{'Подробная информация об этом этапе:'}</span>
                        <span className={commonStyles.stageDesc}>{'Ты пишешь несколько работ: диагностическое тестирование и экзамен по физике и математике. Это поможет уточнить,подходит тебе обучение в лицее или нет.'}</span>
                        <div className={commonStyles.deadlinesStatusCont}>
                            <div className={commonStyles.deadlines}>
                                <span className={commonStyles.deadlinesHeader}>{'Сроки:'}</span>
                                <span className={commonStyles.deadlinesInfo}>{'01.06.26 - 15.07.26'}</span>
                            </div>
                            <div className={commonStyles.status}>
                                <span className={commonStyles.statusHeader}>{'Статус этапа:'}</span>

                                <div className={commonStyles.status}>
                                    <span className={commonStyles.statusHeader}>{'Статус этапа:'}</span>

                                    {
                                        defineStageStatus(currentStage)
                                    }
                                </div>
                            </div>
                        </div>
                    </div>
                    {
                        <MarksPanel exams={exams}/>
                    }

                    <div className={commonStyles.arrowNext} id='nextPageBtn'></div>
                    <div className={commonStyles.arrowPrevious} id='previousPageBtn'></div>
                </>
            )
    )
}

export {
    ExamsPage
}