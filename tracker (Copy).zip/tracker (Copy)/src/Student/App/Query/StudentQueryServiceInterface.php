<?php

namespace App\Student\App\Query;

use App\Student\App\Student;

interface StudentQueryServiceInterface
{
    public function getStudents(array $classFilters, array $stageFilters, string $namePattern): array;
    
    public function findStudent(string $id): Student | null;

    public function findStudentByEmail(string $email): Student | null;

    public function getStudentDocuments(string $studentId): array | null;
}