<?php

namespace App\Controller;

use App\ServiceProvider;
use App\Student\API\StudentAPIInterface;
use App\Student\App\Student;
use App\User\User;
use Exception;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class StudentController extends AbstractController
{
    private StudentAPIInterface $studentAPI;

    public function __construct(
        ServiceProvider $provider
    )
    {
        $this->studentAPI = $provider->getStudentAPI();
    }

    public function getStudents(Request $request): Response
    {
        $classFilters = $request->query->all('class');
        $stageFilters = $request->query->all('stage');
        $namePattern = $request->query->get('name');
        $students = $this->studentAPI->getStudents($classFilters, $stageFilters, $namePattern);
        $studentsData = array_map(
            fn($student) => $student instanceof Student ? $student->hydrateStudentPublicData() : [],
            $students
        );
        return new JsonResponse(
            $studentsData
        );
    }

    public function findStudent(int $id): Response
    {
        $studentData = $this->studentAPI->findStudent($id);
        return new JsonResponse(
            $studentData->hydrateStudentData()
        );
    }

    public function storeDocuments(Request $request): Response
    {
        $user = $this->getUser();

        if(!$user instanceof User)
        {
            throw new Exception();
        }

        $studentId = $user->getUserIdentifier();

        $files = $request->files->get('files');
        $this->studentAPI->storeDocuments($studentId, $files);

        return new Response(Response::HTTP_OK);
    }
}