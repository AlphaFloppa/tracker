import { useEffect, useRef, useState } from 'react';
import styles from './.module.css';

type QuerySetter = {
    setQuery: Function
}

const SearchingRow = ({ setQuery }: QuerySetter) => {
    const isFocused = useRef<boolean>(false);
    const inputRef = useRef<HTMLInputElement | null>(null);

    const enterPressHandler = (e: KeyboardEvent) => {
        if (e.key === 'Enter' && isFocused.current) {
            setQuery(inputRef.current?.value ?? null)
        }
    }

    const escPressHandler = (e: KeyboardEvent) => {
        if (e.key === 'Escape' && isFocused.current) {
            if(inputRef.current === null){
                return;
            }

            inputRef.current.value = '';
            setQuery(null);
        }
    }

    useEffect(
        () => {
            window.addEventListener(
                'keydown',
                enterPressHandler
            );

            window.addEventListener(
                'keydown',
                escPressHandler
            );

            return () => {
                window.removeEventListener(
                    'keydown',
                    enterPressHandler
                );

                window.removeEventListener(
                    'keydown',
                    escPressHandler
                );
            }
        },
        []
    );

    return (
        <div className={styles.container}>
            <input
                ref={inputRef}
                onFocus={() => { isFocused.current = true }}
                onBlur={() => { isFocused.current = false }}
                className={styles.input}
                type="text"
                placeholder="Найти поступающего по ФИО"
            />
        </div>
    )
}

export {
    SearchingRow
}