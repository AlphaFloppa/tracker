<?php

namespace App\Controller;

use App\ServiceProvider;
use App\Common\Service\StagesDeadlines\Service\StagesDeadlinesService;
use App\User\User;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;

class StagesInfoController extends AbstractController
{
    private StagesDeadlinesService $stagesInfoService;
    
    public function __construct(
        ServiceProvider $provider
    ) {
        $this->stagesInfoService = $provider->getStagesDeadlinesService();
    }

    public function getStagesDeadlines(?string $studentId = null): Response
    {
        $data = null;

        if ($studentId !== null) {
            $data = $this->stagesInfoService->getStagesDeadlinesForStudent($studentId);
        } else {
            $user = $this->getUser();

            if (!$user instanceof User) {
                return new Response('', 500);
            }

            $userId = $user->getUserIdentifier();

            $data = $this->stagesInfoService->getStagesDeadlinesForStudent($userId);
        }
        
        return new JsonResponse(
            $data
        );
    }
}
