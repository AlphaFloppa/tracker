import { useState } from "react";
import styles from './.module.css';

type Props = {
    onClick: (isEditingActive: boolean) => void
}

const ChangeBtn = (
    { onClick }: Props
) => {
    const [isActive, setIsActive] = useState<boolean>(false);
    const clickHandler = () => {
        setIsActive(
            (currentState) => !currentState
        );

        onClick(isActive);
    }

    return (
        <div 
            className={ `${isActive ? styles.active : ''} ${styles.btn} `}
            onClick={clickHandler}
        >
        </div>
    );
}

export{
    ChangeBtn
}