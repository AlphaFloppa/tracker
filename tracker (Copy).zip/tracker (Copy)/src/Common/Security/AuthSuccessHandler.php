<?php

namespace App\Common\Security;

use App\Exam\API\ExamAPIInterface;
use App\ServiceProvider;
use App\Student\API\StudentAPIInterface;
use App\User\User;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Security\Http\Authentication\AuthenticationSuccessHandlerInterface;

class AuthSuccessHandler implements AuthenticationSuccessHandlerInterface
{
    private ExamAPIInterface $examAPI;
    private StudentAPIInterface $studentAPI;

    public function __construct(
        ServiceProvider $service_provider
    )
    {
        $this->studentAPI = $service_provider->getStudentAPI();
        $this->examAPI = $service_provider->getExamAPI();
    }

    public function onAuthenticationSuccess(Request $request, TokenInterface $token): ?Response
    {
        $user = $token->getUser();

        if(!$user instanceof User)
        {
            return new Response(
                '',
                502
            );
        }

        $role = $user->getRoles()[0];

        if($role === 'ROLE_ADMIN')
        {
            return new JsonResponse(
                [
                    'type' => 'ADMIN',
                    'userData' => $user->hydrateUserData(),
                    'isSuccessful' => true
                ]
            );
        }
        
        $userId = $user->getUserIdentifier();

        $exam = $this->examAPI->findExamByStudentId($userId);

        $documents = $this->studentAPI->getStudentDocuments($userId);

        return new JsonResponse(
            [
                'type' => 'STUDENT',
                'userData' => $user->hydrateUserData(),
                ...(
                    is_null($exam) 
                    ? [] 
                    : ['examData' => $exam->getMarks()]
                ),
                ...(
                    is_null($documents)
                    ? []
                    : ['docs' => $documents]
                ),
                'isSuccessful' => true
            ]
        );
    }
}
