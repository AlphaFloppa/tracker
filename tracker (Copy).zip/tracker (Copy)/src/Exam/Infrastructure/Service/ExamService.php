<?php

namespace App\Exam\Infrastructure\Service;

use App\Exam\App\Repository\ExamRepositoryInterface;
use App\Exam\App\Service\ExamServiceInterface;

class ExamService implements ExamServiceInterface
{
    public function __construct(
        private ExamRepositoryInterface $repository
    )
    {}

    public function setExamResultsByStudentId(string $id, array $results): void
    {
        $this->repository->setExamResults($id, $results);
    }
}