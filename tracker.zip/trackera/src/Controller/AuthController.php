<?php

namespace App\Controller;

use App\Exam\API\ExamAPIInterface;
use App\Meeting\API\MeetingAPIInterface;
use App\ServiceProvider;
use App\Student\API\StudentAPIInterface;
use App\Student\App\Student;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use App\User\User;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use App\Common\Service\StagesDeadlines\Service\StagesDeadlinesService;

class AuthController extends AbstractController
{

    private StudentAPIInterface $studentAPI;
    private ExamAPIInterface $examAPI;
    private MeetingAPIInterface $meetingAPI;
    private StagesDeadlinesService $stagesInfoService;

    public function __construct(
        ServiceProvider $provider
    ) {
        $this->studentAPI = $provider->getStudentAPI();
        $this->examAPI = $provider->getExamAPI();
        $this->meetingAPI = $provider->getMeetingAPI();
        $this->stagesInfoService = $provider->getStagesDeadlinesService();
    }

    public function register(Request $request, UserPasswordHasherInterface $hasher): Response
    {
        $role = $request->get('role');
        if ($role === 'STUDENT') {
            $student = new Student(
                uniqid(),
                $request->get('class'),
                $request->get('email'),
                $request->get('password'),
                $request->get('fullName'),
                $request->get('parentFullName'),
                $request->get('phone'),
                'documentsSubmission',
                'enroll'
            );

            $student->validate();

            $user = new User($student);

            $user->setPassword(
                $hasher->hashPassword($user, $user->getPassword())
            );

            $this->studentAPI->createStudent(
                $user->getUserDTO()
            );
        }

        return new Response(Response::HTTP_OK);
    }


    public function getUserInfo(): Response
    {
        $user = $this->getUser();

        if (!$user instanceof User) {
            return new Response('', 500);
        }

        $userId = $user->getUserIdentifier();
        $userRole = $user->getRoles()[0];

        if ($userRole === 'ROLE_STUDENT') {
            $stagesData = [];

            $stagesData['uploadedDocuments'] = $this->studentAPI->getStudentDocuments(
                $userId
            );

            $stagesData['exams'] = $this->examAPI->findExamByStudentId(
                $userId
            );

            $stagesData['meeting'] = $this->meetingAPI->getMeetingByStudentId(
                $userId
            );

            $stagesDeadlines = $this->stagesInfoService->getStagesDeadlinesForStudent($userId);

            return new JsonResponse(
                [
                    'type' => 'STUDENT',
                    'userData' => [
                        ...$user->hydrateUserData()
                    ],
                    'stagesData' => [
                        'docs' => $stagesData['uploadedDocuments'],
                        ...(
                            is_null($stagesData['exams'])
                            ? []
                            : [
                                'exams' => $stagesData['exams']->getMarks()
                            ]
                        ),
                        ...(
                            is_null($stagesData['meeting'])
                            ? []
                            : [
                                'meeting' => $stagesData['meeting']->getInfo()
                            ]
                        ),
                        'stagesDeadlines' => $stagesDeadlines,
                    ]
                ]
            );
        } 
        
        if($userRole === 'ROLE_ADMIN') {
            return new JsonResponse(
                [
                    'type' => 'ADMIN',
                    'userData' => [
                        ...$user->hydrateUserData()
                    ]
                ]
            );
        }
            
        return new Response('', 403);
    }
}
