<?php

namespace App\Common\Security;

use App\User\User;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Security\Core\Exception\AuthenticationException;
use Symfony\Component\Security\Core\Exception\UserNotFoundException;
use Symfony\Component\Security\Core\Exception\BadCredentialsException;
use Symfony\Component\Security\Http\Authentication\AuthenticationFailureHandlerInterface;


class AuthFailureHandler implements AuthenticationFailureHandlerInterface
{
    public function onAuthenticationFailure(Request $request, AuthenticationException $exception): Response
    {
        $errorReason = '';
        if($exception instanceof UserNotFoundException){
            $errorReason = 'login';
        } else if($exception instanceof BadCredentialsException){
            $errorReason = 'password';
        }
        return new JsonResponse(
            [
                'isSuccessful' => false,
                'errorReason' => $errorReason
            ]
        );
    }
}