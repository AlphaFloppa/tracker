import React, { useState, useRef, useEffect, forwardRef, ForwardedRef } from 'react';
import styles from './.module.css';
import formStyles from '../../RegisterForm/.module.css';

type Option = {
    value: string,
    label: string,
}

type CustomSelectProps = {
    onDataChange: Function,
    errorMode: boolean
}

const visibleAtWindowOptionsCount = 4;

const options = [
    { value: '11', label: '11 класс' },
    { value: '10', label: '10 класс' },
    { value: '9', label: '9 класс' },
    { value: '8', label: '8 класс' },
    { value: '7', label: '7 класс' },
    { value: '6', label: '6 класс' },
    { value: '5', label: '5 класс' },
    { value: '4', label: '4 класс' },
    { value: '3', label: '3 класс' },
    { value: '2', label: '2 класс' },
    { value: '1', label: '1 класс' },
];


const CustomSelect: React.FC<CustomSelectProps> = forwardRef(
    ({
        onDataChange
    }, ref: ForwardedRef<HTMLSelectElement | null>
    ) => {
        const [isOpen, setIsOpen] = useState(false);
        const error = useRef<'empty' | null>(null);
        const setError = (value: 'empty' | null) => {
            error.current = value;
        }
        const inputWrapperRef = useRef<HTMLDivElement | null>(null);
        const [selected, setSelected] = useState<Option | null>(null);
        const containerRef = useRef<HTMLDivElement>(null);
        const listRef = useRef<HTMLUListElement>(null);
        const hiddenSelectRef = useRef<HTMLSelectElement>(null);
        console.log(selected);
        const validate = () => {
            console.log(selected);
            if (selected === null) {
                inputWrapperRef.current?.classList.add(formStyles.contentEmpty)
                onDataChange(false)
                return
            }

            inputWrapperRef.current?.classList.remove(formStyles.contentEmpty);

            onDataChange(true)
        }

        const resetErrors = () => {
            inputWrapperRef.current?.classList.remove(formStyles.contentEmpty)
        }

        /*const onBlur = () => {
            if (selected === null) {
                setError('empty');
            } else {
                onDataChange(true);
            }
        }*/

        useEffect(
            () => {
                document.querySelector('#submit')?.addEventListener(
                    'click',
                    validate
                );

                document.querySelector('#trigger')?.addEventListener(
                    'click',
                    resetErrors
                )
            },
            [selected]
        )

        useEffect(() => {
            if (hiddenSelectRef.current && selected) {
                hiddenSelectRef.current.value = selected.value;
            }
        }, [selected]);

        useEffect(() => {
            const handleClickOutside = (event: MouseEvent) => {
                if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
                    setIsOpen(false);
                }
            };
            document.addEventListener('mousedown', handleClickOutside);
            return () => document.removeEventListener('mousedown', handleClickOutside);
        }, []);

        const handleSelect = (option: Option) => {
            setSelected(option);
            setIsOpen(false);

            if (hiddenSelectRef.current) {
                const event = new Event('change', { bubbles: true });
                hiddenSelectRef.current.dispatchEvent(event);
            }
        };

        return (
            <div
                className={
                    `
                        ${styles.customSelect}
                        ${formStyles.inputWrapper}
                    `
                }
                ref={
                    (node) => {
                        containerRef.current = node;
                        inputWrapperRef.current = node;
                    }
                }
            >
                <select
                    ref={
                        (node) => {
                            hiddenSelectRef.current = node;
                            if (ref && typeof ref !== "function") {
                                ref.current = node;
                            }
                        }
                    }
                    name='class'
                    value={selected?.value || ''}
                    onChange={() => { }}
                    style={{
                        position: 'absolute',
                        opacity: 0,
                        pointerEvents: 'none',
                        width: 0,
                        height: 0,
                        margin: 0,
                        padding: 0,
                        border: 'none',
                        overflow: 'hidden'
                    }}
                    aria-hidden="true"
                    tabIndex={-1}
                >
                    <option value="" disabled>Выберите</option>
                    {options.map(option => (
                        <option key={option.value} value={option.value}>
                            {option.label}
                        </option>
                    ))}
                </select>

                <div
                    id = 'trigger'
                    className={`${styles.selectTrigger} ${isOpen && styles.open} ${formStyles.input}`}
                    onClick={() => setIsOpen(!isOpen)}
                >
                    <span className={selected ? styles.selectedValue : styles.placeholder}>
                        {selected ? selected.label : 'Класс поступления'}
                    </span>
                    <div className={`${styles.arrow} ${isOpen ? styles.open : styles.closed}`} />
                </div>

                {
                    isOpen && (
                        <ul
                            className={styles.optionsList}
                            style={{ '--visible-items': visibleAtWindowOptionsCount } as React.CSSProperties}
                            ref={listRef}
                        >
                            {options.map(option => (
                                <li
                                    key={option.value}
                                    className={`${styles.option} ${selected?.value === option.value ? styles.selected : ''}`}
                                    onClick={() => handleSelect(option)}
                                >
                                    {option.label}
                                </li>
                            ))}
                        </ul>
                    )}
            </div>
        );
    }
);

export {
    CustomSelect,
    type CustomSelectProps,
}