<?php

namespace App\Admin\App;

use RuntimeException;

class Admin
{
    public function __construct(
        private string $id,
        private string $email,
        private string $password
    ) {}

    public function validate(): void 
    {
        if (
            !preg_match(
                '/^[a-zA-Z0-9.%_+\-$#]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/u',
                $this->email
            )
        ) {
            throw new RuntimeException('Invalid email');
        }
    }

    public function getId(): string
    {
        return $this->id;
    }

    public function getEmail(): string
    {
        return $this->email;
    }

    public function getPassword(): string
    {
        return $this->password;
    }

    public function setPassword(string $password): void
    {
        $this->password = $password;
    }

    public function hydrateAdminData(): array
    {
        return[
            'id' => $this->getId(),
            'email' => $this->getEmail(),
            'password' => $this->getPassword()
        ];
    }
}
