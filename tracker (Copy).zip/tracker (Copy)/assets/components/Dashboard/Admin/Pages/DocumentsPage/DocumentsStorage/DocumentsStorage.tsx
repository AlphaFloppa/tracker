import React, { forwardRef, useEffect, useImperativeHandle, useState } from 'react';
import styles from './.module.css';
import { useDocuments } from './DocumentsStorage.hooks';
import { useFetch } from '../../Common/.hooks';
import { useParams } from 'react-router-dom';

type SendingSubscriber = {
    sendFilesHandler: Function
}

const DocumentsStorage = forwardRef(
    (
        {}, ref
    ) => {
        const { id: studentId } = useParams() as { id: string };
        const [filesStorage, setFilesStorage] = useState<File[]>([]);
        const { storeDocsAsAdmin: storeDocs, validate } = useDocuments();

        useImperativeHandle(
            ref,
            () => (
                {
                    sendFilesHandler: () => {
                        storeDocs(filesStorage, studentId)?.then(
                            (isSuccessful) => {
                                if (!isSuccessful) {
                                    return;
                                }
                                setFilesStorage([]);
                            }
                        );
                    }
                }
            )
        );

        const inputChangeHandler = (e: React.ChangeEvent<HTMLInputElement>) => {
            if (e.target.files === null) {
                return;
            }
            const files = Array.from(e.target.files).filter(
                (file) => validate(file)
            );

            setFilesStorage(
                (filesStorage) => (
                    [
                        ...filesStorage,
                        ...files
                    ]
                )
            );
        }

        const removeFileHandler = (index: number) => {
            setFilesStorage(
                (filesStorage) => (
                    filesStorage.toSpliced(index, 1)
                )
            );
        }

        return (
            <div className={styles.documentCont}>
                <div className={styles.addBtn}>
                    <input
                        type="file"
                        className={styles.hiddenInput}
                        onChange={inputChangeHandler}
                        title=''
                    />
                    +
                </div>

                {
                    (filesStorage.length) === 0
                    && (
                        <div className={styles.placeholder}>{'Тут появится загруженный файл'}</div>
                    )
                }

                {
                    filesStorage.map(
                        (file, index) => (
                            <div key={index} className={styles.file}>
                                <span className={styles.fileName}>{file.name}</span>
                                <span className={styles.success}>{'Загружено'}</span>
                                <div
                                    className={styles.removeBtn}
                                    onClick={() => { removeFileHandler(index) }}
                                ></div>
                            </div>
                        )
                    )
                }
            </div>
        );
    }
);

export {
    DocumentsStorage
}

export type {
    SendingSubscriber
}