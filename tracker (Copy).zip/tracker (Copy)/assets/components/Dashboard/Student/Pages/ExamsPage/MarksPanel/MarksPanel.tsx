import { useUser } from '@/hooks/UserStorage.hooks';
import { ExamMark, Exams } from '../../../../../../types/Exam';
import styles from './.module.css';
import { stylishMark } from './common';
import { use } from 'react';

type Props = {
    exams: Exams | null
}
const MarksPanel = (
    {exams}: Props
) => {
    
    return (
        <div
            className={
                `
                    ${styles.marksCont}
                    ${exams === null ? styles.noMarks : ''}
                `
            }
        >
            <span className={styles.header}>
                {'Оценки'}
            </span>

            {
                exams === null
                    ? (
                        <span className={styles.noExamsMessage}>
                            {'Тут скоро появятся твои оценки за экзамены...'}
                        </span>
                    )
                    : (
                        <>
                            <div className={styles.subject} id='math'>
                                <span className={styles.subjectName}>{'Математика'}</span>
                                <div className={styles.marksContainer}>
                                    <>
                                        {
                                            <div
                                                className={
                                                    `
                                                                ${styles.mark} 
                                                                ${exams.math ? stylishMark(exams.math) : ''}
                                                            `
                                                }
                                            >
                                                {
                                                    exams.math?.currentMark
                                                }
                                            </div>
                                        }
                                        <div className={styles.maxMark}>
                                            <span className={styles.maxMarkLabel}>{'max'}</span>

                                            {
                                                <span
                                                    className={styles.maxMark}
                                                >
                                                    {
                                                        exams.math?.maxMark
                                                    }
                                                </span>
                                            }
                                        </div>
                                    </>
                                </div>
                            </div>

                            <div className={styles.subject} id='phys'>
                                <span className={styles.subjectName}>{'Физика'}</span>
                                <div className={styles.marksContainer}>
                                    <>
                                        {
                                            <div
                                                className={
                                                    `
                                                                ${styles.mark} 
                                                                ${exams.phys ? stylishMark(exams.phys) : ''}
                                                            `
                                                }
                                            >
                                                {
                                                    exams.phys?.currentMark
                                                }
                                            </div>
                                        }
                                        <div className={styles.maxMark}>
                                            <span className={styles.maxMarkLabel}>{'max'}</span>

                                            {
                                                <span
                                                    className={styles.maxMark}
                                                >
                                                    {
                                                        exams.phys?.maxMark
                                                    }
                                                </span>
                                            }
                                        </div>
                                    </>
                                </div>
                            </div>

                            <div className={styles.subject} id='test'>
                                <span className={styles.subjectName}>{'Диагностическое тестирование'}</span>
                                <div className={styles.marksContainer}>
                                    <>
                                        {
                                            <div
                                                className={
                                                    `
                                                                ${styles.mark} 
                                                                ${exams.test ? stylishMark(exams.test) : ''}
                                                            `
                                                }
                                            >
                                                {
                                                    exams.test?.currentMark
                                                }
                                            </div>
                                        }
                                        <div className={styles.maxMark}>
                                            <span className={styles.maxMarkLabel}>{'max'}</span>

                                            {
                                                <span
                                                    className={styles.maxMark}
                                                >
                                                    {
                                                        exams.test?.maxMark
                                                    }
                                                </span>
                                            }
                                        </div>
                                    </>
                                </div>
                            </div>
                        </>
                    )
            }
        </div >
    );
}

export {
    MarksPanel
}