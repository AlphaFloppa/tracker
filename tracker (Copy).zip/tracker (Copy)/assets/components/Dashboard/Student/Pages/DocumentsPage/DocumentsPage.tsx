import commonStyles from '../../Pages/.module.css';
import dashboardStyles from '../../.module.css';
import styles from './.module.css';
import { useUser } from '../../../../../hooks/UserStorage.hooks';
import { DocumentsStorage, SendingSubscriber } from './DocumentsStorage/DocumentsStorage';
import { useRef } from 'react';
import { stageToPageIndex } from '../../Dashboard';
import { useDevice } from '../../../../../hooks/DeviceType.hooks';
import { Student } from '../../../../../types/User';

type Props = {
    student: Student
}

const DocumentsPage = (
    { student }: Props
) => {
    const { currentStage } = student;
    const isMobile = useDevice();

    const filesStorageRef = useRef<SendingSubscriber | null>(null);
    return (
        !isMobile
            ? (
                <>
                    <div
                        className={
                            dashboardStyles.infoContainer
                        }>
                        <div className={commonStyles.container}>
                            <div className={commonStyles.infoContainer}>
                                <span className={commonStyles.trackHeader}>{'Подача документов'}</span>
                                <span className={commonStyles.trackSubHeader}>{'Подробная информация об этом этапе:'}</span>
                                <span className={commonStyles.stageDesc}>{'Если ты прошел все предыдущие этапы, мы присылаем тебе рекомендательное письмо, оно является гарантией поступления в лицей Инфотех'}</span>
                                <div className={commonStyles.deadlinesStatusCont}>
                                    <div className={commonStyles.deadlines}>
                                        <span className={commonStyles.deadlinesHeader}>{'Сроки:'}</span>
                                        <span className={commonStyles.deadlinesInfo}>{'01.06.26 - 15.07.26'}</span>
                                    </div>
                                    <div className={commonStyles.status}>
                                        <span className={commonStyles.statusHeader}>{'Статус этапа:'}</span>
                                        <span
                                            className={
                                                `
                                        ${commonStyles.statusValue} 
                                        ${stageToPageIndex(currentStage) < 1
                                                    ? commonStyles.unstarted
                                                    : stageToPageIndex(currentStage) === 1
                                                        ? commonStyles.unfinished
                                                        : commonStyles.finished
                                                }
                                    `
                                            }
                                        >
                                            {
                                                stageToPageIndex(currentStage) < 1
                                                    ? 'Не начато'
                                                    : stageToPageIndex(currentStage) === 1
                                                        ? 'В процессе'
                                                        : 'Пройдено'
                                            }
                                        </span>
                                    </div>
                                </div>
                            </div>

                            {
                                stageToPageIndex(currentStage) > 2
                                    ? (
                                        <div className={styles.loadCont}>
                                            <span className={styles.loadContHeader}>{'Загрузка документов'}</span>
                                            <span className={styles.stageFinishedMessage}>
                                                {'Ваши документы были успешно загружены и проверены. Этап с документами пройден!'}
                                            </span>
                                        </div>
                                    )
                                    : (
                                        <div className={styles.loadCont}>
                                            <span className={styles.loadContHeader}>{'Загрузка документов'}</span>
                                            <span className={styles.loadContSubHeader}>{'Тут вы можете прикрепить документы, необходимые для поступления'}</span>

                                            <DocumentsStorage
                                                studentDocumentsNames={student.uploadedDocuments}
                                                ref={filesStorageRef}
                                            />

                                            <div
                                                className={styles.sendBtn}
                                                onClick={
                                                    () => {
                                                        filesStorageRef.current?.sendFilesHandler()
                                                    }
                                                }
                                            >{'Отправить'}</div>
                                        </div>
                                    )
                            }
                        </div>

                        <div className={commonStyles.arrowNext} id='nextPageBtn'></div>
                        <div className={commonStyles.arrowPrevious} id='previousPageBtn'></div>
                    </div>
                </>
            )

            :
            (
                <>
                    <div className={
                        `
                            ${commonStyles.infoContainer}
                            ${commonStyles.mobile}
                        `
                    }>
                        <span className={commonStyles.trackHeader}>{'Подача документов'}</span>
                        <span className={commonStyles.trackSubHeader}>{'Подробная информация об этом этапе:'}</span>
                        <span className={commonStyles.stageDesc}>{'Если ты прошел все предыдущие этапы, мы присылаем тебе рекомендательное письмо, оно является гарантией поступления в лицей Инфотех'}</span>
                        <div className={commonStyles.deadlinesStatusCont}>
                            <div className={commonStyles.deadlines}>
                                <span className={commonStyles.deadlinesHeader}>{'Сроки:'}</span>
                                <span className={commonStyles.deadlinesInfo}>{'01.06.26 - 15.07.26'}</span>
                            </div>
                            <div className={commonStyles.status}>
                                <span className={commonStyles.statusHeader}>{'Статус этапа:'}</span>
                                <span
                                    className={
                                        `
                                        ${commonStyles.statusValue} 
                                        ${stageToPageIndex(currentStage) < 1
                                            ? commonStyles.unstarted
                                            : stageToPageIndex(currentStage) === 1
                                                ? commonStyles.unfinished
                                                : commonStyles.finished
                                        }
                                    `
                                    }
                                >
                                    {
                                        stageToPageIndex(currentStage) < 1
                                            ? 'Не начато'
                                            : stageToPageIndex(currentStage) === 1
                                                ? 'В процессе'
                                                : 'Пройдено'
                                    }
                                </span>
                            </div>
                        </div>

                        <div className={commonStyles.arrowNext} id='nextPageBtn'></div>
                        <div className={commonStyles.arrowPrevious} id='previousPageBtn'></div>
                    </div>

                    {
                        stageToPageIndex(currentStage) > 2
                            ? (
                                <div className={`${styles.loadCont} ${styles.mobile}`}>
                                    <span className={styles.loadContHeader}>{'Загрузка документов'}</span>
                                    <span className={styles.stageFinishedMessage}>
                                        {'Ваши документы были успешно загружены и проверены. Этап с документами пройден!'}
                                    </span>
                                </div>
                            )
                            : (
                                <div className={`${styles.loadCont} ${styles.mobile}`}>
                                    <span className={styles.loadContHeader}>{'Загрузка документов'}</span>
                                    <span className={styles.loadContSubHeader}>{'Тут вы можете прикрепить документы, необходимые для поступления'}</span>

                                    <DocumentsStorage
                                        studentDocumentsNames={student.uploadedDocuments}
                                        ref={filesStorageRef}
                                    />

                                    <div
                                        className={styles.sendBtn}
                                        onClick={
                                            () => {
                                                filesStorageRef.current?.sendFilesHandler()
                                            }
                                        }
                                    >{'Отправить'}</div>
                                </div>
                            )
                    }
                </>
            )
    )
}

export {
    DocumentsPage
}