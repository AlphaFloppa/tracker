import React, { useState, useRef, useEffect, forwardRef, ForwardedRef, ReactNode } from 'react';
import styles from './.module.css';
import formStyles from '../../RegisterForm/.module.css';

type Option = {
    value: string,
    label: ReactNode
}

type CustomSelectProps = {
    onSelect?: (value: string) => void,
    onDataChange?: (isValid: boolean) => void,
    options: Option[],
    placeholder: ReactNode,
    visibility?: number
}

const CustomSelect: React.FC<CustomSelectProps> = forwardRef(
    ({
        onSelect,
        onDataChange,
        options,
        placeholder,
        visibility = 4
    }, ref: ForwardedRef<HTMLSelectElement | null>
    ) => {
        const [isOpen, setIsOpen] = useState(false);
        const error = useRef<'empty' | null>(null);
        const setError = (value: 'empty' | null) => {
            error.current = value;
        }
        const inputWrapperRef = useRef<HTMLDivElement | null>(null);
        const [selected, setSelected] = useState<Option | null>(null);
        const containerRef = useRef<HTMLDivElement>(null);
        const listRef = useRef<HTMLUListElement>(null);
        const hiddenSelectRef = useRef<HTMLSelectElement>(null);
        const validate = () => {
            if (selected === null) {
                inputWrapperRef.current?.classList.add(formStyles.contentEmpty)
                onDataChange?.(false)
                return
            }

            inputWrapperRef.current?.classList.remove(formStyles.contentEmpty);

            onDataChange?.(true)
        }

        const resetErrors = () => {
            inputWrapperRef.current?.classList.remove(formStyles.contentEmpty)
        }

        useEffect(
            () => {
                document.querySelector('#submit')?.addEventListener(
                    'click',
                    validate
                );

                document.querySelector('#trigger')?.addEventListener(
                    'click',
                    resetErrors
                )
            },
            [selected]
        )

        useEffect(() => {
            if (hiddenSelectRef.current && selected) {
                hiddenSelectRef.current.value = selected.value;
            }
        }, [selected]);

        useEffect(() => {
            const handleClickOutside = (event: MouseEvent) => {
                if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
                    setIsOpen(false);
                }
            };
            document.addEventListener('mousedown', handleClickOutside);
            return () => document.removeEventListener('mousedown', handleClickOutside);
        }, []);

        const handleSelect = (option: Option) => {
            setSelected(option);
            setIsOpen(false);
            onSelect?.(option.value);

            if (hiddenSelectRef.current) {
                const event = new Event('change', { bubbles: true });
                hiddenSelectRef.current.dispatchEvent(event);
            }
        };

        return (
            <div
                className={
                    `
                        ${styles.customSelect}
                        ${formStyles.inputWrapper}
                    `
                }
                ref={
                    (node) => {
                        containerRef.current = node;
                        inputWrapperRef.current = node;
                    }
                }
            >
                <select
                    ref={
                        (node) => {
                            hiddenSelectRef.current = node;
                            if (ref && typeof ref !== "function") {
                                ref.current = node;
                            }
                        }
                    }
                    name='class'
                    value={selected?.value || ''}
                    onChange={() => { }}
                    style={{
                        position: 'absolute',
                        opacity: 0,
                        pointerEvents: 'none',
                        width: 0,
                        height: 0,
                        margin: 0,
                        padding: 0,
                        border: 'none',
                        overflow: 'hidden'
                    }}
                    aria-hidden="true"
                    tabIndex={-1}
                >
                    <option value="" disabled>Выберите</option>
                    {options.map(option => (
                        <option key={option.value} value={option.value}>
                        </option>
                    ))}
                </select>

                <div
                    id = 'trigger'
                    className={`${styles.selectTrigger} ${isOpen && styles.open} ${formStyles.input}`}
                    onClick={() => setIsOpen(!isOpen)}
                >
                    {selected ? selected.label : placeholder}

                    <div className={`${styles.arrow} ${isOpen ? styles.open : styles.closed}`} />
                </div>

                {
                    isOpen && (
                        <ul
                            className={styles.optionsList}
                            style={{ '--visible-items': visibility } as React.CSSProperties}
                            ref={listRef}
                        >
                            {options.map(option => (
                                <li
                                    key={option.value}
                                    className={`${styles.option} ${selected?.value === option.value ? styles.selected : ''}`}
                                    onClick={() => handleSelect(option)}
                                >
                                    {option.label}
                                </li>
                            ))}
                        </ul>
                    )}
            </div>
        );
    }
);

export {
    CustomSelect,
    type CustomSelectProps,
}