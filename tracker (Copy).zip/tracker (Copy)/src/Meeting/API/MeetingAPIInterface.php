<?php

namespace App\Meeting\API;

use App\Meeting\App\Meeting;

interface MeetingAPIInterface
{
    public function getMeetingByStudentId(string $studentId): ?Meeting;

    public function storeMeeting(Meeting $meeting): void;
}