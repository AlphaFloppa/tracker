import { Interview } from "../../../../../../types/Interview"
import { useState, useEffect } from "react"
import { useFetch } from "../../Common/.hooks"
import { useParams } from "react-router-dom"
import { ChangeBtn } from "../../../../../AdminPanel/MakeChangeBtn/MakeChangeBtn"
import { DateInput } from "./DateInput/DateInput"
import { TimeInput } from "./TimeInput/TimeInput"
import { useChangingStudent } from "../../../hooks"

const InterviewPanel = (
) => {
    const {value: student, setValue: setStudent} = useChangingStudent();
    const [interview, setInterview] = useState<Interview | null>(student.interview);
    const formattedTime = interview?.datetime.getHours() + ':' + interview?.datetime.getMinutes();
    const formattedDate = [
        interview?.datetime.getDay(),
        interview?.datetime.getMonth(),
        interview?.datetime.getFullYear(),
    ].join('.');

    const [isEditingEnabled, setIsEditingEnabled] = useState<boolean>(false);

    return (
        <>
            <span>
                {'Собеседование'}

                <ChangeBtn
                    onClick={
                        (isEnabled: boolean) => {
                            setIsEditingEnabled(!isEnabled)
                        }
                    } />
            </span>
            {
                interview !== null &&
                (
                    isEditingEnabled
                        ? (
                            <>
                                <DateInput
                                    onBlur={() => {}}
                                    initialDay={interview.datetime.getDay().toString()}
                                    initialMonth={interview.datetime.getMonth().toString()}
                                />

                                <TimeInput
                                    initialHour={interview.datetime.getHours().toString()}
                                    initialMinute={interview.datetime.getMinutes().toString()}
                                />
                            </>
                        )
                        : (
                            <>
                                <label>
                                    {'Дата'}
                                    <span>
                                        {formattedDate}
                                    </span>
                                </label>

                                <label>
                                    {'Время'}
                                    <span>
                                        {formattedTime}
                                    </span>
                                </label>
                            </>
                        )
                )
            }

            {
                interview !== null && (
                    <label>
                        {'Ссылка'}
                        <span>
                            {interview?.link}
                        </span>
                    </label>
                )
            }
        </>
    );
}

export {
    InterviewPanel
}