<?php

namespace App\Student\App\Repository;

use App\Student\App\Student;

interface StudentRepositoryInterface
{
    public function createStudent(Student $student): void;

    public function deleteStudent(string $id): void;

    public function updateStudentPassword(string $id, string $password): void;

    /**
     * @param array $documents array of already stored Files
     */
    public function saveStudentDocuments(string $studentId, array $documents): void;

    public function setStudentStage(string $studentId, string $newStage): void;

    public function setStudentStatus(string $studentId, string $newStatus): void;
}