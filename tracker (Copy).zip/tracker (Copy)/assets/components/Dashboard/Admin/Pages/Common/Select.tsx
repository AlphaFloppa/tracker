import React, { useState, useRef, useEffect, forwardRef, ForwardedRef, ReactNode } from 'react';
import styles from './.module.css';

type Option = {
    value: string,
    label: ReactNode
}

type CustomSelectProps = {
    onSelect?: (value: string) => void,
    options: Option[],
    placeholder: Option,
    visibility?: number
}

const CustomSelect: React.FC<CustomSelectProps> = forwardRef(
    ({
        onSelect,
        options,
        placeholder,
        visibility = 4
    }, ref: ForwardedRef<HTMLSelectElement | null>
    ) => {
        const [isOpen, setIsOpen] = useState(false);
        const inputWrapperRef = useRef<HTMLDivElement | null>(null);
        const [selected, setSelected] = useState<Option>(placeholder);
        const containerRef = useRef<HTMLDivElement>(null);
        const listRef = useRef<HTMLUListElement>(null);
        const hiddenSelectRef = useRef<HTMLSelectElement>(null);

        useEffect(() => {
            if (hiddenSelectRef.current && selected) {
                hiddenSelectRef.current.value = selected.value;
            }
        }, [selected]);

        useEffect(() => {
            const handleClickOutside = (event: MouseEvent) => {
                if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
                    setIsOpen(false);
                }
            };
            document.addEventListener('mousedown', handleClickOutside);
            return () => document.removeEventListener('mousedown', handleClickOutside);
        }, []);

        const handleSelect = (option: Option) => {
            setSelected(option);
            setIsOpen(false);
            onSelect?.(option.value);

            if (hiddenSelectRef.current) {
                const event = new Event('change', { bubbles: true });
                hiddenSelectRef.current.dispatchEvent(event);
            }
        };

        return (
            <div
                className={styles.customSelect}
                ref={
                    (node) => {
                        containerRef.current = node;
                        inputWrapperRef.current = node;
                    }
                }
            >

                <div
                    id='trigger'
                    className={styles.selectTrigger}
                    onClick={() => setIsOpen(!isOpen)}
                >
                    {selected ? selected.label : placeholder.label}

                    <div className={`${styles.arrow} ${isOpen ? styles.open : styles.closed}`} />
                </div>

                {
                    (
                        <ul
                            className={styles.optionsList}
                            style={
                                { 
                                    '--visible-items': visibility,
                                    ...{
                                        visibility: isOpen ? 'visible' : 'hidden'
                                    }
                                } as React.CSSProperties
                            }
                            ref={listRef}
                        >
                            {
                                options
                                .filter(
                                    (option) => option.value !== selected?.value
                                )
                                .map(
                                    option => (
                                        <li
                                            key={option.value}
                                            className={`${styles.option} ${selected?.value === option.value ? styles.selected : ''}`}
                                            onClick={() => handleSelect(option)}
                                        >
                                            {option.label}
                                        </li>
                                    )
                                )
                            }
                        </ul>
                    )}
            </div>
        );
    }
);

export {
    CustomSelect,
    type CustomSelectProps,
}