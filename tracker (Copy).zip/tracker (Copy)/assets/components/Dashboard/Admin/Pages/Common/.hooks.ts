import { StudentData } from "@/types/User";
import { Exams } from "../../../../../types/Exam";
import { Interview } from "../../../../../types/Interview";
import type { MutableStudentData } from "../../Dashboard";

const fetchDocuments = async (studentId: string): Promise<string[]> => {
    return fetch(
        `/documents/${studentId}`,
        {
            method: 'GET'
        }
    ).then(
        async (response) => {
            if (!response.ok) {
                return []
            }
            const documentsNames = await response.json();
            return documentsNames as string[]
        }
    )
}

const fetchExams = async (studentId: string): Promise<Exams | null> => {
    return fetch(
        `/exams/${studentId}`,
        {
            method: 'GET'
        }
    ).then(
        async (response) => {
            if (!response.ok) {
                return null
            }
            const marks = await response.json();
            return marks as Exams
        }
    )
}

const fetchMeeting = async (studentId: string): Promise<Interview | null> => {
    return fetch(
        `/interview/${studentId}`,
        {
            method: 'GET'
        }
    ).then(
        async (response) => {
            if (!response.ok) {
                return null
            }
            const { datetime, link } = await response.json() as { datetime: number, link: string };
            const formattedDatetime = new Date(datetime * 1000);
            formattedDatetime.setMinutes(
                formattedDatetime.getMinutes() + formattedDatetime.getTimezoneOffset()
            )
            return {
                datetime: formattedDatetime,
                link
            } as Interview
        }
    )
}

const loadMutableStudentData = async (studentData: StudentData): Promise<StudentData> => {
    const docNames = await fetchDocuments(studentData.id);
    const exams = await fetchExams(studentData.id);
    const interview = await fetchMeeting(studentData.id);
    return {
        ...studentData,
        uploadedDocuments: docNames,
        exam: exams,
        interview
    }
}

const useFetch = (
    studentId: string
) => (
    {
        fetchExams: () => fetchExams(studentId),
        fetchMeeting: () => fetchMeeting(studentId),
        fetchDocuments: () => fetchDocuments(studentId),
        loadMutableStudentData
    }
);



const isStudentMutated = (studentData: StudentData, mutatedStudent: StudentData) => {
    return !(
        studentData.interview?.datetime === mutatedStudent.interview?.datetime &&
        studentData.interview?.link === mutatedStudent.interview?.link &&
        studentData.uploadedDocuments.length === mutatedStudent.uploadedDocuments.length &&
        studentData.currentStage === mutatedStudent.currentStage &&
        studentData.exam?.math?.currentMark === mutatedStudent.exam?.math?.currentMark &&
        studentData.exam?.math?.maxMark === mutatedStudent.exam?.math?.maxMark &&
        studentData.exam?.phys?.currentMark === mutatedStudent.exam?.phys?.currentMark &&
        studentData.exam?.phys?.maxMark === mutatedStudent.exam?.phys?.maxMark &&
        studentData.exam?.test?.currentMark === mutatedStudent.exam?.test?.currentMark &&
        studentData.exam?.test?.maxMark === mutatedStudent.exam?.test?.maxMark
    );
}

const storeMutatedStudent = (studentData: StudentData, mutatedStudent: MutableStudentData) => {
    if(!isStudentMutated(studentData, mutatedStudent)){
        return
    }

    fetch(
        `/student/update`,
        {
            method: 'POST',
            body: JSON.stringify(mutatedStudent)
        }
    )
}

const useStore = () => {
    return {
        storeMutatedStudent
    }
}

export {
    useFetch,
    useStore
}