import styles from './.module.css';
import type { ActiveMode } from '../DocumentsPage';

type SwitcherPropsType = {
    currentMode: ActiveMode,
    toggleMode: Function
}

const Switcher = ({currentMode, toggleMode}: SwitcherPropsType) => {
    const modeChangeHandler = ({ currentTarget }: React.MouseEvent) => {
        if (currentTarget.classList.contains(styles.active)) {
            return;
        }

        toggleMode();
    }
    return (
        <div className = {styles.switcher}>
            <span 
                onClick={modeChangeHandler}
                className = {
                    `
                        ${styles.label}
                        ${styles.view}
                        ${
                            currentMode === 'view'
                            && styles.active
                        }
                    `
                }>
                {'Скачать'}
            </span>
            <span 
                onClick={modeChangeHandler}
                className = {
                    `
                        ${styles.label}
                        ${styles.load}
                        ${
                            currentMode === 'load'
                            && styles.active
                        }
                    `
            }>
                {'Загрузить'}
            </span>
        </div>
    );
}

export{
    Switcher
}