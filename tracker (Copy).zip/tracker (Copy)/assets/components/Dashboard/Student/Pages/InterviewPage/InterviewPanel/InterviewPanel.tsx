import { Interview } from "../../../../../../types/Interview"

type Props = {
    interview: Interview | null
}

const InterviewPanel = (
    { interview }: Props
) => {
    const formattedTime = interview?.datetime.getHours() + ':' + interview?.datetime.getMinutes();
    const formattedDate = [
        interview?.datetime.getDay(),
        interview?.datetime.getMonth(),
        interview?.datetime.getFullYear(),
    ].join('.');

    return (
        <div>
            {'Собеседование'}
            {
                interview === null
                    ? (
                        <span>
                            {'Здесь появятся назначенное время для собеседования'}
                        </span>
                    )
                    : (
                        <>
                            <label>
                                {'Дата'}
                                <span>
                                    {formattedDate}
                                </span>
                            </label>

                            <label>
                                {'Время'}
                                <span>
                                    {formattedTime}
                                </span>
                            </label>

                            <label>
                                {'Ссылка'}
                                <span>
                                    {interview?.link}
                                </span>
                            </label>
                        </>
                    )
            }
        </div>
    );
}

export {
    InterviewPanel
}