import styles from './.module.css';
import { FilterPanel } from './FilterPanel/FilterPanel';
import { SearchingRow } from './SearchingRow/SearchingRow';
import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ProfileSidebar } from '../Dashboard/Student/ProfileSidebar/Student/ProfileSidebar';
import { useUser } from '../../hooks/UsersStorage.hooks';
import { Student, StudentData } from '../../types/User';
import { StudentCard } from './StudentCard/StudentCard';
import { useStudentsData } from './AdminPanel.hooks';

const AdminPanel = () => {
    const { user } = useUser();
    const navigate = useNavigate();

    const [classFilters, setClassFilters] = useState<Array<string>>(
        ['11', '10', '9', '8']
    );
    const [stageFilters, setStageFilters] = useState<Array<string>>(
        ['documentsSubmission', 'exams', 'interview', 'final']
    );
    const [searchingQuery, setSearchingQuery] = useState<string | null>(null);
    const [students, setStudents] = useState<StudentData[]>([]);
    useStudentsData(
        {
            classFilters,
            stageFilters,
            studentNameQuery: searchingQuery,
            setResult: setStudents
        }
    );
    const [selection, setSelection] = useState<Array<string>>([]);
    const [isProfileOpen, setIsProfileOpen] = useState<boolean>(false);
    const containerRef = useRef<HTMLDivElement | null>(null);

    const studentClickHandler = (clickedStudentId: string) => {
        setSelection(
            (currentSelectionState) => {
                const isUnselected = selection.some(
                    (selectedId) => selectedId === clickedStudentId
                );

                if(isUnselected){
                    return [...currentSelectionState].filter(
                        (selectedId) => selectedId !== clickedStudentId 
                    )
                } else {
                    return [
                        ...currentSelectionState,
                        clickedStudentId
                    ]
                }
            }
        )
    }

    const selectAllStudentsHandler = () => {
        setSelection(
            students.map(
                ({id}) => id
            )
        );
    }

    const profileOpenHandler = () => {
        setIsProfileOpen(true);
        containerRef.current?.classList.add(
            styles.overlay
        );
    }

    const profileCloseHandler = () => {
        setIsProfileOpen(false);
        containerRef.current?.classList.remove(
            styles.overlay
        );
    }

    useEffect(
        () => {
            if (user === null) {
                navigate('/sign')
            }
        }
    )

    if (user === null || user.type !== 'admin') {
        return;
    }

    return (
        <div
            className={styles.mainContainer}
            ref={containerRef}
        >
            <div className={styles.header}>
                <div className={styles.logo}></div>
                <div
                    className={styles.profileIcon}
                    onClick={profileOpenHandler}
                >
                </div>
            </div>

            <FilterPanel
                setClassFilters={setClassFilters}
                setStageFilters={setStageFilters}
            />

            <div className={styles.studentsViewer}>
                <span className={styles.counter}>
                    {
                        searchingQuery === null
                            ? `Всего поступающих: ${students.length}`
                            : `Результаты поиска: ${students.length}`
                    }
                </span>

                <div 
                    className={styles.selectAllStudentsBtn}
                    onClick={selectAllStudentsHandler}
                >
                    {'Выбрать все'}
                </div>
                <SearchingRow
                    setQuery={setSearchingQuery}
                />
                <div className={styles.contentContainer}>
                    <div className={styles.labels}></div>
                    <ul className={styles.studentsList}>
                        {
                            students.map(
                                (studentData) => (
                                    <li
                                        key={studentData.id}
                                        className={styles.studentLItem}
                                    >
                                        <div
                                            className={
                                                `
                                                    ${styles.selectStudentCardBtn}
                                                    ${
                                                        selection.some(
                                                            (selectedId) => studentData.id === selectedId 
                                                        ) 
                                                        ? styles.selected
                                                        : ''
                                                    }
                                                `
                                            }
                                            onClick={
                                                () => {
                                                    studentClickHandler(studentData.id)
                                                }
                                            }
                                        >
                                        </div>
                                        <StudentCard studentData={studentData} />
                                    </li>
                                )
                            )
                        }
                    </ul>
                </div>

                <div className={styles.selectAllBtn}></div>
            </div>

            {
                isProfileOpen &&
                <ProfileSidebar
                    onClose={profileCloseHandler}
                />
            }
        </div>
    );
}
export {
    AdminPanel
}