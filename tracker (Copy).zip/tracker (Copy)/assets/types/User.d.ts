import { ExamMark, Exams } from "./Exam";
import { Interview } from "./Interview";
import type { Stage } from "./Stage";

type Student = {
    type: 'student',
    password: string,
    id: string,
    class: number,
    email: string,
    fullName: string,
    parentName: string,
    phone: string,
    currentStage: Stage,
    exam: Exams | null,
    uploadedDocuments: Array<string>,
    interview: Interview | null
}

type StudentData = Omit<Student, 'password'>

type Admin = {
    type: 'admin',
    email: string,
    password: string,
    id: string,
    fullName: string
}

type User = Student | Admin

export type {
    Student, 
    StudentData,
    Admin,
    User
}