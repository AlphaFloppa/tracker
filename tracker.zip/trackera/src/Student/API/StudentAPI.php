<?php

namespace App\Student\API;

use App\Common\Service\DocumentService;
use App\Student\App\Student;
use App\Student\App\Service\StudentServiceInterface;
use App\Student\API\StudentAPIInterface;
use App\Student\App\Query\StudentQueryServiceInterface;
use Override;

class StudentAPI implements StudentAPIInterface
{
    public function __construct(
        private StudentServiceInterface $service,
        private StudentQueryServiceInterface $queryService,
        private DocumentService $documentService
    )
    {
    }

    public function getStudents(
        array $classFilters,
        array $stageFilters,
        ?string $namePattern
    ): array
    {
        return $this->queryService->getStudents($classFilters, $stageFilters, $namePattern);
    }

    public function createStudent(Student $student): void
    {
        $this->service->createStudent($student);
    }

    public function findStudent(string $id): Student
    {
        return $this->queryService->findStudent($id);
    }

    public function deleteStudent(string $id): void
    {
        $this->service->deleteStudent($id);
    }

    public function updateStudentPassword(string $id, string $password): void
    {
        $this->service->updateStudentPassword($id, $password);        
    }

    public function storeDocuments(string $studentId, array $documents): void
    {
        $storedFiles = $this->documentService->saveDocuments($documents);
        $this->service->storeStudentDocs($studentId, $storedFiles);
    }

    public function getStudentDocuments(string $studentId): array | null
    {
        return $this->queryService->getStudentDocuments($studentId);
    }

    public function setStudentStage(Student $student, string $newStage): void
    {
        if($student->getCurrentStage() === $newStage) {
            return;
        }
        
        $this->service->setStudentStage($student->getId(), $newStage);
    }

    public function setStudentStatus(string $studentId, string $newStatus): void
    {
        $this->service->setStudentStatus($studentId, $newStatus);
    }
}