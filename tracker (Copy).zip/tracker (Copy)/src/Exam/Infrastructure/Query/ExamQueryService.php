<?php

namespace App\Exam\Infrastructure\Query;

use App\Exam\App\Exam;
use App\Exam\App\Query\ExamQueryServiceInterface;
use PDO;

class ExamQueryService implements ExamQueryServiceInterface
{
    public function __construct(
        private PDO $pdo
    ) {}

    public function findExamByStudentId(string $id): ?Exam
    {
        $query = <<<SQL
            SELECT * FROM exam_mark
            WHERE student_id = :id
        SQL;

        $stmt = $this->pdo->prepare($query);
        $stmt->execute(
            [
                'id' => $id
            ]
        );

        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (count($data) === 0) {
            return null;
        }

        $physMark = array_values(
            array_filter(
                $data,
                fn($record) => $record['subject'] === 'phys'
            )
        )[0];

        $mathMark = array_values(
            array_filter(
                $data,
                fn($record) => $record['subject'] === 'math'
            )
        )[0];

        $testMark = array_values(
            array_filter(
                $data,
                fn($record) => $record['subject'] === 'test'
            )
        )[0];

        return new Exam(
            $physMark,
            $mathMark,
            $testMark
        );
    }
}
