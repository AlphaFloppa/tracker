import { useEffect, useRef, useState } from 'react';
import styles from './.module.css';
import { useRegister } from './RegisterForm.hooks';
import { CustomSelect } from '../Common/Select/Select';
import { NameInput } from '../Common/NameInput/NameInput';
import { PhoneInput } from '../Common/PhoneInput/PhoneInput';
import { PasswordInput } from '../Common/PasswordInput/PasswordInput';
import { EmailInput } from '../Common/EmailInput/EmailInput';

const Form = () => {
    const isFormDataValid = useRef<Map<string, boolean>>(
        new Map([
            ['email', false],
            ['password', false],
            ['name', false],
            ['parentName', false],
            ['class', false],
            ['phone', false]
        ])
    );
    const [isErrorsExist, setIsErrorsExist] = useState<boolean>(false);
    const formRef = useRef<HTMLFormElement | null>(null);

    useRegister(
        {
            isFormDataValid,
            formRef,
            setIsErrorsExist
        }
    );

    const inputDataChangeHandler = (key: string, value: boolean) => {
        isFormDataValid.current.set(key, value);
    }

    return (
        <form
            ref={formRef}
            className={styles.registerform}
            action='/register'
        >
            <div className={styles.inputsContainer}>
                <input
                    type='hidden'
                    name='role'
                    value='STUDENT'
                />

                <NameInput
                    errorMode = {isErrorsExist}
                    onDataChange={
                        (value: boolean) => {
                            inputDataChangeHandler('name', value)
                        }
                    }
                    type='studentName'
                />

                <NameInput
                    errorMode={isErrorsExist}
                    onDataChange={
                        (value: boolean) => {
                            inputDataChangeHandler('parentName', value)
                        }
                    }
                    type='parentName'
                />

                <div className={styles.horizontalContainer}>
                    <CustomSelect
                        errorMode={isErrorsExist}
                        onDataChange={
                            (value: boolean) => {
                                inputDataChangeHandler('class', value)
                            }
                        }
                    />

                    <PhoneInput
                        errorMode={isErrorsExist}
                        onDataChange={
                            (value: boolean) => {
                                inputDataChangeHandler('phone', value)
                            }
                        }
                    />
                </div>

                <EmailInput
                    errorMode={isErrorsExist}
                    onDataChange={
                        (value: boolean) => {
                            inputDataChangeHandler('email', value)
                        }
                    }
                />

                <PasswordInput
                    errorMode={isErrorsExist}
                    onDataChange={
                        (value: boolean) => {
                            inputDataChangeHandler('password', value)
                        }
                    }
                    type='register'
                />
            </div>

            <div className={styles.lowerCont}>
                <span
                    className={styles.conventions}
                >
                    {'Отправляя форму, вы соглашаетесь на обработку персональных данных.'}
                </span>

                <button
                    id = 'submit'
                    type="submit"
                    className={styles.submit}
                >
                    {'Войти'}
                </button>
            </div>
        </form>
    );
}

export {
    Form
}