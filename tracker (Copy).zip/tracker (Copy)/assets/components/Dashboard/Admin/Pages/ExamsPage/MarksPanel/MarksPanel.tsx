import { ChangeBtn } from '../../../../../AdminPanel/MakeChangeBtn/MakeChangeBtn';
import { ExamMark, Exams } from '../../../../../../types/Exam';
import styles from './.module.css';
import { useState, useEffect } from 'react';
import { stylishMark } from './common';
import { useParams } from 'react-router-dom';
import { useChangingStudent } from '../../../hooks';

type EditingMode = false | 'marks'

const MarksPanel = () => {
    const {value: student, setValue: setStudent} = useChangingStudent();
    const {exam: exams} = student;
    const [editingMode, setEditingMode] = useState<EditingMode>(false);

    const setMarksEditMode = (isEditModeEnabled: boolean) => {
        setEditingMode(
            isEditModeEnabled
                ? false
                : 'marks'
        );
    }

    return (
        <div
            className={
                `
                    ${styles.marksCont}
                    ${exams === null ? styles.noMarks : ''}
                `
            }
        >
            <span className={styles.header}>
                {'Оценки'}
                <ChangeBtn onClick={setMarksEditMode} />
            </span>

            {
                exams === null
                    ? (
                        <span className={styles.noExamsMessage}>
                            {'Тут скоро появятся твои оценки за экзамены...'}
                        </span>
                    )
                    : (
                        <>
                            <div className={styles.subject} id='math'>
                                <span className={styles.subjectName}>{'Математика'}</span>
                                <div className={styles.marksContainer}>
                                    <>
                                        {
                                            editingMode === false
                                                ? (
                                                    <div
                                                        className={
                                                            `
                                                                ${styles.mark} 
                                                                ${exams.math ? stylishMark(exams.math): ''}
                                                            `
                                                        }
                                                    >
                                                        {
                                                            exams.math?.currentMark
                                                        }
                                                    </div>
                                                )
                                                : (
                                                    <input
                                                        type='number'
                                                        defaultValue={exams.math?.currentMark}
                                                        onChange={() => { }}
                                                        onBlur={
                                                            ({ currentTarget: { value } }) => {
                                                                setStudent(
                                                                    {
                                                                        ...student,
                                                                        exam: {
                                                                            ...student.exam,
                                                                            math: {
                                                                                currentMark: Number(value),
                                                                                maxMark: student.exam?.math?.maxMark ?? 0
                                                                            }
                                                                        }
                                                                    }
                                                                );
                                                            }
                                                        }
                                                    />
                                                )
                                        }
                                        <div className={styles.maxMark}>
                                            <span className={styles.maxMarkLabel}>{'max'}</span>

                                            {
                                                editingMode === false
                                                    ? (
                                                        <span
                                                            className={styles.maxMark}
                                                        >
                                                            {
                                                                exams.math?.maxMark
                                                            }
                                                        </span>
                                                    )
                                                    : (
                                                        <input
                                                            type='number'
                                                            defaultValue={exams.math?.maxMark}
                                                            onChange={() => { }}
                                                            onBlur={
                                                                ({ currentTarget: { value } }) => {
                                                                    setStudent(
                                                                        {
                                                                            ...student,
                                                                            exam: {
                                                                                ...student.exam,
                                                                                math: {
                                                                                    currentMark: student.exam?.math?.currentMark ?? 0,
                                                                                    maxMark: Number(value)
                                                                                }
                                                                            }
                                                                        }
                                                                    );
                                                                }
                                                            }
                                                        />
                                                    )
                                            }
                                        </div>
                                    </>
                                </div>
                            </div>

                            <div className={styles.subject} id='phys'>
                                <span className={styles.subjectName}>{'Физика'}</span>
                                <div className={styles.marksContainer}>
                                    <>
                                        {
                                            editingMode === false
                                                ? (
                                                    <div
                                                        className={
                                                            `
                                                                ${styles.mark} 
                                                                ${exams.phys ? stylishMark(exams.phys): ''}
                                                            `
                                                        }
                                                    >
                                                        {
                                                            exams.phys?.currentMark
                                                        }
                                                    </div>
                                                )
                                                : (
                                                    <input
                                                        type='number'
                                                        defaultValue={exams.phys?.currentMark}
                                                        onChange={() => { }}
                                                        onBlur={
                                                            ({ currentTarget: { value } }) => {
                                                                setStudent(
                                                                    {
                                                                        ...student,
                                                                        exam: {
                                                                            ...student.exam,
                                                                            phys: {
                                                                                currentMark: Number(value),
                                                                                maxMark: student.exam?.phys?.maxMark ?? 0
                                                                            }
                                                                        }
                                                                    }
                                                                );
                                                            }
                                                        }
                                                    />
                                                )
                                        }
                                        <div className={styles.maxMark}>
                                            <span className={styles.maxMarkLabel}>{'max'}</span>

                                            {
                                                editingMode === false
                                                    ? (
                                                        <span
                                                            className={styles.maxMark}
                                                        >
                                                            {
                                                                exams.phys?.maxMark
                                                            }
                                                        </span>
                                                    )
                                                    : (
                                                        <input
                                                            type='number'
                                                            defaultValue={exams.phys?.maxMark}
                                                            onChange={() => { }}
                                                            onBlur={
                                                                ({ currentTarget: { value } }) => {
                                                                    setStudent(
                                                                        {
                                                                            ...student,
                                                                            exam: {
                                                                                ...student.exam,
                                                                                phys: {
                                                                                    currentMark: student.exam?.phys?.currentMark ?? 0,
                                                                                    maxMark: Number(value)
                                                                                }
                                                                            }
                                                                        }
                                                                    );
                                                                }
                                                            }
                                                        />
                                                    )
                                            }
                                        </div>
                                    </>
                                </div>
                            </div>

                            <div className={styles.subject} id='test'>
                                <span className={styles.subjectName}>{'Диагностическое тестирование'}</span>
                                <div className={styles.marksContainer}>
                                    <>
                                        {
                                            editingMode === false
                                                ? (
                                                    <div
                                                        className={
                                                            `
                                                                ${styles.mark} 
                                                                ${exams.test ? stylishMark(exams.test) : ''}
                                                            `
                                                        }
                                                    >
                                                        {
                                                            exams.test?.currentMark
                                                        }
                                                    </div>
                                                )
                                                : (
                                                    <input
                                                        type='number'
                                                        defaultValue={exams.test?.currentMark}
                                                        onChange={() => { }}
                                                        onBlur={
                                                            ({ currentTarget: { value } }) => {
                                                                setStudent(
                                                                    {
                                                                        ...student,
                                                                        exam: {
                                                                            ...student.exam,
                                                                            test: {
                                                                                currentMark: Number(value),
                                                                                maxMark: student.exam?.test?.maxMark ?? 0
                                                                            }
                                                                        }
                                                                    }
                                                                );
                                                            }
                                                        }
                                                    />
                                                )
                                        }
                                        <div className={styles.maxMark}>
                                            <span className={styles.maxMarkLabel}>{'max'}</span>

                                            {
                                                editingMode === false
                                                    ? (
                                                        <span
                                                            className={styles.maxMark}
                                                        >
                                                            {
                                                                exams.test?.maxMark
                                                            }
                                                        </span>
                                                    )
                                                    : (
                                                        <input
                                                            type='number'
                                                            defaultValue={exams.test?.maxMark}
                                                            onChange={() => { }}
                                                            onBlur={
                                                                ({ currentTarget: { value } }) => {
                                                                    setStudent(
                                                                        {
                                                                            ...student,
                                                                            exam: {
                                                                                ...student.exam,
                                                                                phys: {
                                                                                    currentMark: student.exam?.phys?.currentMark ?? 0,
                                                                                    maxMark: Number(value)
                                                                                }
                                                                            }
                                                                        }
                                                                    );
                                                                }
                                                            }
                                                        />
                                                    )
                                            }
                                        </div>
                                    </>
                                </div>
                            </div>
                        </>
                    )
            }
        </div >
    );
}

export {
    MarksPanel
}