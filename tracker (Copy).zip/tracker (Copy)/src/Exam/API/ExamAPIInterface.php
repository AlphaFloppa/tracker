<?php

namespace App\Exam\API;

use App\Exam\App\Exam;

interface ExamAPIInterface
{
    public function findExamByStudentId(string $id): ?Exam;

    public function setExamResultsByStudentId(string $id, array $results): void;
}