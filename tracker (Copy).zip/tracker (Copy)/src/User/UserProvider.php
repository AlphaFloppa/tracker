<?php

namespace App\User;

use App\Admin\Infrastructure\Query\AdminQueryService;
use App\Admin\App\Query\AdminQueryServiceInterface;
use App\Common\Infrastructure\ConnectionProvider;
use App\Student\App\Query\StudentQueryServiceInterface;
use App\Student\Infrastructure\Query\StudentQueryService;
use Symfony\Component\Security\Core\Exception\UserNotFoundException;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Security\Core\User\UserProviderInterface;

class UserProvider implements UserProviderInterface
{
    private StudentQueryServiceInterface $studentQueryService;
    private AdminQueryServiceInterface $adminQueryService;
    public function __construct(
        ConnectionProvider $provider
    )
    {
        $this->studentQueryService = new StudentQueryService(
            $provider->getConnectionToDb()
        );

        $this->adminQueryService = new AdminQueryService(
            $provider->getConnectionToDb()
        );
    }

    public function loadUserByIdentifier(string $identifier): UserInterface
    {
        $student = $this->studentQueryService->findStudentByEmail($identifier);
        if(is_null($student))
        {
            $admin = $this->adminQueryService->findAdminByEmail($identifier);
            if(is_null($admin))
            {
                throw new UserNotFoundException();
            }   

            return new User($admin);
        }
        return new User($student);
    }

    public function refreshUser(UserInterface $user): UserInterface
    {
        return $user;
    }

    public function supportsClass(string $class): bool
    {
        return User::class === $class;
    }
}