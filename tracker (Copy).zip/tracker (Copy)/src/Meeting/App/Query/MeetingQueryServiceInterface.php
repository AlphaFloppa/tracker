<?php

namespace App\Meeting\App\Query;

use App\Meeting\App\Meeting;

interface MeetingQueryServiceInterface
{
    public function getMeetingByStudentId(string $studentId): ?Meeting;
}