<?php

namespace App\Student\Infrastructure\Query;

use App\Student\App\Student;
use PDO;
use App\Student\App\Query\StudentQueryServiceInterface;

class StudentQueryService implements StudentQueryServiceInterface
{
    public function __construct(
        private PDO $pdo
    ) {}

    public function getStudents(array $classFilters, array $stageFilters, ?string $namePattern = null): array
    {
        $classFiltersPlaceholders = implode(', ', array_fill(0, count($classFilters), '?'));
        $stageFiltersPlaceholders = implode(', ', array_fill(0, count($stageFilters), '?'));

        $classFiltersClause = count($classFilters) > 0 
            ? "AND class IN ($classFiltersPlaceholders)" 
            : '';
        $stageFiltersClause = count($stageFilters) > 0 
            ? "AND current_stage IN ($stageFiltersPlaceholders)" 
            : '';
        $nameClause = is_null($namePattern) 
            ? ''
            : "AND full_name LIKE ?";
        $whereClause = "1=1 $classFiltersClause $stageFiltersClause $nameClause";

        $query = <<<SQL
            SELECT * FROM student
            WHERE $whereClause AND status = 'enroll'
        SQL;

        $stmt = $this->pdo->prepare($query);
        $filtersValues = array_merge(
            $classFilters,
            $stageFilters,
            is_null($namePattern) 
                ? [] 
                : ["%$namePattern%"]
        );
        
        $stmt->execute(
            $filtersValues
        );

        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $students = array_map(
            fn($record) => new Student(
                $record['id'],
                $record['class'],
                $record['email'],
                $record['password_hash'],
                $record['full_name'],
                $record['parent_full_name'],
                $record['phone'],
                $record['current_stage'],
                $record['status']
            ),
            $data
        );

        return $students;
    }

    public function findStudent(string $id): Student | null
    {
        $query = <<<SQL
            SELECT * FROM student
            WHERE id = :id
        SQL;

        $stmt = $this->pdo->prepare($query);
        $stmt->execute(
            [
                'id' => $id
            ]
        );

        $data = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$data) {
            return null;
        }

        return new Student(
            $id,
            $data['class'],
            $data['email'],
            $data['password_hash'],
            $data['full_name'],
            $data['parent_full_name'],
            $data['phone'],
            $data['current_stage'],
            $data['status']
        );
    }

    public function findStudentByEmail(string $email): Student | null
    {
        $query = <<<SQL
            SELECT * FROM student
            WHERE email = :email
        SQL;

        $stmt = $this->pdo->prepare($query);
        $stmt->execute(
            [
                'email' => $email
            ]
        );

        $data = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$data) {
            return null;
        }

        return new Student(
            $data['id'],
            $data['class'],
            $email,
            $data['password_hash'],
            $data['full_name'],
            $data['parent_full_name'],
            $data['phone'],
            $data['current_stage'],
            $data['status']
        );
    }

    /**
     * @return array Array of strings - filenames
     */
    public function getStudentDocuments(string $studentId): array | null
    {
        $query = <<<SQL
            SELECT document_name 
            FROM document
            WHERE student_id = :id
        SQL;

        $stmt = $this->pdo->prepare($query);
        $stmt->execute(
            [
                'id' => $studentId
            ]
        );

        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (count($data) === 0) {
            return null;
        }

        return array_map(
            fn($docName) => $docName['document_name'],
            $data
        );
    }
}
