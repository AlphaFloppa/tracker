import { useChangingStudent } from '@/components/Dashboard/Admin/hooks';
import styles from './.module.css';

type Props = {
    initialLink: string
}

const LinkInput = (
    { initialLink }: Props
) => {
    const {value: student, setValue: setStudent} = useChangingStudent();
    const handleLinkChange = (newLink: string) => {
        setStudent(
            {
                ...student,
                interview: {
                    datetime: student.interview?.datetime ?? new Date(),
                    link: newLink
                }
            }
        )
    }

    return (
        <>
            <input
                className={styles.input}
                id='link'
                type="text"
                defaultValue={initialLink}
                onChange={() => { }}
                onBlur={
                    (e) => {
                        handleLinkChange(
                            e.currentTarget.value
                        )
                    }
                }
            />
        </>
    );
}

export {
    LinkInput
}