<?php

namespace App\Meeting\App\Repository;

use App\Meeting\App\Meeting;

interface MeetingRepositoryInterface
{
    public function storeMeeting(Meeting $meeting): void;
}