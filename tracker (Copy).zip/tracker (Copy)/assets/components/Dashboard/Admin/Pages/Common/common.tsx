import { Stage } from '../../../../../types/Stage';
import { stageToPageIndex } from '../../Dashboard';
import commonStyles from '../.module.css';

const stageNotStarted = (
    <span className={` ${commonStyles.unstarted} ${commonStyles.statusValue} `} >
        {'Не начато'}
    </span>
);

const stageUnfinished = (
    <span className={` ${commonStyles.unfinished} ${commonStyles.statusValue} `} >
        {'В процессе'}
    </span>
);

const stagePassed = (
    <span className={` ${commonStyles.finished} ${commonStyles.statusValue} `} >
        {'Пройдено'}
    </span>
);

const stageFailed = (
    <span className={` ${commonStyles.failed} ${commonStyles.statusValue} `} >
        {'Провалено'}
    </span>
);

const stageSettlementOptions = [
    {
        value: 'unfinished', label: stageUnfinished
    },
    {
        value: 'passed', label: stagePassed
    },
    {
        value: 'failed', label: stageFailed
    }
];

const defineStageStatus = (
    currentStage: "register" | "documentsSubmission" | "exams" | "interview" | "final"
) => (
    stageToPageIndex(currentStage) < 2
        ? stageNotStarted
        : stageToPageIndex(currentStage) === 2
            ? stageUnfinished
            : stagePassed
);

const defineNewStage = (
    {
        currentStageSetting,
        currentStage
    }: {
        currentStageSetting: string,
        currentStage: Stage
    }
): Stage | null => {
    if (
        currentStageSetting === 'unfinished' ||
        !['passed', 'failed'].includes(
            currentStageSetting
        )
    ) {
        return null;
    }

    let newStage: Stage = currentStage;

    switch (currentStage) {
        case 'register':
            newStage =
                currentStageSetting === 'passed'
                    ? 'documentsSubmission'
                    : 'register';
            break;

        case 'documentsSubmission':
            newStage =
                currentStageSetting === 'passed'
                    ? 'exams'
                    : 'register';
            break

        case 'exams':
            newStage =
                currentStageSetting === 'passed'
                    ? 'interview'
                    : 'register';
            break;

        case 'interview':
            newStage =
                currentStageSetting === 'passed'
                    ? 'final'
                    : 'register';
            break;

        case 'final':
            newStage =
                currentStageSetting === 'passed'
                    ? 'final'  // финальный этап, остаёмся здесь
                    : 'register';  // возврат в начало
            break;
    }

    return newStage;
};

export {
    stageSettlementOptions,
    defineStageStatus,
    defineNewStage
}