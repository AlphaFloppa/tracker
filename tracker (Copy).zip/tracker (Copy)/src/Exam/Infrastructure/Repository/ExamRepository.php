<?php

namespace App\Exam\Infrastructure\Repository;

use App\Exam\App\Repository\ExamRepositoryInterface;
use PDO;

class ExamRepository implements ExamRepositoryInterface
{
    public function __construct(
        private PDO $pdo
    ) {}

    /**
     * @param string $id
     * @param array $results ['phys'] => ['currentMark' => int, 'maxMark' => int]
     */
    public function setExamResults(string $id, array $results): void
    {
        $placeholders = implode(
            ',',
            array_map(
                fn() => '(?, ?, ?, ?)',
                $results
            )
        );

        $query = <<<SQL
            INSERT INTO exam_mark
            (student_id, subject, mark, max_mark)
            VALUES
            $placeholders
            ON DUPLICATE KEY UPDATE
                mark = VALUES(mark),
                max_mark = VALUES(max_mark)
        SQL;

        $stmt = $this->pdo->prepare($query);

        $values = [];

        foreach ($results as $examName => $examResult) {
            $values = array_merge(
                $values,
                [$id, $examName, $examResult['currentMark'], $examResult['maxMark']]
            );
        }

        $stmt->execute(
            $values
        );
    }
}
