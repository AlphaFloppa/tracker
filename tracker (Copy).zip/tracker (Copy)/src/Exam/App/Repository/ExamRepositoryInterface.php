<?php

namespace App\Exam\App\Repository;

interface ExamRepositoryInterface
{
    /**
     * @param string $id
     * @param array $results ['phys' => {int}, 'math' => {int}, 'test' => {int}]
     */
    public function setExamResults(string $id, array $results): void;
}
