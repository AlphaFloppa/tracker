<?php

namespace App\Exam\App\Service;

interface ExamServiceInterface
{
    public function setExamResultsByStudentId(string $id, array $results): void;
}