<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* index.html.twig */
class __TwigTemplate_2e416622b1184d1d7604a3dd3daa91f9 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "index.html.twig"));

        // line 1
        yield "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\">
        <title>Tracker</title>
        <link rel=\"icon\" type=\"image/svg+xml\" href = '/icon2.svg' />
        ";
        // line 7
        yield $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackLinkTags("app");
        yield "
        <style>
            * {
                box-sizing: border-box;
            }

            body{
                width: fit-content;
                height: fit-content;
                margin: 0;
                padding: 0;
            }

            :root{
                font-size: clamp(8px, max(1.6svh, 1svw), 16px);
            }

            #root{
                position: relative
            }
        </style>
        ";
        // line 28
        yield $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackScriptTags("app");
        yield "
    </head>
    <body>
        <div id = 'root'>
        </div>
    </body>
</html>";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  77 => 28,  53 => 7,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\">
        <title>Tracker</title>
        <link rel=\"icon\" type=\"image/svg+xml\" href = '/icon2.svg' />
        {{ encore_entry_link_tags('app') }}
        <style>
            * {
                box-sizing: border-box;
            }

            body{
                width: fit-content;
                height: fit-content;
                margin: 0;
                padding: 0;
            }

            :root{
                font-size: clamp(8px, max(1.6svh, 1svw), 16px);
            }

            #root{
                position: relative
            }
        </style>
        {{ encore_entry_script_tags('app') }}
    </head>
    <body>
        <div id = 'root'>
        </div>
    </body>
</html>", "index.html.twig", "/home/kirill.bakhtin/tracker/templates/index.html.twig");
    }
}
