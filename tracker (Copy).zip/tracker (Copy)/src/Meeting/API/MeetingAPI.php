<?php

namespace App\Meeting\API;

use App\Meeting\App\Meeting;
use App\Meeting\App\Query\MeetingQueryServiceInterface;
use App\Meeting\App\Repository\MeetingRepositoryInterface;
use Override;

class MeetingAPI implements MeetingAPIInterface
{
    public function __construct(
        private MeetingQueryServiceInterface $queryService,
        private MeetingRepositoryInterface $repository
    )
    {}

    public function getMeetingByStudentId(string $studentId): ?Meeting
    {
        return $this->queryService->getMeetingByStudentId($studentId);
    }

    public function storeMeeting(Meeting $meeting): void
    {
        $this->repository->storeMeeting($meeting);
    }
}