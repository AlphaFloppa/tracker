<?php

namespace App\Controller;

use App\Exam\API\ExamAPIInterface;
use App\ServiceProvider;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

class ExamsController extends AbstractController
{
    private ExamAPIInterface $examsAPI;

    public function __construct(
        ServiceProvider $provider
    ) {
        $this->examsAPI = $provider->getExamAPI();
    }

    public function getStudentExams(string $studentId): Response
    {
        $exams = $this->examsAPI->findExamByStudentId($studentId);
        return new JsonResponse(
            $exams->getMarks()
        );
    }
    
}
