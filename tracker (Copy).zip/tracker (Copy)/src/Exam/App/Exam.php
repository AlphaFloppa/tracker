<?php

namespace App\Exam\App;

class Exam
{
    /**
     * @param array $physMark [mark, max_mark]
     * @param array $mathMark [mark, max_mark]
     * @param array $testMark [mark, max_mark]
     */
    public function __construct(
        private array $physMark,
        private array $mathMark,
        private array $testMark
    ) {}

    public function getMarks(): array
    {
        return [
            'phys' => [
                'currentMark' => $this->physMark[0],
                'maxMark' => $this->physMark[1]
            ],
            'math' => [
                'currentMark' => $this->mathMark[0],
                'maxMark' => $this->mathMark[1]
            ],
            'test' => [
                'currentMark' => $this->testMark[0],
                'maxMark' => $this->testMark[1]
            ],
        ];
    }
}
