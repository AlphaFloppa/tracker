const validExtensions = [
    'application/pdf',
    'image/png',
    'image/jpeg'
];

const url = '/documents/store';

const useDocuments = () => {

    const storeDocs = async (files: File[]) => {
        if(
            files.length === 0
        ){
            return;
        }

        const formData = new FormData();
        files.forEach(
            (file) => {
                formData.append('files[]', file);
            }
        );

        return fetch(
            url,
            {
                method: 'POST',
                body: formData
            }
        ).then(
            (response) => response.ok
        );
    }

    const validate = (file: File) => validExtensions.includes(file.type);

    return {
        storeDocs,
        validate
    };
}

export{
    useDocuments
}