<?php

namespace App\Exam\App;

class Exam
{
    /**
     * @param array $physMark [mark, max_mark]
     * @param array $mathMark [mark, max_mark]
     * @param array $testMark [mark, max_mark]
     */
    public function __construct(
        private array $physMark,
        private array $mathMark,
        private array $testMark
    ) {}

    public function getMarks(): array
    {
        return [
            'phys' => $this->physMark,
            'math' => $this->mathMark,
            'test' => $this->testMark
        ];
    }
}
