<?php

namespace App\Exam\Infrastructure\Repository;

use App\Exam\App\Repository\ExamRepositoryInterface;
use PDO;

class ExamRepository implements ExamRepositoryInterface
{
    public function __construct(
        private PDO $pdo
    )
    {}
    
    public function setExamResults(string $id, array $results): void
    {
        $query = <<<SQL
            INSERT INTO exam_mark
            (student_id, phys_mark, math_mark, test_mark)
            VALUES
            (:id, :phys, :math, :test)
        SQL;

        $stmt = $this->pdo->prepare($query);
        $stmt->execute(
            [
                'id' => $id,
                ...$results
            ]
        );
    }
}