import { useEffect } from "react";
import { useUser } from "../../hooks/UserStorage.hooks";
import { AdminPanel } from "../AdminPanel/AdminPanel";
import { Dashboard as AdminDashboard } from "../Dashboard/Admin/Dashboard";
import { Dashboard as StudentDashboard } from "../Dashboard/Student/Dashboard";
import { SignPage } from "../SignPage/SignPage";
import { BrowserRouter, Route, Routes, useLocation } from "react-router-dom";

const App = () => {
    const { user } = useUser();

    useEffect(
        () => {
            if (user === null && window.location.pathname !== '/sign') {
                window.location.href = '/sign'
            }
        },
        []
    );
    return (
        <>
            <BrowserRouter>
                <Routes>
                    <Route path='/sign' element={<SignPage />} />
                    <Route path='/dashboard' element={<StudentDashboard />} />
                    <Route path='/panel' element={<AdminPanel />} />
                    <Route path='/student/:id' element={<AdminDashboard />} />
                </Routes>
            </BrowserRouter>
        </>
    );
}

export {
    App
}