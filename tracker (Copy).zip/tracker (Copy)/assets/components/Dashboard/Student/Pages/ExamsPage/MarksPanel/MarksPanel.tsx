import { ExamMark } from '../../../../../../types/Exam';
import { useUser } from '../../../../../../hooks/UsersStorage.hooks';
import styles from './.module.css';

const defineMarkTypeClass = (mark: ExamMark) => {
    const { currentMark, maxMark } = mark;
    const examResult = (currentMark / maxMark);
    switch (true) {
        case examResult <= 0.1:
            return styles.markAwful;
        case examResult <= 0.2:
            return styles.markWorse;
        case examResult <= 0.3:
            return styles.markBad;
        case examResult <= 0.6:
            return styles.markMedium;
        case examResult <= 0.8:
            return styles.markGood;
        case examResult <= 1:
            return styles.markBest;
        default:
            return undefined;
    }
}

const MarksPanel = () => {
    const { user } = useUser();
    if (user === null || user.type !== 'student') {
        return;
    }
    const { exam } = user;
    return (
        <div
            className={
                `
                    ${styles.marksCont}
                    ${exam === null ? styles.noMarks : ''}
                `
            }
        >
            <span className={styles.header}>
                {'Оценки'}
            </span>

            {
                exam === null
                    ? (
                        <span className={styles.noExamsMessage}>
                            {'Тут скоро появятся твои оценки за экзамены...'}
                        </span>
                    )
                    : (
                        <>
                            <div className={styles.subject} id='math'>
                                <span className={styles.subjectName}>{'Математика'}</span>
                                <div className={styles.marksContainer}>
                                    <div
                                        className={
                                            `
                                                ${styles.mark} 
                                                ${defineMarkTypeClass(exam.math)}
                                            `
                                        }>
                                        {
                                            exam.math.currentMark
                                        }
                                    </div>
                                    <div className={styles.maxMark}>
                                        <span className={styles.maxMarkLabel}>{'max'}</span>
                                        <span className={styles.maxMarkNumber}>
                                            {
                                                exam.math.maxMark
                                            }
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div className={styles.subject} id='phys'>
                                <span className={styles.subjectName}>{'Физика'}</span>
                                <div className={styles.marksContainer}>
                                    <div
                                        className={
                                            `
                                                ${styles.mark} 
                                                ${defineMarkTypeClass(exam.phys)}
                                            `
                                        }>
                                        {
                                            exam.phys.currentMark
                                        }
                                    </div>
                                    <div className={styles.maxMark}>
                                        <span className={styles.maxMarkLabel}>{'max'}</span>
                                        <span className={styles.maxMarkNumber}>
                                            {
                                                exam.phys.maxMark
                                            }
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div className={styles.subject} id='testing'>
                                <span className={styles.subjectName}>{'Диагностическое тестирование'}</span>
                                <div className={styles.marksContainer}>
                                    <div
                                        className={
                                            `
                                                ${styles.mark} 
                                                ${defineMarkTypeClass(exam.test)}
                                            `
                                        }>
                                        {
                                            exam.test.currentMark
                                        }
                                    </div>
                                    <div className={styles.maxMark}>
                                        <span className={styles.maxMarkLabel}>{'max'}</span>
                                        <span className={styles.maxMarkNumber}>
                                            {
                                                exam.test.maxMark
                                            }
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </>
                    )
            }
        </div >
    );
}

export {
    MarksPanel
}