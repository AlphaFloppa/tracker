<?php

namespace App\Meeting\App;

class Meeting
{
    public function __construct(
        private string $studentId,
        private int $time,
        private string $link
    ){}

    public function getMeetingTime(): int
    {
        return $this->time;
    }

    public function getFormattedDate(): string
    {
        return date('d.m.Y', $this->time);
    }

    public function getFormattedTime(): string
    {
        return date('H:i', $this->time);
    }

    public function getLink(): string
    {
        return $this->link;
    }

    public function getStudentId(): string
    {
        return $this->studentId;
    }

    public function getInfo(): array
    {
        return [
            'datetime' => $this->getMeetingTime(),
            'link' => $this->getLink()
        ];
    }

    public function getFormattedInfo(): array
    {
        return [
            'date' => $this->getFormattedDate(),
            'time' => $this->getFormattedTime(),
            'link' => $this->getLink()
        ];
    }
}