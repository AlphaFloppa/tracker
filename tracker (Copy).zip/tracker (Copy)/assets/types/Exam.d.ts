type ExamMark = {
    currentMark: number,
    maxMark: number
}

type Exams = {
    phys?: ExamMark
    math?: ExamMark
    test?: ExamMark
}

export type{
    ExamMark,
    Exams
}