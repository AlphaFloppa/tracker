import React, { forwardRef, useEffect, useImperativeHandle, useState } from 'react';
import styles from './.module.css';
import { useDocuments } from './DocumentsStorage.hooks';
import { useUser } from '../../../../../../hooks/UsersStorage.hooks';

type SendingSubscriber = {
    sendFilesHandler: Function
}

const DocumentsStorage = forwardRef(
    ({ }, ref) => {
        const { user } = useUser();
        if (user === null || user.type !== 'student') {
            return;
        }

        const fetchedDocuments = user.uploadedDocuments.map(
            (fileName) => {
                const ext = fileName.split('.').at(-1);
                return fileName.slice(0, fileName.lastIndexOf('_')) + '.' + ext;
            }
        );

        const [uploadedDocuments, setUploadedDocuments] = useState<string[]>(fetchedDocuments);
        const [filesStorage, setFilesStorage] = useState<File[]>([]);
        const { storeDocs, validate} = useDocuments();

        useImperativeHandle(
            ref,
            () => (
                {
                    sendFilesHandler: () => {
                        storeDocs(filesStorage).then(
                            (isSuccessful) => {
                                if(!isSuccessful) {
                                    return;
                                }
                                setUploadedDocuments(
                                    (previousDocs) => [
                                        ...previousDocs,
                                        ...filesStorage.map(
                                            (file) => file.name
                                        )
                                    ]
                                );
                                setFilesStorage([]);
                            }
                        );
                    }
                }
            )
        );

        const inputChangeHandler = (e: React.ChangeEvent<HTMLInputElement>) => {
            if (e.target.files === null) {
                return;
            }
            const files = Array.from(e.target.files).filter(
                (file) => validate(file)
            );

            setFilesStorage(
                (filesStorage) => (
                    [
                        ...filesStorage,
                        ...files
                    ]
                )
            );
        }

        const removeFileHandler = (index: number) => {
            setFilesStorage(
                (filesStorage) => (
                    filesStorage.toSpliced(index, 1)
                )
            );
        }

        return (
            <div className={styles.documentCont}>
                <div className={styles.addBtn}>
                    <input
                        type="file"
                        className={styles.hiddenInput}
                        onChange={inputChangeHandler}
                        title=''
                    />
                    +
                </div>

                {
                    (filesStorage.length + uploadedDocuments.length) === 0
                    && (
                        <div className={styles.placeholder}>{'Тут появится загруженный файл'}</div>
                    )
                }

                {
                    uploadedDocuments.map(
                        (fileName, index) => (
                            <div key={index} className={styles.file}>
                                <span className={styles.fileName}>{fileName}</span>
                                <span className={styles.success}>{'Отправлено'}</span>
                            </div>
                        )
                    )
                }

                {
                    filesStorage.map(
                        (file, index) => (
                            <div key={index} className={styles.file}>
                                <span className={styles.fileName}>{file.name}</span>
                                <span className={styles.success}>{'Загружено'}</span>
                                <div
                                    className={styles.removeBtn}
                                    onClick={() => { removeFileHandler(index) }}
                                ></div>
                            </div>
                        )
                    )
                }
            </div>
        );
    }
);

export {
    DocumentsStorage
}

export type {
    SendingSubscriber
}