const validate = (value: any) => {
    if(!value) {
        throw new Error()
    }

    return value
}

export {
    validate
}