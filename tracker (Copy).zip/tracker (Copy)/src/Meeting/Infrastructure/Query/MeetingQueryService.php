<?php

namespace App\Meeting\Infrastructure\Query;

use App\Meeting\App\Meeting;
use App\Meeting\App\Query\MeetingQueryServiceInterface;
use Override;
use PDO;

class MeetingQueryService implements MeetingQueryServiceInterface
{
    public function __construct(
        private PDO $pdo
    )
    {}

    public function getMeetingByStudentId(string $studentId): ?Meeting
    {
        $query = <<<SQL
            SELECT meeting_time, meeting_link 
            FROM interview
            WHERE student_id = :id
        SQL;

        $stmt = $this->pdo->prepare($query);

        $stmt->execute(
            [
                'id' => $studentId
            ]
        );

        $data = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if(!$data) 
        {
            return null;
        }

        return new Meeting(
            $studentId,
            strtotime($data['meeting_time']),
            $data['meeting_link']
        );
    }
}