<?php

namespace App;

use App\Common\Infrastructure\ConnectionProvider;
use App\Common\Infrastructure\EnvProvider;
use App\Common\Service\StagesDeadlines\Query\StagesDeadlinesQueryService;
use App\Common\Service\StagesDeadlines\Repository\StagesDeadlinesRepository;
use App\Exam\API\ExamAPIInterface;
use App\Exam\Infrastructure\Factory\ExamAPIFactory;
use App\Meeting\API\MeetingAPIInterface;
use App\Meeting\Infrastructure\Factory\MeetingAPIFactory;
use App\Student\API\StudentAPIInterface;
use App\Student\Infrastructure\Factory\StudentAPIFactory;
use PDO;
use App\Common\Service\StagesDeadlines\Service\StagesDeadlinesService;

class ServiceProvider
{
    private PDO $pdo;

    public function __construct(
        ConnectionProvider $provider,
        private EnvProvider $envProvider
    )
    {
        $this->pdo = $provider->getConnectionToDb();
    }

    public function getStudentAPI(): StudentAPIInterface
    {
        return StudentAPIFactory::createStudentAPI($this->pdo);
    }

    public function getExamAPI(): ExamAPIInterface
    {
        return ExamAPIFactory::createExamAPI($this->pdo);
    }

    public function getMeetingAPI(): MeetingAPIInterface
    {
        return MeetingAPIFactory::createMeetingAPI($this->pdo);
    }

    public function getStagesDeadlinesService(): StagesDeadlinesService
    {
        return new StagesDeadlinesService(
            new StagesDeadlinesQueryService(
                $this->pdo,
                $this->envProvider
            ),
            new StagesDeadlinesRepository(
                $this->pdo
            )
        );
    }
}