<?php

namespace App\Student\Infrastructure\Repository;

use PDO;
use App\Student\App\Repository\StudentRepositoryInterface;
use App\Student\App\Student;
use Exception;
use Symfony\Component\HttpFoundation\File\File;

class StudentRepository implements StudentRepositoryInterface
{
    public function __construct(
        private PDO $pdo
    ) {}

    public function createStudent(Student $student): void
    {
        $query = <<<SQL
            INSERT INTO student
            (id, class, email, password_hash, full_name, parent_full_name, phone, current_stage)
            VALUES
            (:id, :class, :email, :password, :fullName, :parentFullName, :phone, 2)
        SQL;

        $stmt = $this->pdo->prepare($query);

        $stmt->execute(
            [
                'id' => $student->getId(),
                'class' => $student->getClass(),
                'email' => $student->getEmail(),
                'password' => $student->getPassword(),
                'fullName' => $student->getFullName(),
                'parentFullName' => $student->getParentName(),
                'phone' => $student->getPhone()
            ]
        );
    }

    public function deleteStudent(string $id): void
    {
        $query = <<<SQL
            DELETE FROM student
            WHERE id = :id
        SQL;

        $stmt = $this->pdo->prepare($query);

        $stmt->execute(
            [
                'id' => $id
            ]
        );
    }

    public function updateStudentPassword(string $id, string $password): void
    {
        $query = <<<SQL
            UPDATE student
            SET password_hash = :password
            WHERE id = :id
        SQL;

        $stmt = $this->pdo->prepare($query);

        $stmt->execute(
            [
                'id' => $id,
                'password' => $password
            ]
        );
    }

    public function saveStudentDocuments(string $studentId, array $documents): void
    {
        $placeholders = implode(
            ',',
            array_fill(
                0,
                count($documents),
                '(?, ?)'
            )
        );

        $query = <<<SQL
            INSERT INTO document
            (document_name, student_id)
            VALUES
            $placeholders
        SQL;

        $stmt = $this->pdo->prepare($query);

        $values = [];
        foreach ($documents as $document) {
            if (!$document instanceof File) {
                throw new Exception();
            }

            $values = array_merge(
                [
                    $document->getBasename(),
                    $studentId
                ],
                $values
            );
        }

        $stmt->execute($values);
    }
}
