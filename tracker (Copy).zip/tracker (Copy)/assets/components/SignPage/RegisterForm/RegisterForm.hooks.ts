import React, { useCallback, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useUser } from "../../../hooks/UsersStorage.hooks";

type useRegisterPropsType = {
    isFormDataValid: React.RefObject<Map<string, boolean>>,
    formRef: React.RefObject<HTMLFormElement | null>,
    setIsErrorsExist: Function
}

const useRegister = (
    {
        isFormDataValid,
        formRef,
        setIsErrorsExist
    }: useRegisterPropsType
) => {
    const { setUser } = useUser();
    const navigate = useNavigate();
    const registerHandler = (
        (e: SubmitEvent) => {
            const form = formRef.current;
            if (form === null) {
                console.log('formref is null');
                return;
            }
            e.preventDefault();
            const actionURL = form.action;
            const formData = new FormData(form);


            let email = formData.get('email');
            if (email !== null) {
                email = email as string
            } else {
                throw new Error();
            }

            let password = formData.get('password');
            if (password !== null) {
                password = password as string
            } else {
                throw new Error();
            }

            const phone = formData.get('phone') as string;
            formData.set(
                'phone',
                '+' + (phone).replace(/\D/g, '')
            );


            fetch(
                actionURL,
                {
                    method: 'POST',
                    body: formData
                }
            ).then(
                (response) => {
                    if (!response.ok) {
                        console.debug(response);
                        return;
                    }

                    const loginFormData = new FormData();
                    loginFormData.append('email', email);
                    loginFormData.append('password', password);
                    fetch(
                        '/login',
                        {
                            method: 'POST',
                            body: loginFormData
                        }
                    ).then(
                        async (response) => {
                            if (!response.ok) {
                                console.debug(response);
                                return;
                            }

                            const data = await response.json();
                            if (!data.isSuccessful) {
                                return;
                            }
                            const { userData } = data;
                            setUser(
                                {
                                    ...userData,
                                    password,
                                    class: Number(userData.class),
                                    currentStage: userData.current_stage,
                                    exam: 'examData' in data
                                        ? {
                                            phys: {
                                                currentMark: Number(data.examData.phys.mark),
                                                maxMark: Number(data.examData.phys.max_mark)
                                            },
                                            math: {
                                                currentMark: Number(data.examData.phys.mark),
                                                maxMark: Number(data.examData.phys.max_mark)
                                            },
                                            test: {
                                                currentMark: Number(data.examData.phys.mark),
                                                maxMark: Number(data.examData.phys.max_mark)
                                            },
                                        }
                                        : null,
                                    uploadedDocuments: 'docs' in data
                                        ? data.docs
                                        : [],
                                    type: 'student'
                                }
                            );
                            navigate('/dashboard');
                        }
                    )
                }
            )
        }
    );

    useEffect(
        () => {
            formRef.current?.addEventListener(
                'submit',
                (e) => {
                    e.preventDefault();
                    if (Array.from(                          //падает на телефоне(разница в движках)
                        isFormDataValid.current.values()
                    ).every(
                        (flag) => flag)
                    ) {
                        registerHandler(e);
                    } else {
                        setIsErrorsExist(true)
                    }
                }
            );
        },
        []
    );
}

export {
    useRegister
}