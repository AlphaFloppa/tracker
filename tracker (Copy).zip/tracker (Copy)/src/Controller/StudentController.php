<?php

namespace App\Controller;

use App\Exam\API\ExamAPIInterface;
use App\Meeting\API\MeetingAPIInterface;
use App\ServiceProvider;
use App\Student\API\StudentAPIInterface;
use App\Student\App\Student;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class StudentController extends AbstractController
{
    private StudentAPIInterface $studentAPI;
    private MeetingAPIInterface $meetingAPI;
    private ExamAPIInterface $examAPI;

    public function __construct(
        ServiceProvider $provider
    )
    {
        $this->studentAPI = $provider->getStudentAPI();
        $this->meetingAPI = $provider->getMeetingAPI();
        $this->examAPI = $provider->getExamAPI();
    }

    public function getStudents(Request $request): Response
    {
        $classFilters = $request->query->all('class');
        $stageFilters = $request->query->all('stage');
        $namePattern = $request->query->get('name');
        $students = $this->studentAPI->getStudents($classFilters, $stageFilters, $namePattern);
        $studentsData = array_map(
            fn($student) => $student instanceof Student ? $student->hydrateStudentPublicData() : [],
            $students
        );
        return new JsonResponse(
            $studentsData
        );
    }

    public function findStudent(int $id): Response
    {
        $studentData = $this->studentAPI->findStudent($id);
        return new JsonResponse(
            $studentData->hydrateStudentData()
        );
    }

    public function setStudentData(Request $request): Response
    {
        $modifiedStudentData = $request->toArray();
        $studentId = $modifiedStudentData['id'];

        //нет изменения этапа
        if(array_key_exists(
            'exam',
            $modifiedStudentData
        ))
        {
            $this->examAPI->setExamResultsByStudentId(
                $studentId,
                $modifiedStudentData['exam']
            );
        }

        return new Response('', 200);
    }
}