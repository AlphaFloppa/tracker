<?php

namespace App\Meeting\Infrastructure\Factory;

use PDO;
use App\Meeting\API\MeetingAPIInterface;
use App\Meeting\Infrastructure\Query\MeetingQueryService;
use App\Meeting\Infrastructure\Repository\MeetingRepository;
use App\Meeting\API\MeetingAPI;

class MeetingAPIFactory
{
    public static function createMeetingAPI(PDO $pdo): MeetingAPIInterface
    {
        return new MeetingAPI(
            new MeetingQueryService($pdo),
            new MeetingRepository($pdo)
        );
    }
}
