import { ForwardedRef, forwardRef, useRef, useEffect } from 'react';
import styles from '../../RegisterForm/.module.css';

type NameInputProps = {
    onDataChange: Function
    type: 'studentName' | 'parentName',
    errorMode: boolean
}

const NameInput = forwardRef(
    ({ onDataChange, type, errorMode }: NameInputProps, ref: ForwardedRef<HTMLInputElement>) => {
        const inputRef = useRef<HTMLInputElement | null>(null);
        const inputWrapperRef = useRef<HTMLDivElement | null>(null);
        const error = useRef<'incorrect' | 'empty' | null>(null);
        const setError = (value: 'incorrect' | 'empty' | null) => {
            error.current = value;
        }

        const validate = () => {
            const name = inputRef.current?.value;
            if (name === undefined) {
                return;
            }
            if (name.toString() == "") {
                inputWrapperRef.current?.classList.add(styles.contentEmpty)
                onDataChange(false)
                return;
            }

            onDataChange(true)
        }

        const resetErrors = () => {
            inputWrapperRef.current?.classList.remove(styles.contentEmpty)
        }

        /*const focusHandler = () => {
            setError(null);
        }
        const blurHandler = () => {
            const name = inputRef.current?.value;
            if (!name) {
                return;
            }
            if (name === '') {
                setError('empty');
            } else {
                onDataChange(true);
            }
        }

        useEffect(
            () => {
                if (error.current === null || errorMode) {
                    return;
                }
                inputWrapperRef.current?.classList.add(
                    (
                        error.current === 'empty'
                            && styles.contentEmpty
                    ) as string
                )
            }
        )*/

        useEffect(
            () => {
                document.querySelector('#submit')?.addEventListener(
                    'click',
                    validate
                )

                inputRef.current?.addEventListener(
                    'focus',
                    resetErrors
                )
            }
        )

        return (
            <div
                ref={inputWrapperRef}
                className={styles.inputWrapper}
            >
                <input
                    ref={
                        (node) => {
                            inputRef.current = node;
                            if (typeof ref !== 'function' && ref) {
                                ref.current = node;
                            }
                        }
                    }
                    type='text'
                    placeholder={
                        type === 'studentName'
                            ? 'ФИО ребенка'
                            : 'ФИО родителя'
                    }
                    name={
                        type === 'studentName'
                            ? 'fullName'
                            : 'parentFullName'
                    }
                    className={styles.input}
                />
            </div>
        );
    }
);

export {
    NameInput
}