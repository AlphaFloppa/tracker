import { useEffect, useRef, useState } from 'react';
import styles from './.module.css';
import { useUser } from '../../../../../hooks/UsersStorage.hooks';
import { useLogout } from './ProfileSidebar.hooks';
import { useNavigate } from 'react-router-dom';

type ProfileSidebarProps = {
    onClose: () => void
}

const unmountAnimDuration = 500;

const ProfileSidebar = ({ onClose }: ProfileSidebarProps) => {
    const {user, setUser} = useUser();
    const [isPasswordHidden, setIsPasswordHidden] = useState<boolean>(true);
    const containerRef = useRef<HTMLDivElement | null>(null);
    const logout = useLogout();
    if (user === null) {
        return;
    }

    const logoutHandler = () => {
        logout().then(
            (isSuccessful) => {
                if(!isSuccessful){
                    return;
                }

                setUser(null);
            }
        );
    }

    const closeHandler = () => {
        containerRef.current?.classList.remove(
            styles.active
        );
        setTimeout(
            () => {
                onClose();
            },
            unmountAnimDuration
        )
    }

    useEffect(
        () => {
            setTimeout(
                () => {
                    containerRef.current?.classList.add(
                        styles.active
                    );
                },
                0
            );
        },
        []
    );

    return (
        <div
            className={styles.container}
            ref={containerRef}
        >
            <div className={styles.contentCont}>
                <div
                    className={styles.backBtn}
                    onClick={closeHandler}
                >
                </div>
                <div className={styles.bg}>
                    <div className={styles.avatarWrapper}>
                        <div className={styles.avatar}>{
                            user.type === 'student'
                                ? (
                                    user.fullName.split(' ')[0].charAt(0).toUpperCase()
                                        + user.fullName.split(' ')[1].charAt(0).toUpperCase()
                                )
                                : '67'
                        }</div>
                    </div>
                </div>
                <div className={styles.header}>{'Информация об аккаунте'}</div>
                <div className={styles.infoContainer}>
                    {

                        user.type === 'student'
                        && (
                            <>
                                <div className={styles.dataRow}>
                                    <span className={styles.dataHeader}>{'ФИО ребёнка'}</span>
                                    <span className={styles.data}>{user.fullName}</span>
                                </div>

                                <div className={styles.dataRow}>
                                    <span className={styles.dataHeader}>{'ФИО родителя'}</span>
                                    <span className={styles.data}>{user.parentName}</span>
                                </div>

                                <div className={styles.dataRow}>
                                    <span className={styles.dataHeader}>{'Класс поступления'}</span>
                                    <span className={styles.data}>{user.class}</span>
                                </div>

                                <div className={styles.dataRow}>
                                    <span className={styles.dataHeader}>{'Мобильный телефон'}</span>
                                    <span className={styles.data}>{user.phone}</span>
                                </div>
                            </>
                        )
                    }

                    <div className={styles.dataRow}>
                        <span className={styles.dataHeader}>{'Электронная почта'}</span>
                        <span className={styles.data}>{user.email}</span>
                    </div>

                    <div className={styles.dataRow}>
                        <span className={styles.dataHeader}>{'Пароль'}</span>
                        <span className={styles.data}>
                            {
                                isPasswordHidden
                                    ? new Array(user.password.length).fill('*')
                                    : user.password
                            }
                        </span>
                        <div
                            className={
                                `${styles.showPasswordBtn}
                                ${isPasswordHidden ? styles.hidden : styles.open}`
                            }
                            onClick={() => { setIsPasswordHidden((value) => !value) }}
                        ></div>
                    </div>
                </div>

                <div className={styles.logoutBtn} onClick={logoutHandler}>
                    {'Выйти из аккаунта'}
                </div>
            </div>

        </div>
    );
}

export {
    ProfileSidebar
}