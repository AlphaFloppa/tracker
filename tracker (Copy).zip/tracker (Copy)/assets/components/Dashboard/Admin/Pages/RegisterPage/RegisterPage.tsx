import commonStyles from '../../Pages/.module.css';
import dashboardStyles from '../../.module.css';
import styles from './.module.css';

const RegisterPage = () => {
    return (
        <div className={`${dashboardStyles.infoContainer} ${styles.infoContainer}`}>
            <div className={commonStyles.container}>
                <div className={commonStyles.infoContainer}>
                    <span className={commonStyles.trackHeader}>{'Регистрация'}</span>
                    <span className={commonStyles.trackSubHeader}>{'Подробная информация об этом этапе:'}</span>
                    <span className={commonStyles.stageDesc}>{'Сейчас ты на этапе своего поступления в Инфотех'}</span>
                    <div className={commonStyles.deadlinesStatusCont}>
                        <div className={commonStyles.deadlines}>
                            <span className={commonStyles.deadlinesHeader}>{'Сроки:'}</span>
                            <span className={commonStyles.deadlinesInfo}>{'до 01.06.2026'}</span>
                        </div>
                        <div className={commonStyles.status}>
                            <span className={commonStyles.statusHeader}>{'Статус этапа:'}</span>
                            <span className={`${commonStyles.statusValue} ${commonStyles.finished}`}>{'Пройдено'}</span>
                        </div>
                    </div>
                </div>
            </div>

            <div className={commonStyles.arrowNext} id='nextPageBtn'></div>
        </div >
    );
}

export {
    RegisterPage
}