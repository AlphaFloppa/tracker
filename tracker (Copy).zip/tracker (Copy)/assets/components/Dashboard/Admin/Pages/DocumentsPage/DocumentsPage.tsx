import commonStyles from '../../Pages/.module.css';
import dashboardStyles from '../../.module.css';
import styles from './.module.css';
import { DocumentsStorage, SendingSubscriber } from './DocumentsStorage/DocumentsStorage';
import { useRef, useState } from 'react';
import { stageToPageIndex } from '../../Dashboard';
import { useDevice } from '../../../../../hooks/DeviceType.hooks';
import { Student } from '../../../../../types/User';
import { Switcher } from './Switcher/Switcher';
import { DocumentsViewer } from './DocumentsViewer/DocumentsViewer';
import { useChangingStudent } from '../../hooks';

type Props = {
    student: Student
}

type ActiveMode = 'load' | 'view';

const DocumentsPage = (
    { student }: Props
) => {
    const { currentStage } = useChangingStudent().value;
    const isMobile = useDevice();
    const [activeMode, setActiveMode] = useState<ActiveMode>('view');
    const toggleActiveMode = () => {
        setActiveMode(
            activeMode === 'view'
                ? 'load'
                : 'view'
        );
    }

    const filesStorageRef = useRef<SendingSubscriber | null>(null);
    return (
        !isMobile
            ? (
                <div
                    className={
                        dashboardStyles.infoContainer
                    }>
                    <div className={commonStyles.container}>
                        <div className={commonStyles.infoContainer}>
                            <span className={commonStyles.trackHeader}>{'Подача документов'}</span>
                            <span className={commonStyles.trackSubHeader}>{'Подробная информация об этом этапе:'}</span>
                            <span className={commonStyles.stageDesc}>{'Если ты прошел все предыдущие этапы, мы присылаем тебе рекомендательное письмо, оно является гарантией поступления в лицей Инфотех'}</span>
                            <div className={commonStyles.deadlinesStatusCont}>
                                <div className={commonStyles.deadlines}>
                                    <span className={commonStyles.deadlinesHeader}>{'Сроки:'}</span>
                                    <span className={commonStyles.deadlinesInfo}>{'01.06.26 - 15.07.26'}</span>
                                </div>
                                <div className={commonStyles.status}>
                                    <span className={commonStyles.statusHeader}>{'Статус этапа:'}</span>
                                    <span
                                        className={
                                            `
                                        ${commonStyles.statusValue} 
                                        ${stageToPageIndex(currentStage) < 1
                                                ? commonStyles.unstarted
                                                : stageToPageIndex(currentStage) === 1
                                                    ? commonStyles.unfinished
                                                    : commonStyles.finished
                                            }
                                    `
                                        }
                                    >
                                        {
                                            stageToPageIndex(currentStage) < 1
                                                ? 'Не начато'
                                                : stageToPageIndex(currentStage) === 1
                                                    ? 'В процессе'
                                                    : 'Пройдено'
                                        }
                                    </span>
                                </div>
                            </div>
                        </div>

                        {
                            stageToPageIndex(currentStage) > 1
                                ? (
                                    <div className={`${styles.loadCont} ${styles.mobile}`}>
                                        <span className={styles.loadContHeader}>{'Просмотр документов'}</span>
                                        <span className={styles.stageFinishedMessage}>
                                            {'Этап с документами пройден'}
                                        </span>
                                    </div>
                                )
                                : (
                                    <div className={styles.loadCont}>
                                        <span className={styles.loadContHeader}>{'Загрузка документов'}</span>
                                        <span className={styles.loadContSubHeader}>{'Тут вы можете прикрепить документы, необходимые для поступления'}</span>

                                        <Switcher
                                            toggleMode={toggleActiveMode}
                                            currentMode={activeMode}
                                        />

                                        {
                                            activeMode === 'load'
                                                ? (
                                                    <>
                                                        <DocumentsStorage
                                                            ref={filesStorageRef}
                                                        />

                                                        <div
                                                            className={styles.sendBtn}
                                                            onClick={
                                                                () => {
                                                                    filesStorageRef.current?.sendFilesHandler()
                                                                }
                                                            }
                                                        >
                                                            {'Отправить'}
                                                        </div>
                                                    </>
                                                )
                                                : (
                                                    <DocumentsViewer />
                                                )
                                        }
                                    </div>
                                )
                        }
                    </div>

                    <div className={commonStyles.arrowNext} id='nextPageBtn'></div>
                    <div className={commonStyles.arrowPrevious} id='previousPageBtn'></div>
                </div>
            )

            :
            (
                <>
                    <div className={
                        `
                            ${commonStyles.infoContainer}
                            ${commonStyles.mobile}
                        `
                    }>
                        <span className={commonStyles.trackHeader}>{'Подача документов'}</span>
                        <span className={commonStyles.trackSubHeader}>{'Подробная информация об этом этапе:'}</span>
                        <span className={commonStyles.stageDesc}>{'Если ты прошел все предыдущие этапы, мы присылаем тебе рекомендательное письмо, оно является гарантией поступления в лицей Инфотех'}</span>
                        <div className={commonStyles.deadlinesStatusCont}>
                            <div className={commonStyles.deadlines}>
                                <span className={commonStyles.deadlinesHeader}>{'Сроки:'}</span>
                                <span className={commonStyles.deadlinesInfo}>{'01.06.26 - 15.07.26'}</span>
                            </div>
                            <div className={commonStyles.status}>
                                <span className={commonStyles.statusHeader}>{'Статус этапа:'}</span>
                                <span
                                    className={
                                        `
                                        ${commonStyles.statusValue} 
                                        ${stageToPageIndex(currentStage) < 1
                                            ? commonStyles.unstarted
                                            : stageToPageIndex(currentStage) === 1
                                                ? commonStyles.unfinished
                                                : commonStyles.finished
                                        }
                                    `
                                    }
                                >
                                    {
                                        stageToPageIndex(currentStage) < 1
                                            ? 'Не начато'
                                            : stageToPageIndex(currentStage) === 1
                                                ? 'В процессе'
                                                : 'Пройдено'
                                    }
                                </span>
                            </div>
                        </div>

                        <div className={commonStyles.arrowNext} id='nextPageBtn'></div>
                        <div className={commonStyles.arrowPrevious} id='previousPageBtn'></div>
                    </div>

                    {
                        stageToPageIndex(currentStage) > 1
                            ? (
                                <div className={`${styles.loadCont} ${styles.mobile}`}>
                                    <span className={styles.loadContHeader}>{'Просмотр документов'}</span>
                                    <span className={styles.stageFinishedMessage}>
                                        {'Этап с документами пройден'}
                                    </span>
                                </div>
                            )
                            : (
                                <div className={`${styles.loadCont} ${styles.mobile}`}>
                                    <span className={styles.loadContHeader}>{'Просмотр документов'}</span>
                                    <span className={styles.loadContSubHeader}>{'Тут вы можете скачать документы, прикреплённые поступающим, а также загрузить другие необходимые файлы'}</span>

                                    <Switcher
                                        toggleMode={toggleActiveMode}
                                        currentMode={activeMode}
                                    />

                                    {
                                        activeMode === 'load'
                                            ? (
                                                <>
                                                    <DocumentsStorage
                                                        ref={filesStorageRef}
                                                    />

                                                    <div
                                                        className={styles.sendBtn}
                                                        onClick={
                                                            () => {
                                                                filesStorageRef.current?.sendFilesHandler()
                                                            }
                                                        }
                                                    >
                                                        {'Отправить'}
                                                    </div>
                                                </>
                                            )
                                            : (
                                                <DocumentsViewer />
                                            )
                                    }
                                </div>
                            )
                    }
                </>
            )
    )
}

export {
    DocumentsPage
}

export type {
    ActiveMode
}