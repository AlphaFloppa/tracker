<?php

namespace App\Controller;

use App\ServiceProvider;
use App\Student\API\StudentAPIInterface;
use App\User\User;
use Exception;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class DocumentsController extends AbstractController
{
    private StudentAPIInterface $studentAPI;

    public function __construct(
        ServiceProvider $provider
    ) {
        $this->studentAPI = $provider->getStudentAPI();
    }

    public function getStudentDocuments(string $studentId): Response
    {
        $documents = $this->studentAPI->getStudentDocuments($studentId);

        return new JsonResponse(
            $documents ?? []
        );
    }

    public function storeDocuments(Request $request): Response
    {
        $user = $this->getUser();

        if (!$user instanceof User) 
        {
            throw new Exception();
        }
            
        $files = $request->files->get('files');

        if($user->getRoles()[0] === 'ROLE_STUDENT') {
            $studentId = $user->getUserIdentifier();
        } else if($user->getRoles()[0] === 'ROLE_ADMIN') {
            $studentId = $request->get('studentId');
        }

        $this->studentAPI->storeDocuments($studentId, $files);

        return new Response('', Response::HTTP_OK);
    }
}
