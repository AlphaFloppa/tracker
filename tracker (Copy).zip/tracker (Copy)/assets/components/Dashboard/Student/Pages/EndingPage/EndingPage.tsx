import commonStyles from '../../Pages/.module.css';
import dashboardStyles from '../../.module.css';
import styles from './.module.css';
import { stageToPageIndex } from '../../Dashboard';
import type { Student } from '../../../../../types/User';

type Props = {
    student: Student
}

const EndingPage = (
    { student }: Props
) => {
    const { currentStage } = student;

    return (
        <div className={`${dashboardStyles.infoContainer} ${styles.infoContainer}`}>
            <div className={commonStyles.container}>
                <div className={commonStyles.infoContainer}>
                    <span className={commonStyles.trackHeader}>{'Поступление'}</span>
                    <span className={commonStyles.trackSubHeader}>{'Подробная информация об этом этапе:'}</span>
                    <span className={commonStyles.stageDesc}>{'Это последний твой этап перед поступлением в лицей Инфотех'}</span>
                    <div className={commonStyles.deadlinesStatusCont}>
                        <div className={commonStyles.deadlines}>
                            <span className={commonStyles.deadlinesHeader}>{'Сроки:'}</span>
                            <span className={commonStyles.deadlinesInfo}>{'01.06.26 - 15.07.26 '}</span>
                        </div>
                        <div className={commonStyles.status}>
                            <span className={commonStyles.statusHeader}>{'Статус этапа:'}</span>
                            <span
                                className={
                                    `
                                        ${commonStyles.statusValue} 
                                        ${stageToPageIndex(currentStage) < 4
                                        ? commonStyles.unstarted
                                        : stageToPageIndex(currentStage) === 4
                                            ? commonStyles.unfinished
                                            : commonStyles.finished
                                    }
                                    `
                                }
                            >
                                {
                                    stageToPageIndex(currentStage) < 4
                                        ? 'Не начато'
                                        : stageToPageIndex(currentStage) === 4
                                            ? 'В процессе'
                                            : 'Пройдено'
                                }
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <div className={commonStyles.arrowPrevious} id='previousPageBtn'></div>
        </div >
    );
}

export {
    EndingPage
}