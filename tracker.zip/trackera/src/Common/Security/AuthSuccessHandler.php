<?php

namespace App\Common\Security;

use App\Exam\API\ExamAPIInterface;
use App\Meeting\API\MeetingAPIInterface;
use App\ServiceProvider;
use App\Student\API\StudentAPIInterface;
use App\User\User;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Security\Http\Authentication\AuthenticationSuccessHandlerInterface;
use App\Common\Service\StagesDeadlines\Service\StagesDeadlinesService;

class AuthSuccessHandler implements AuthenticationSuccessHandlerInterface
{
    private ExamAPIInterface $examAPI;
    private StudentAPIInterface $studentAPI;
    private MeetingAPIInterface $meetingAPI;
    private StagesDeadlinesService $stagesInfoService;

    public function __construct(
        ServiceProvider $provider
    )
    {
        $this->studentAPI = $provider->getStudentAPI();
        $this->examAPI = $provider->getExamAPI();
        $this->meetingAPI = $provider->getMeetingAPI();
        $this->stagesInfoService = $provider->getStagesDeadlinesService();
    }

    public function onAuthenticationSuccess(Request $request, TokenInterface $token): ?Response
    {
        $user = $token->getUser();

        if(!$user instanceof User)
        {
            return new Response(
                '',
                502
            );
        }

        $role = $user->getRoles()[0];

        if($role === 'ROLE_ADMIN')
        {
            return new JsonResponse(
                [
                    'type' => 'ADMIN',
                    'userData' => $user->hydrateUserData(),
                    'isSuccessful' => true
                ]
            );
        }
        
        $studentId = $user->getUserIdentifier();

        $exam = $this->examAPI->findExamByStudentId($studentId);

        $documents = $this->studentAPI->getStudentDocuments($studentId);

        $meeting = $this->meetingAPI->getMeetingByStudentId($studentId);

        $stagesDeadlines = $this->stagesInfoService->getStagesDeadlinesForStudent($studentId);

        return new JsonResponse(
            [
                'type' => 'STUDENT',
                'userData' => $user->hydrateUserData(),
                'stagesDeadlines' => $stagesDeadlines,
                ...(
                    is_null($exam) 
                    ? [] 
                    : ['examData' => $exam->getMarks()]
                ),
                ...(
                    is_null($documents)
                    ? []
                    : ['docs' => $documents]
                ),
                ...(
                    is_null($meeting)
                    ? []
                    : ['interview' => $meeting->getInfo()]
                ),
                'isSuccessful' => true
            ]
        );
    }
}
