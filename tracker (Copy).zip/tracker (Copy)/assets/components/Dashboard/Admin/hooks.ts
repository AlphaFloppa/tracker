import { useContext } from "react";
import { MutableStudentCopyContext } from './Dashboard';

const useChangingStudent = () => {
    const value = useContext(MutableStudentCopyContext);
    if (value === null) {
        throw new Error('Changes Context value is null');
    }

    return value
}

export {
    useChangingStudent
}