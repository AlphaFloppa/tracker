import { useLocation, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import { useUser } from "../../../hooks/UserStorage.hooks";
import styles from './.module.css';
import { DashboardRender as StudentDashboardRender } from "./StudentDashboard.render";
import { Student } from "../../../types/User";

const stageToPageIndex = (
    stage: "register" | "documentsSubmission" | "exams" | "interview" | "final"
) => {
    switch (stage) {
        case 'register':
            return 0
        case 'documentsSubmission':
            return 1
        case 'exams':
            return 2
        case 'interview':
            return 3
        case 'final':
            return 4
    }
}

const Dashboard = () => {
    const { user } = useUser();
    const navigate = useNavigate();

    const [isProfileOpen, setIsProfileOpen] = useState<boolean>(false);
    const [page, setPage] = useState<number>(
        user !== null && user.type === 'student'
            ? stageToPageIndex(user.currentStage)
            : 0
    );

    const moveUp = () => {
        setPage(
            (page) => page < 4 ? page + 1 : page
        );
    }
    const moveDown = () => {
        setPage(
            (page) => page > 0 ? page - 1 : page
        );
    }

    const profileOpenHandler = () => {
        setIsProfileOpen(true);
        document.getElementById('overlay-provider')?.classList.add(
            styles.overlay
        );
    }

    const profileCloseHandler = () => {
        setIsProfileOpen(false);
        document.getElementById('overlay-provider')?.classList.remove(
            styles.overlay
        );
    }

    useEffect(
        () => {
            document.querySelector('#nextPageBtn')?.addEventListener(
                'click',
                moveUp
            );

            document.querySelector('#previousPageBtn')?.addEventListener(
                'click',
                moveDown
            );

            return () => {
                document.querySelector('#nextPageBtn')?.removeEventListener(
                    'click',
                    moveUp
                );

                document.querySelector('#previousPageBtn')?.removeEventListener(
                    'click',
                    moveDown
                );
            }
        }
    );

    useEffect(
        () => {
            if (user === null) {
                navigate('/sign')
            }
        }
    );



    if (user === null || user.type !== 'student') {
        return;
    }

    return (
        <StudentDashboardRender
            student={user}
            isProfileOpen={isProfileOpen}
            profileOpenHandler={profileOpenHandler}
            profileCloseHandler={profileCloseHandler}
            activePage={page}
            setActivePage={setPage}
        />
    );
}

export {
    Dashboard,
    stageToPageIndex
}