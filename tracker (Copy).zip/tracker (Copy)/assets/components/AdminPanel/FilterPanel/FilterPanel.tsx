import { useEffect, useRef } from 'react';
import styles from './.module.css';

type FilterParamsSetter = {
    setClassFilters: Function,
    setStageFilters: Function
}

const FilterPanel = ({ setClassFilters, setStageFilters }: FilterParamsSetter) => {
    const containerRef = useRef<HTMLDivElement | null>(null);
    const addClassFilter = (newClassFilter: string) => {
        setClassFilters(
            (previousFilters: Array<string>) => previousFilters.some(
                    (filter) => newClassFilter === filter
                )
                ? previousFilters
                : [...previousFilters, newClassFilter]
        )
    }
    const removeClassFilter = (extraFilter: string) => {
        setClassFilters(
            (previousFilters: Array<string>) => [...previousFilters].filter(
                (filter) => filter !== extraFilter
            )
        )
    }

    const addStageFilter = (newStageFilter: string) => {
        setStageFilters(
            (previousFilters: Array<string>) => previousFilters.some(
                    (filter) => newStageFilter === filter
                )
                ? previousFilters
                : [...previousFilters, newStageFilter]
        )
    }
    const removeStageFilter = (extraFilter: string) => {
        setStageFilters(
            (previousFilters: Array<string>) => [...previousFilters].filter(
                (filter) => filter !== extraFilter
            )
        )
    }

    const inputChangeFilter = ({ currentTarget: { name, value, checked } }: React.ChangeEvent<HTMLInputElement>) => {
        if (name === 'class[]') {
            if (checked) {
                addClassFilter(value);
            } else {
                removeClassFilter(value)
            }
        } else if (name === 'stage[]') {
            if (checked) {
                addStageFilter(value);
            } else {
                removeStageFilter(value)
            }
        }
    }

    const resetAllFiltersHandler = () => {
        setClassFilters(
            ['11', '10', '9', '8']
        );

        setStageFilters(
            ['documentsSubmission', 'exams', 'interview', 'final']
        );

        containerRef.current?.querySelectorAll('input[type=checkbox]').forEach(
            (input) => {
                const validInput = input as HTMLInputElement;
                validInput.checked = true;
            }
        )
    }

    useEffect(
        () => {
            const radioInputs = containerRef.current?.querySelectorAll('[data-preferred]') ?? [];
            const checkboxInputs = containerRef.current?.querySelectorAll('input[type=checkbox]') ?? [];

            radioInputs.forEach(
                (target) => {
                    const input = target as HTMLInputElement;
                    input.checked = true
                }
            );

            checkboxInputs.forEach(
                (target) => {
                    const input = target as HTMLInputElement;
                    input.checked = true
                }
            );
        },
        []
    );

    return (
        <div
            className={styles.filterPanel}
            ref={containerRef}
        >
            <div className={styles.sortingContainer}>
                <span className={styles.header}>{'Сортировка'}</span>
                <div className={styles.sortTypeContainer}>
                    <span className={styles.subheader}>{'Тип сортировки'}</span>
                    <label className={styles.sortDesc}>
                        По убыванию
                        <input className={styles.input} type="radio" name='sortType' value='desc' data-preferred />
                    </label>

                    <label className={styles.sortAsc}>
                        По возрастанию
                        <input className={styles.input} type="radio" name='sortType' value='asc' />
                    </label>
                </div>

                <div className={styles.sortParamsContainer}>
                    <span className={styles.subheader}>{'Параметр сортировки'}</span>
                    <label>
                        По ФИО
                        <input className={styles.input} type='radio' name='sortParams' value='byName' data-preferred />
                    </label>

                    <label>
                        По текущему этапу
                        <input className={styles.input} type='radio' name='sortParams' value='byStage' />
                    </label>

                    <label>
                        По классу
                        <input className={styles.input} type='radio' name='sortParams' value='byClass' />
                    </label>
                </div>
            </div>

            <div className={styles.filtersContainer}>
                <form>
                    <span className={styles.header}>{'Фильтры'}</span>

                    <div className={styles.filtersByClass}>
                        <span className={styles.subheader}>{'Класс'}</span>
                        <label>
                            11 класс
                            <input className={styles.input}
                                type='checkbox'
                                name='class[]'
                                value='11'
                                onChange={inputChangeFilter}
                            />
                        </label>

                        <label>
                            10 класс
                            <input className={styles.input}
                                type='checkbox'
                                name='class[]'
                                value='10'
                                onChange={inputChangeFilter}
                            />
                        </label>

                        <label>
                            9 класс
                            <input className={styles.input}
                                type='checkbox'
                                name='class[]'
                                value='9'
                                onChange={inputChangeFilter}
                            />
                        </label>

                        <label>
                            8 класс
                            <input className={styles.input}
                                type='checkbox'
                                name='class[]'
                                value='8'
                                onChange={inputChangeFilter}
                            />
                        </label>
                    </div>

                    <div className={styles.filtersByStage}>
                        <span className={styles.subheader}>{'Текущий этап'}</span>

                        <label>
                            Подача документов
                            <input className={styles.input}
                                type='checkbox'
                                name='stage[]'
                                value='documentsSubmission'
                                onChange={inputChangeFilter}
                            />
                        </label>

                        <label>
                            Экзамены
                            <input className={styles.input}
                                type='checkbox'
                                name='stage[]'
                                value='exams'
                                onChange={inputChangeFilter}
                            />
                        </label>

                        <label>
                            Собеседование
                            <input className={styles.input}
                                type='checkbox'
                                name='stage[]'
                                value='interview'
                                onChange={inputChangeFilter}
                            />
                        </label>

                        <label>
                            Поступление
                            <input className={styles.input}
                                type='checkbox'
                                name='stage[]'
                                value='final'
                                onChange={inputChangeFilter}
                            />
                        </label>
                    </div>
                </form>
            </div>

            <div 
                className={styles.resetAllFilters}
                onClick={resetAllFiltersHandler}
            >
                {'Выбрать все'}
            </div>
        </div>
    );
}

export {
    FilterPanel
}