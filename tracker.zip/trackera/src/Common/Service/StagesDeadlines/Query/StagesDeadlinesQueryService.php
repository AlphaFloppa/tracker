<?php

namespace App\Common\Service\StagesDeadlines\Query;

use App\Common\Infrastructure\EnvProvider;
use PDO;

class StagesDeadlinesQueryService
{
    public function __construct(
        private PDO $pdo,
        private EnvProvider $envProvider
    ) {}

    public function getStagesDeadlinesForStudent(string $studentId): array
    {
        $query = <<<SQL
            SELECT * FROM stage
            WHERE student_id = :studentId
        SQL;

        $stmt = $this->pdo->prepare($query);

        $stmt->execute(
            [
                'studentId' => $studentId
            ]
        );

        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $registerDeadline = 1780272000;

        $documentsSubmissionLowerDeadline = count(
            array_filter(
                $data,
                fn($record) => $record['name'] === 'documentsSubmission'
            )
        ) === 0
            ? $this->envProvider->getStagesDefaultDeadlines()['docsLower']
            : array_values(
                array_filter(
                    $data,
                    fn($record) => $record['name'] === 'documentsSubmission'
                )
            )[0]['start'];

        $documentsSubmissionUpperDeadline = count(
            array_filter(
                $data,
                fn($record) => $record['name'] === 'documentsSubmission'
            )
        ) === 0
            ? $this->envProvider->getStagesDefaultDeadlines()['docsUpper']
            : array_values(
                array_filter(
                    $data,
                    fn($record) => $record['name'] === 'documentsSubmission'
                )
            )[0]['end'];

        $examLowerDeadline = count(
            array_filter(
                $data,
                fn($record) => $record['name'] === 'exams'
            )
        ) === 0
            ? $this->envProvider->getStagesDefaultDeadlines()['examsLower']
            : array_values(
                array_filter(
                    $data,
                    fn($record) => $record['name'] === 'exams'
                )
            )[0]['start'];

        $examUpperDeadline = count(
            array_filter(
                $data,
                fn($record) => $record['name'] === 'exams'
            )
        ) === 0
            ? $this->envProvider->getStagesDefaultDeadlines()['examsUpper']
            : array_values(
                array_filter(
                    $data,
                    fn($record) => $record['name'] === 'exams'
                )
            )[0]['end'];

        $interviewLowerDeadline = count(
            array_filter(
                $data,
                fn($record) => $record['name'] === 'interview'
            )
        ) === 0
            ? $this->envProvider->getStagesDefaultDeadlines()['interviewLower']
            : array_values(
                array_filter(
                    $data,
                    fn($record) => $record['name'] === 'interview'
                )
            )[0]['start'];

        $interviewUpperDeadline = count(
            array_filter(
                $data,
                fn($record) => $record['name'] === 'interview'
            )
        ) === 0
            ? $this->envProvider->getStagesDefaultDeadlines()['interviewUpper']
            : array_values(
                array_filter(
                    $data,
                    fn($record) => $record['name'] === 'interview'
                )
            )[0]['end'];

        $finalStageDeadline = 1785801600;

        

        return [
            'register' => [
                'start' => $registerDeadline
            ],
            'documentsSubmission' => [
                'start' => strtotime($documentsSubmissionLowerDeadline),
                'end' => strtotime($documentsSubmissionUpperDeadline)
            ],
            'exams' => [
                'start' => strtotime($examLowerDeadline),
                'end' => strtotime($examUpperDeadline)
            ],
            'interview' => [
                'start' => strtotime($interviewLowerDeadline),
                'end' => strtotime($interviewUpperDeadline)
            ],
            'final' => [
                'end' => $finalStageDeadline
            ]
        ];
    }
}
