import {createRoot} from 'react-dom/client';
import { App } from './components/App/app';
import { UserDataProvider } from './hooks/UsersStorage.hooks';

window.addEventListener('DOMContentLoaded', () => {
    const rootContainer = document.getElementById('root');
    if(!rootContainer){
        alert('rootContainer is null');
        return;
    }
    const root = createRoot(rootContainer);
    root.render(
        <UserDataProvider>
            <App/>
        </UserDataProvider>
    )
});