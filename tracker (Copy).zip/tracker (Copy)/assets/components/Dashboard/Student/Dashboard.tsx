import { useUser } from "../../../hooks/UsersStorage.hooks";
import { useEffect, useState } from "react";
import styles from './.module.css';
import { RegisterPage } from "./Pages/RegisterPage/RegisterPage";
import { DocumentsPage } from "./Pages/DocumentsPage/DocumentsPage";
import { ExamsPage } from "./Pages/ExamsPage/ExamsPage";
import { InterviewPage } from "./Pages/InterviewPage/InterviewPage";
import { EndingPage } from "./Pages/EndingPage/EndingPage";
import { ProfileSidebar } from "./ProfileSidebar/Student/ProfileSidebar";
import { Track } from "./Track/Track";
import { useNavigate } from "react-router-dom";

const stageToPageIndex = (
    stage: "register" | "documentsSubmission" | "exams" | "interview" | "final"
) => {
    switch(stage){
        case 'register':
            return 0
        case 'documentsSubmission':
            return 1
        case 'exams':
            return 2
        case 'interview':
            return 3
        case 'final':
            return 4
    }
}

const Dashboard = () => {
    const { user } = useUser();
    console.log(user);
    const navigate = useNavigate();
    const [page, setPage] = useState<number>(
        user !== null && user.type === 'student'
        ? stageToPageIndex(user.currentStage)
        : 0
    );
    const [isProfileOpen, setIsProfileOpen] = useState<boolean>(false);

    const moveUp = () => {
        setPage(
            (page) => page < 4 ? page + 1 : page
        );
    }
    const moveDown = () => {
        setPage(
            (page) => page > 0 ? page - 1 : page
        );
    }

    const profileOpenHandler = () => {
        setIsProfileOpen(true);
        document.getElementById('overlay-provider')?.classList.add(
            styles.overlay
        );
    }

    const profileCloseHandler = () => {
        setIsProfileOpen(false);
        document.getElementById('overlay-provider')?.classList.remove(
            styles.overlay
        );
    }

    useEffect(
        () => {
            document.querySelector('#nextPageBtn')?.addEventListener(
                'click',
                moveUp
            );

            document.querySelector('#previousPageBtn')?.addEventListener(
                'click',
                moveDown
            );

            return () => {
                document.querySelector('#nextPageBtn')?.removeEventListener(
                    'click',
                    moveUp
                );

                document.querySelector('#previousPageBtn')?.removeEventListener(
                    'click',
                    moveDown
                );
            }
        }
    );

    useEffect(
        () => {
            if(user === null) {
                navigate('/sign')
            }
        }
    )

    if (user === null || user.type !== 'student') {
        return;
    }

    return (
        <>
            <div className={styles.mainContainer} id='overlay-provider'>
                <div className={styles.header}>
                    <div className={styles.logo}></div>
                    <span className={styles.signRedirectBtn}>{'На главную'}</span>
                    <div
                        className={styles.profileIcon}
                        onClick={profileOpenHandler}
                    >
                    </div>
                </div>


                <div className={styles.track}>
                    <div className={styles.textCont}>
                        <span className={styles.trackHeader}>{'Траектория поступления'}</span>
                        <span className={styles.trackSubHeader}>{'Отслеживай своё поступление без лишних проблем'}</span>
                    </div>
                    <Track activePage={page} setPage={setPage} />
                </div>

                {
                    function () {
                        switch (page) {
                            case 0:
                                return (<RegisterPage />);
                            case 1:
                                return (<DocumentsPage />);
                            case 2:
                                return (<ExamsPage />);
                            case 3:
                                return (<InterviewPage />);
                            case 4:
                                return (<EndingPage />);
                        }
                    }()
                }

                {
                    isProfileOpen && <ProfileSidebar onClose={profileCloseHandler} />
                }
            </div>
        </>
    );
}

export {
    Dashboard,
    stageToPageIndex
}