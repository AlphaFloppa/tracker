import { useEffect, useState } from "react";
import styles from './.module.css';

type InputData = {
    isFocused: boolean,
    content: string
}

type Props = {
    initialHour: string,
    initialMinute: string
}

const TimeInput = (
    { initialHour, initialMinute }: Props
) => {
    const [hourInput, setHourInput] = useState<InputData>(
        {
            isFocused: false,
            content: initialHour
        }
    );
    const [minuteInput, setMinuteInput] = useState<InputData>(
        {
            isFocused: false,
            content: initialMinute
        }
    );

    const hourInputHandler = ({ key }: KeyboardEvent) => {
        if (hourInput.isFocused) {

            if (/[0-9]/.test(key) && hourInput.content.length < 2) {
                setHourInput(
                    {
                        isFocused: true,
                        content: hourInput.content + key
                    }
                )
            } else if (key === 'Backspace' && hourInput.content.length > 0) {
                setHourInput(
                    {
                        isFocused: true,
                        content: hourInput.content.length - 1 > 0
                            ? hourInput.content.slice(0, -1)
                            : '00'
                    }
                )
            }
        }
    }

    const minuteInputHandler = ({ key }: KeyboardEvent) => {
        if (minuteInput.isFocused) {

            if (/[0-9]/.test(key) && minuteInput.content.length < 2) {
                setMinuteInput(
                    {
                        isFocused: true,
                        content: minuteInput.content + key
                    }
                )
            } else if (key === 'Backspace' && minuteInput.content.length > 0) {
                setMinuteInput(
                    {
                        isFocused: true,
                        content: minuteInput.content.length - 1 > 0
                            ? minuteInput.content.slice(0, -1)
                            : '00'
                    }
                )
            }
        }
    }

    useEffect(
        () => {
            const composedHandler = (event: KeyboardEvent) => {
                hourInputHandler(event);
                minuteInputHandler(event);
            }

            window.addEventListener(
                'keydown',
                composedHandler
            );

            return () => {
                window.removeEventListener(
                    'keydown',
                    composedHandler
                );
            }
        },
        [hourInput, minuteInput]
    )


    return (
        <>
            <input
                className={styles.input}
                id='hour'
                type="text"
                value={hourInput.content}
                onChange={() => { }}
                onFocus={
                    () => setHourInput(
                        (currentState) => (
                            {
                                ...currentState,
                                isFocused: true
                            }
                        )
                    )
                }
                onBlur={
                    () => setHourInput(
                        (currentState) => (
                            {
                                ...currentState,
                                isFocused: false
                            }
                        )
                    )
                }
            />

            <span>
                {':'}
            </span>

            <input
                className={styles.input}
                id='minute'
                type="text"
                value={minuteInput.content}
                onChange={() => { }}
                onFocus={
                    () => setMinuteInput(
                        (currentState) => (
                            {
                                ...currentState,
                                isFocused: true
                            }
                        )
                    )
                }
                onBlur={
                    () => setMinuteInput(
                        (currentState) => (
                            {
                                ...currentState,
                                isFocused: false
                            }
                        )
                    )
                }
            />
        </>
    );
}

export {
    TimeInput
}