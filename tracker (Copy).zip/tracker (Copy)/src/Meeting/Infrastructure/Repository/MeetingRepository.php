<?php

namespace App\Meeting\Infrastructure\Repository;

use App\Meeting\App\Meeting;
use App\Meeting\App\Repository\MeetingRepositoryInterface;
use PDO;

class MeetingRepository implements MeetingRepositoryInterface
{
    public function __construct(
        private PDO $pdo
    )
    {}

    public function storeMeeting(Meeting $meeting): void
    {
        $query = <<<SQL
            INSERT INTO interview
            (student_id, meeting_time, meeting_link)
            VALUES
            (:studentId, :meetingTime, :meetingLink)
        SQL;

        $stmt = $this->pdo->prepare($query);

        $stmt->execute(
            [
                'id' => $meeting->getStudentId(),
                'meetingTime' =>$meeting->getMeetingTime(),
                'meetingLink' => $meeting->getLink()
            ]
        );
    }
}