import { useEffect, useState } from "react"
import { useFetch } from "../../Common/.hooks";
import { useParams } from "react-router-dom";
import styles from './.module.css';
import { useChangingStudent } from "../../../hooks";

const formatDocumentName = (fileName: string) => {
    const ext = fileName.split('.').at(-1);
    return fileName.slice(0, fileName.lastIndexOf('_')) + '.' + ext;
}

const DocumentsViewer = () => {
    const {value: student} = useChangingStudent();
    const [uploadedDocsNames, setUploadedDocsNames] = useState<string[]>(student.uploadedDocuments);

    return (
        <>
            {
                uploadedDocsNames.map(
                    (documentName, index) => (
                        <div key={index} className={styles.file}>
                            <span className={styles.fileName}>
                                {formatDocumentName(documentName)}
                            </span>
                        </div>
                    )
                )
            }
        </>
    );
}

export{
    DocumentsViewer
}