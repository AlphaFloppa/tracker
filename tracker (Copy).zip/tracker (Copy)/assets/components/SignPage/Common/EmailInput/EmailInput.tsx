import { ForwardedRef, forwardRef, useEffect, useRef, useState } from 'react';
import styles from '../../RegisterForm/.module.css';
import { CSSProperties } from 'react';

type EmailInputProps = {
    onDataChange: Function,
    errorMode: boolean
}

const emailValidateRegex = /^[a-zA-Z0-9.%_+\-$#]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/;

const contentIncorrectErrorMessage = "'*неверно указана электронная почта'";

const EmailInput = forwardRef(
    ({ onDataChange, errorMode }: EmailInputProps, ref: ForwardedRef<HTMLInputElement>) => {
        const inputRef = useRef<HTMLInputElement | null>(null);
        const inputWrapperRef = useRef<HTMLDivElement | null>(null);
        const error = useRef<'incorrect' | 'empty' | null>(null);
        const setError = (value: 'incorrect' | 'empty' | null) => {
            error.current = value;
        }

        const validate = () => {
            const email = inputRef.current?.value;
            if (email === undefined) {
                return;
            }
            if (email.toString() == "") {
                inputWrapperRef.current?.classList.add(styles.contentEmpty)
                inputWrapperRef.current?.classList.remove(styles.contentIncorrect)
                onDataChange(false);
                return;
            } 
            /*if (!emailValidateRegex.test(email)) {
                inputWrapperRef.current?.classList.remove(styles.contentEmpty)
                inputWrapperRef.current?.classList.add(styles.contentIncorrect)
                onDataChange(false);
                return;
            }*/

            onDataChange(true);
        }

        const resetErrors = () => {
            inputWrapperRef.current?.classList.remove(styles.contentEmpty)
            inputWrapperRef.current?.classList.remove(styles.contentIncorrect)
        }

        /*const focusHandler = () => {
            setError(null);
        }
        const blurHandler = () => {
            const email = inputRef.current?.value;
            if (!email) {
                return;
            }
            if (email === '') {
                setError('empty');
            } else if (!emailValidateRegex.test(email)) {
                setError('incorrect');
            } else {
                onDataChange(true);
            }   
        }

        useEffect(
            () => {
                if (error.current === null || errorMode) {
                    return;
                }
                inputWrapperRef.current?.classList.add(
                    (
                        error.current === 'empty'
                            ? styles.contentEmpty
                            : styles.contentIncorrect
                    ) as string
                )
            }
        )*/

        useEffect(
            () => {
                document.querySelector('#submit')?.addEventListener(
                    'click',
                    validate
                );

                inputRef.current?.addEventListener(
                    'focus',
                    resetErrors
                )
            }
        )

        return (
            <div
                style={
                    {
                        '--contentIncorrectMessage': contentIncorrectErrorMessage
                    } as CSSProperties
                }
                ref={inputWrapperRef}
                id = 'email'
                className={styles.inputWrapper}
            >
                <input
                    ref={
                        (node) => {
                            inputRef.current = node;
                            if (typeof ref !== 'function' && ref) {
                                ref.current = node;
                            }
                        }
                    }
                    type='text'
                    placeholder="Электронная почта"
                    name='email'
                    className={styles.input}
                />
            </div>
        );
    }
);

export {
    EmailInput
}