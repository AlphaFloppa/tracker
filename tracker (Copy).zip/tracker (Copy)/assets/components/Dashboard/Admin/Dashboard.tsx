import { useLocation, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import { useUser } from "../../../hooks/UserStorage.hooks";
import styles from './.module.css';
import { DashboardRender as AdminDashboardRender } from "./AdminDashboard.render";
import { Student, StudentData } from "../../../types/User";
import { createContext } from "react";
import { useStore } from "./Pages/Common/.hooks";

const stageToPageIndex = (
    stage: "register" | "documentsSubmission" | "exams" | "interview" | "final"
) => {
    switch (stage) {
        case 'register':
            return 0
        case 'documentsSubmission':
            return 1
        case 'exams':
            return 2
        case 'interview':
            return 3
        case 'final':
            return 4
    }
}

type MutableStudentData = Omit<StudentData, 'uploadedDocuments'> & {
    documents: File[]
}

type MutableStudentCopyContextValue = {
    value: MutableStudentData,
    setValue: (newValue: MutableStudentData) => void
}

const MutableStudentCopyContext = createContext<MutableStudentCopyContextValue | null>(null);

const Dashboard = () => {
    const { user } = useUser();
    const navigate = useNavigate();
    const {storeMutatedStudent} = useStore();
    const { studentData } = useLocation().state as { studentData: Student };
    const {uploadedDocuments, ...rest} = studentData;
    const [mutableStudentCopy, setMutableStudentCopy] = useState<MutableStudentData>(
        {
            ...rest,
            documents: []
        }
    );
    console.log(mutableStudentCopy);
    const [isProfileOpen, setIsProfileOpen] = useState<boolean>(false);
    const [page, setPage] = useState<number>(0);

    const moveUp = () => {
        setPage(
            (page) => page < 4 ? page + 1 : page
        );
    }
    const moveDown = () => {
        setPage(
            (page) => page > 0 ? page - 1 : page
        );
    }

    const profileOpenHandler = () => {
        setIsProfileOpen(true);
        document.getElementById('overlay-provider')?.classList.add(
            styles.overlay
        );
    }

    const profileCloseHandler = () => {
        setIsProfileOpen(false);
        document.getElementById('overlay-provider')?.classList.remove(
            styles.overlay
        );
    }

    const exitHandler = () => {
        alert('saving');
        storeMutatedStudent(
            studentData,
            mutableStudentCopy
        );
    }

    useEffect(
        () => {
            document.querySelector('#nextPageBtn')?.addEventListener(
                'click',
                moveUp
            );

            document.querySelector('#previousPageBtn')?.addEventListener(
                'click',
                moveDown
            );

            return () => {
                document.querySelector('#nextPageBtn')?.removeEventListener(
                    'click',
                    moveUp
                );

                document.querySelector('#previousPageBtn')?.removeEventListener(
                    'click',
                    moveDown
                );
            }
        }
    );

    useEffect(
        () => {
            if (user === null) {
                navigate('/sign')
            }
        }
    );

    if (user === null) {
        return;
    }

    return (
        <MutableStudentCopyContext.Provider 
            value={
                {
                    value: mutableStudentCopy,
                    setValue: setMutableStudentCopy
                }
            }
        >
            <AdminDashboardRender
                onExit={exitHandler}
                student={studentData}
                isProfileOpen={isProfileOpen}
                profileOpenHandler={profileOpenHandler}
                profileCloseHandler={profileCloseHandler}
                activePage={page}
                setActivePage={setPage}
            />
        </MutableStudentCopyContext.Provider>
    );
}

export {
    Dashboard,
    stageToPageIndex
}

export {
    MutableStudentCopyContext
}

export type {
    MutableStudentData
}