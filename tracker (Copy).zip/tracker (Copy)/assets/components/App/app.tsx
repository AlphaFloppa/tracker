import { useUser } from "../../hooks/UsersStorage.hooks";
import { AdminPanel } from "../AdminPanel/AdminPanel";
import { Dashboard } from "../Dashboard/Student/Dashboard";
import { SignPage } from "../SignPage/SignPage";
import { BrowserRouter, Route, Routes } from "react-router-dom";

const App = () => {
    const { user } = useUser();
    /*if (user == null && window.location.pathname !== '/sign'){
        window.location.href = '/sign';
    }*/
    return (
        <>
            <BrowserRouter>
                <Routes>
                    <Route path='/sign' element={<SignPage />} />
                    <Route path='/dashboard' element={<Dashboard />} />
                    <Route path='/panel' element={<AdminPanel />} />
                </Routes>
            </BrowserRouter>
        </>
    );
}

export {
    App
}