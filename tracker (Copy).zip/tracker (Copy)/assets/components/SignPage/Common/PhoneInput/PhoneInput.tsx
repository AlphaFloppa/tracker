import { CSSProperties, ForwardedRef, forwardRef, useCallback, useEffect, useRef, useState } from "react";
import styles from '../../RegisterForm/.module.css';

type PhoneInputProps = {
    onDataChange: Function,
    errorMode: boolean
}

const contentIncorrectErrorMessage = "'*неверно указан номер телефона'";

const PhoneInput = forwardRef(
    ({ onDataChange, errorMode }: PhoneInputProps, ref: ForwardedRef<HTMLInputElement | null>) => {
        const [isFocused, setIsFocused] = useState<boolean>(false);
        const inputWrapperRef = useRef<HTMLDivElement | null>(null);
        const progress = useRef<number>(0);
        const [phone, setCurrentPhone] = useState<(string | null)[]>(
            [null, null, null, null, null, null, null, null, null, null]
        );
        const error = useRef<'incorrect' | 'empty' | null>(null);
        const setError = (value: 'incorrect' | 'empty' | null) => {
            error.current = value;
        }
        const inputRef = useRef<HTMLInputElement | null>(null);

        const validate = () => {
            if (progress.current === 0) {
                inputWrapperRef.current?.classList.add(styles.contentEmpty)
                inputWrapperRef.current?.classList.remove(styles.contentIncorrect)
                onDataChange(false)
                return
            }
            if (progress.current < 10) {
                inputWrapperRef.current?.classList.remove(styles.contentEmpty)
                inputWrapperRef.current?.classList.add(styles.contentIncorrect)
                onDataChange(false)
                return
            }

            onDataChange(true)
        }

        const resetErrors = () => {
            inputWrapperRef.current?.classList.remove(styles.contentEmpty)
            inputWrapperRef.current?.classList.remove(styles.contentIncorrect)
        }
        /*const setCursorPosition = () => {
            const cursorMap = {
                0: 3,
                1: 4,
                2: 5,
                3: 7,
                4: 8,
                5: 9,
                6: 11,
                7: 12,
                8: 14,
                9: 15,
                10: 16
            } as Record<number, number>;

            const position = cursorMap[progress.current];
            console.log(progress.current);
            inputRef.current?.setSelectionRange(0, 0);
        }*/

        /*const focusHandler = () => {
            setIsFocused(true);
            setError(null);
        }

        const blurHandler = () => {
            setIsFocused(false);
            if (progress.current === 0) {
                setError('empty');
            } else if (progress.current < 11) {
                setError('incorrect');
            } else {
                onDataChange(true);
            }
        }*/

        const changeHandler = (e: KeyboardEvent) => {
            if (/^[0-9]$/.test(e.key) && isFocused && progress.current < 10) {
                progress.current = progress.current + 1;

                setCurrentPhone(
                    (currentPhone) => {
                        const newPhone = [...currentPhone];
                        newPhone[progress.current - 1] = e.key;
                        return newPhone;
                    }
                )
            } else if (e.key === 'Backspace' && progress.current > 0) {
                progress.current = progress.current - 1;

                setCurrentPhone(
                    (currentPhone) => {
                        const newPhone = [...currentPhone];
                        newPhone[progress.current] = null;
                        return newPhone;
                    }
                )
            }
        }

        /*useEffect(
            () => {
                setCursorPosition()
            },
            [phone]
        );*/

        useEffect(
            () => {
                document.querySelector('#submit')?.addEventListener(
                    'click',
                    validate
                )

                inputRef.current?.addEventListener(
                    'focus',
                    resetErrors
                )
            }
        )

        useEffect(() => {
            if (isFocused) {
                document.addEventListener('keydown', changeHandler);
            } else {
                document.removeEventListener('keydown', changeHandler);
            }

            return () => document.removeEventListener('keydown', changeHandler);
        }, [isFocused, changeHandler]);

        return (
            <div
                style={
                    {
                        '--contentIncorrectMessage': contentIncorrectErrorMessage
                    } as CSSProperties
                }
                className={styles.inputWrapper}
                ref={inputWrapperRef}
            >
                {
                    (
                        <input
                            ref={
                                (node) => {
                                    inputRef.current = node;
                                    if (typeof ref !== 'function' && ref !== null) {
                                        ref.current = node;
                                    }
                                }
                            }
                            onChange={() => { }}
                            value={
                                progress.current > 0 || isFocused
                                    ?
                                    "+7(" +
                                    (phone[0] ?? '_') +
                                    (phone[1] ?? '_') +
                                    (phone[2] ?? '_') +
                                    ")" +
                                    (phone[3] ?? '_') +
                                    (phone[4] ?? '_') +
                                    (phone[5] ?? '_') +
                                    "-" +
                                    (phone[6] ?? '_') +
                                    (phone[7] ?? '_') +
                                    "-" +
                                    (phone[8] ?? '_') +
                                    (phone[9] ?? '_')
                                    :
                                    ''
                            }
                            onFocus={() => { setIsFocused(true) }}
                            onBlur={() => { setIsFocused(false) }}
                            type='tel'
                            placeholder="Номер телефона"
                            name='phone'
                            className={styles.input}
                        />
                    )
                }
            </div>
        );
    }
);

export {
    PhoneInput
}