CREATE DATABASE tracker;

USE tracker;

CREATE TABLE student(
    id VARCHAR(200) PRIMARY KEY,
    class INT UNSIGNED,
    email VARCHAR(200) UNIQUE,
    password_hash VARCHAR(200),
    full_name VARCHAR(200),
    parent_full_name VARCHAR(200),
    phone VARCHAR(200) UNIQUE,
    current_stage ENUM('register' , 'documentsSubmission', 'exams', 'interview', 'final')
);

CREATE TABLE admin(
    id VARCHAR(200) PRIMARY KEY,
    email VARCHAR(200) UNIQUE,
    password_hash VARCHAR(200),
    full_name VARCHAR(200)
);

CREATE TABLE exam_mark(
    subject ENUM('phys', 'math', 'test'),
    mark INT UNSIGNED,
    max_mark INT UNSIGNED,
    student_id VARCHAR(200)
);

CREATE TABLE document(
    document_name VARCHAR(200),
    student_id VARCHAR(200)
);

CREATE TABLE stage(
    id INT UNSIGNED PRIMARY KEY,
);