import commonStyles from '../../Pages/.module.css';
import dashboardStyles from '../../.module.css';
import styles from './.module.css';
import type { Student } from '../../../../../types/User';
import { stageToPageIndex } from '../../Dashboard';
import { InterviewPanel } from './InterviewPanel/InterviewPanel';

type Props = {
    student: Student
}

const InterviewPage = (
    { student }: Props
) => {
    const { currentStage, interview } = student;

    return (
        <div className={`${dashboardStyles.infoContainer} ${styles.infoContainer}`}>
            <div className={commonStyles.container}>
                <div className={commonStyles.infoContainer}>
                    <span className={commonStyles.trackHeader}>{'Собеседование'}</span>
                    <span className={commonStyles.trackSubHeader}>{'Подробная информация об этом этапе:'}</span>
                    <span className={commonStyles.stageDesc}>{'Онлайн-встреча с сотрудником приемной комиссии, чтобы ты рассказал о себе, своих увлечениях и почему тебя заинтересовал Инфотех.'}</span>
                    <div className={commonStyles.deadlinesStatusCont}>
                        <div className={commonStyles.deadlines}>
                            <span className={commonStyles.deadlinesHeader}>{'Сроки:'}</span>
                            <span className={commonStyles.deadlinesInfo}>{'01.06.26 - 15.07.26 '}</span>
                        </div>
                        <div className={commonStyles.status}>
                            <span className={commonStyles.statusHeader}>{'Статус этапа:'}</span>
                            <span
                                className={
                                    `
                                        ${commonStyles.statusValue} 
                                        ${stageToPageIndex(currentStage) < 3
                                        ? commonStyles.unstarted
                                        : stageToPageIndex(currentStage) === 3
                                            ? commonStyles.unfinished
                                            : commonStyles.finished
                                    }
                                    `
                                }
                            >
                                {
                                    stageToPageIndex(currentStage) < 3
                                        ? 'Не начато'
                                        : stageToPageIndex(currentStage) === 3
                                            ? 'В процессе'
                                            : 'Пройдено'
                                }
                            </span>
                        </div>
                    </div>
                </div>

                <InterviewPanel interview={interview}/>
            </div>

            <div className={commonStyles.arrowNext} id='nextPageBtn'></div>
            <div className={commonStyles.arrowPrevious} id='previousPageBtn'></div>
        </div >
    );
}

export {
    InterviewPage
}