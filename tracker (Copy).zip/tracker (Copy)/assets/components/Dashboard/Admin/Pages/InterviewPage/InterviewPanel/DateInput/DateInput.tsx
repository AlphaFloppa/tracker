import { useEffect, useState } from "react";
import styles from './.module.css';

type InputData = {
    isFocused: boolean,
    content: string
}

type Props = {
    initialDay: string,
    initialMonth: string,
    onBlur: Function
}

const DateInput = (
    { initialDay, initialMonth, onBlur }: Props
) => {
    const [dayInput, setDayInput] = useState<InputData>(
        {
            isFocused: false,
            content: initialDay
        }
    );
    const [monthInput, setMonthInput] = useState<InputData>(
        {
            isFocused: false,
            content: initialMonth
        }
    );

    const dayInputHandler = ({ key }: KeyboardEvent) => {
        if (dayInput.isFocused) {

            if (/[0-9]/.test(key) && dayInput.content.length < 2) {
                setDayInput(
                    {
                        isFocused: true,
                        content: dayInput.content + key
                    }
                )
            } else if (key === 'Backspace' && dayInput.content.length > 0) {
                setDayInput(
                    {
                        isFocused: true,
                        content: dayInput.content.slice(0, -1)
                    }
                )
            } /*else if (key === 'Escape') {
                setMonthInput(
                    (currentState) => ({
                        ...currentState,
                        isFocused: false
                    })
                )
            }*/
        }
    }

    const monthInputHandler = ({ key }: KeyboardEvent) => {
        if (monthInput.isFocused) {

            if (/[0-9]/.test(key) && monthInput.content.length < 2) {
                setMonthInput(
                    {
                        isFocused: true,
                        content: monthInput.content + key
                    }
                )
            } else if (key === 'Backspace' && monthInput.content.length > 0) {
                setMonthInput(
                    {
                        isFocused: true,
                        content: monthInput.content.slice(0, -1)
                    }
                )
            } /*else if(key === 'Escape') {
                setMonthInput(
                    (currentState) => ({
                        ...currentState,
                        isFocused: false
                    }) 
                )
            }*/
        }
    }

    useEffect(
        () => {
            const composedHandler = (event: KeyboardEvent) => {
                dayInputHandler(event);
                monthInputHandler(event);
            }

            window.addEventListener(
                'keydown',
                composedHandler
            );

            return () => {
                window.removeEventListener(
                    'keydown',
                    composedHandler
                );
            }
        },
        [dayInput, monthInput]
    );

    return (
        <>
            <input
                className={styles.input}
                id='day'
                type="text"
                value={dayInput.content}
                onChange={() => { }}
                onFocus={
                    () => {
                        setDayInput(
                            (currentState) => (
                                {
                                    ...currentState,
                                    isFocused: true
                                }
                            )
                        )
                    }
                }
                onBlur={
                    () => {
                        setDayInput(
                            (currentState) => (
                                {
                                    ...currentState,
                                    isFocused: false
                                }
                            )
                        );

                        onBlur();
                    }
                }
            />

            <span>
                {'.'}
            </span>

            <input
                className={styles.input}
                id='month'
                type="text"
                value={monthInput.content}
                onChange={() => { }}
                onFocus={
                    () => setMonthInput(
                        (currentState) => (
                            {
                                ...currentState,
                                isFocused: true
                            }
                        )
                    )
                }
                onBlur={
                    () => setMonthInput(
                        (currentState) => (
                            {
                                ...currentState,
                                isFocused: false
                            }
                        )
                    )
                }
            />
        </>
    );
}

export {
    DateInput
}