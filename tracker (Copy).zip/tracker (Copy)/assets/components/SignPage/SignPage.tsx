import { Form as LoginForm } from "./LoginForm/Form";
import { Form as RegisterForm } from './RegisterForm/Form';
import { Switcher } from "./Switcher/Switcher";
import styles from './.module.css';
import { CSSProperties, useState } from "react";

type ActiveMode = 'register' | 'login';

const SignPage = () => {
    const [activeMode, setActiveMode] = useState<ActiveMode>('login');
    const toggleActiveMode = () => {
        if (activeMode === 'login') {
            setActiveMode('register');
        } else {
            setActiveMode('login');
        }
    }
    return (
        <div className={styles.mainContainer} style={
            {'--contentEmptyMessage': "'*это поле обязательно'"} as CSSProperties
        }>

            <div className={styles.pic}>
            </div>

            <div className={styles.panel}>
                <div className={styles.infoContainer}>
                    <h1
                        className={styles.header}
                    >
                        {activeMode === 'register' && 'Зарегистрироваться на портале'}
                        {activeMode === 'login' && 'Зайти на портал'}
                    </h1>
                    <p
                        className={styles.text}
                    >
                        Это место, где можно узнать все о поступлении, прикрепить электронные документы и отслеживать прохождение этапов поступления
                    </p>
                </div>

                <Switcher
                    currentMode={activeMode}
                    toggleMode={toggleActiveMode}
                />

                {
                    activeMode === 'login'
                        ? <LoginForm />
                        : <RegisterForm />
                }
            </div>

        </div>
    );
}

export {
    SignPage,
    type ActiveMode
}