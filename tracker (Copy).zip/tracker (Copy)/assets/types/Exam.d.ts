type ExamMark = {
    currentMark: number,
    maxMark: number
}

export type{
    ExamMark
}