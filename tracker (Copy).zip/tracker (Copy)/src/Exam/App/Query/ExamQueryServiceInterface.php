<?php

namespace App\Exam\App\Query;

use App\Exam\App\Exam;

interface ExamQueryServiceInterface
{
    public function findExamByStudentId(string $id): ?Exam;
}