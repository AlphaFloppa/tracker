import styles from './.module.css';
import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '../../hooks/UserStorage.hooks';
import { Student, StudentData } from '../../types/User';
import { useStudentsData } from './AdminPanel.hooks';
import { AdminPanelRender } from './AdminPanel.render';
import { useFetch } from '../Dashboard/Admin/Pages/Common/.hooks';
import { validate } from '../../hooks/common';

const AdminPanel = () => {
    const { user } = useUser();
    const navigate = useNavigate();

    const [classFilters, setClassFilters] = useState<Array<string>>(
        ['11', '10', '9', '8']
    );
    const [stageFilters, setStageFilters] = useState<Array<string>>(
        ['documentsSubmission', 'exams', 'interview', 'final']
    );
    const [searchingQuery, setSearchingQuery] = useState<string | null>(null);
    const [students, setStudents] = useState<StudentData[]>([]);
    const {loadMutableStudentData} = useFetch('');              //bad

    useStudentsData(
        {
            classFilters,
            stageFilters,
            studentNameQuery: searchingQuery,
            setResult: setStudents
        }
    );

    const [selection, setSelection] = useState<Array<string>>([]);
    const [isProfileOpen, setIsProfileOpen] = useState<boolean>(false);
    const containerRef = useRef<HTMLDivElement | null>(null);

    const studentSelectHandler = (clickedStudentId: string) => {
        setSelection(
            (currentSelectionState) => {
                const isUnselected = selection.some(
                    (selectedId) => selectedId === clickedStudentId
                );

                if (isUnselected) {
                    return [...currentSelectionState].filter(
                        (selectedId) => selectedId !== clickedStudentId
                    )
                } else {
                    return [
                        ...currentSelectionState,
                        clickedStudentId
                    ]
                }
            }
        )
    }

    const studentInspectHandler = async (id: string) => {
        const fullStudentData = await loadMutableStudentData(
            validate(students.find(state => state.id === id))
        );

        navigate(
            `/student/${id}`, 
            {
                state: {
                    studentData: fullStudentData
                }
            }
        );
    }

    const selectAllStudentsHandler = () => {
        setSelection(
            students.map(
                ({ id }) => id
            )
        );
    }

    const profileOpenHandler = () => {
        setIsProfileOpen(true);
        containerRef.current?.classList.add(
            styles.overlay
        );
    }

    const profileCloseHandler = () => {
        setIsProfileOpen(false);
        containerRef.current?.classList.remove(
            styles.overlay
        );
    }

    useEffect(
        () => {
            if (user === null) {
                navigate('/sign')
            }
        }
    )

    if (user === null || user.type !== 'admin') {
        return;
    }

    return (
        <AdminPanelRender 
            containerRef={containerRef}
            isProfileOpen = {isProfileOpen}
            profileOpenHandler={profileOpenHandler}
            profileCloseHandler={profileCloseHandler}
            searchingQuery={searchingQuery}
            setSearchingQuery={setSearchingQuery}
            setClassFilters={setClassFilters}
            setStageFilters={setStageFilters}
            selection={selection}
            students={students}
            selectAllStudentsHandler={selectAllStudentsHandler}
            studentSelectHandler={studentSelectHandler}
            studentInspectHandler={studentInspectHandler}
        />
    );
}
export {
    AdminPanel
}