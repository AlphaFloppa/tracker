<?php

namespace App\Admin\Infrastructure\Query;

use App\Admin\App\Admin;
use App\Admin\App\Query\AdminQueryServiceInterface;
use PDO;

class AdminQueryService implements AdminQueryServiceInterface
{
    public function __construct(
        private PDO $pdo
    ) {}

    public function findAdminByEmail(string $email): ?Admin
    {
        $query = <<<SQL
            SELECT * FROM admin
            WHERE email = :email
        SQL;

        $stmt = $this->pdo->prepare($query);
        $stmt->execute(
            [
                'email' => $email
            ]
        );

        $data = $stmt->fetch(PDO::FETCH_ASSOC);

        if(!$data)
        {
            return null;
        }

        return new Admin(
            $data['id'],
            $data['email'],
            $data['password_hash']
        );
    }
}
